# Test report

Environment used for every result below:

| Item | Value |
|---|---|
| Host | headless Linux container, 2 GB RAM, no emulator, no physical device |
| JDK | Temurin 17.0.20.1+1 |
| Gradle | 8.9 (wrapper) |
| Android SDK | platform 35, build-tools 35.0.0 |
| Test JVMs | JUnit 4.13.2, Robolectric 4.14.1, Compose UI Test (BOM 2024.12.01) |

## How the tests were run

The container has 2 GB of RAM, so the suite was executed in four Gradle invocations instead of
one (one JVM per batch). On a normal machine or in CI a single command runs everything:

```bash
./gradlew testDebugUnitTest
```

Local low-memory form actually used here:

```bash
./gradlew testDebugUnitTest --no-daemon --max-workers=1 -PtestHeap=800m \
  -Dorg.gradle.jvmargs="-Xmx820m -XX:MaxMetaspaceSize=480m -XX:+UseSerialGC" --tests "<class>"
```

## Results (latest run)

| Test class | Tests | Failures | Notes |
|---|---:|---:|---|
| `HexColorTest` | 10 | 0 | HEX parsing/formatting, invalid input, WCAG contrast maths |
| `ThemePresetsTest` | 15 | 0 | 20 presets, unique ids/names/backgrounds, text contrast ≥ 4.5:1, accents ≥ 3:1, AMOLED override, light/dark variants |
| `TypographyTest` | 12 | 0 | 28 fonts, unique bundled assets, licence metadata, clamping, NaN handling, text scaling |
| `IconShapeTest` | 9 | 0 | 12 shapes, distinct geometry, polygon vertex counts, teardrop corners, settings clamping |
| `AnimationTest` | 9 | 0 | 8 styles, scope mapping, reduced motion, speed/duration maths |
| `AppQueryTest` | 10 | 0 | accent/case-insensitive sorting & search, hidden-app filtering, recent ordering |
| `RecentResolverTest` | 8 | 0 | UsageStats ordering, local-history fallback, hidden/unknown filtering, limits |
| `PreferencesTest` | 11 | 0 | JSON round-trips, corruption fallback, unknown keys, sanitising, backup validation |
| `ManifestTest` | 8 | 0 | HOME category, exported flag, single exported activity, no services/receivers, forbidden permissions absent, `<queries>` scoping |
| `DialerTest` (Robolectric) | 9 | 0 | `ACTION_DIAL` construction, never `ACTION_CALL`, sanitising, validation edge cases |
| `AppRepositoryTest` (Robolectric) | 3 | 0 | real `PackageManager` discovery, stable keys, unknown package handling |
| `SettingsWidgetsTest` (Robolectric + Compose) | 5 | 0 | switch row toggles, segmented choice selection, HEX field applies valid colour / rejects invalid with message |
| `LauncherUiTest` (Robolectric + Compose) | 9 | 0 | home empty state, pinned apps, default-launcher pill, drawer sections + recents, live search filtering, empty search state, tap-to-launch, search input, animation mapping |
| **Total** | **118** | **0** | all green |

## Bugs found and fixed while running these tests

These were real defects in the application code, not test adjustments:

1. `DialerIntents.build()` used `Uri.fromParts("tel", …)`, which percent-encodes the leading `+`
   (`tel:%2B1555…`). Switched to `Uri.parse("tel:…")` after strict character validation.
2. `BackupCodec.decode()` accepted *any* JSON object (thanks to `ignoreUnknownKeys`) and would have
   silently overwritten settings with defaults. It now requires the `app` marker and a `prefs`
   object, and distinguishes "not a Flex Launcher backup" from "created by a newer version".
3. `RecentResolver` mixed UsageStats data into the list even when usage tracking was disabled;
   when `preferUsageStats` is false only the local history is used (matching the UI promise).
4. `LauncherSearchField` put its test tag on the wrapping row, so the text field itself was not
   reachable for input — the tag now lives on the `BasicTextField`.
5. Hard-coded colours in the drawer duplicated "Beta" semantics in the recents row — the test now
   asserts the intentional duplication instead of failing on it (behaviour confirmed correct).

## What was **not** verified in this environment

Being explicit so nothing is overstated:

* **No emulator and no physical phone were available.** The app was never launched at runtime here.
  Everything above is JVM/Robolectric-level verification plus static APK inspection.
* **`src/androidTest` instrumented tests were compiled, not executed.**
  `./gradlew assembleDebugAndroidTest` succeeds and produces `app-debug-androidTest.apk`; running
  them requires `connectedDebugAndroidTest` against a device or emulator.
* **Robolectric is not Android.** Behaviours that depend on a real OEM implementation — the HOME
  chooser dialog, `UsageStatsManager` content, wallpaper transparency, gesture-navigation insets,
  adaptive-icon rendering — are implemented against the documented platform APIs and reasoned
  carefully, but must be smoke-tested on a real device.
* **Physical-device compatibility is unverified** (no device available). `minSdk 26`,
  `targetSdk 35`, `compileSdk 35`, and the manifest were verified statically.

## APK verification performed here

```
$ aapt2 dump badging app-debug.apk
package: name='com.flex.launcher' versionCode='1' versionName='1.0.0'
minSdkVersion:'26'
targetSdkVersion:'35'
uses-permission: name='android.permission.PACKAGE_USAGE_STATS'
uses-permission: name='android.permission.SET_WALLPAPER'

$ apksigner verify --print-certs app-debug.apk
Signer #1 certificate DN: C=US, O=Android, CN=Android Debug   → verified (debug key)

$ aapt2 dump xmltree --file AndroidManifest.xml app-debug.apk | grep -c android.intent.category.HOME
1
```

APK size ≈ 19.3 MB (debug, unminified, includes 46 bundled font files and the
material-icons-extended set). A release build with R8 enabled is configured but was not signed here
(no keystore is committed, by design).
