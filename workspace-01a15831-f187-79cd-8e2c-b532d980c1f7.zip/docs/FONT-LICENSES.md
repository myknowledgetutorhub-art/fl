# Bundled font licences

Flex Launcher ships 46 TTF files (regular + bold) covering 23 font families. All of them are
open-source families published on [Google Fonts](https://fonts.google.com) and are redistributable.

| # | Family | Files | Category | Licence | Upstream |
|---|--------|-------|----------|---------|----------|
| 1 | Inter | `inter_regular.ttf`, `inter_bold.ttf` | Grotesk sans | SIL Open Font License 1.1 | https://fonts.google.com/specimen/Inter |
| 2 | Poppins | `poppins_regular.ttf`, `poppins_bold.ttf` | Geometric sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Poppins |
| 3 | Montserrat | `montserrat_*` | Geometric sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Montserrat |
| 4 | Outfit | `outfit_*` | Geometric sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Outfit |
| 5 | DM Sans | `dm_sans_*` | Geometric sans | SIL OFL 1.1 | https://fonts.google.com/specimen/DM+Sans |
| 6 | Space Grotesk | `space_grotesk_*` | Grotesk sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Space+Grotesk |
| 7 | Rubik | `rubik_*` | Rounded sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Rubik |
| 8 | Nunito | `nunito_*` | Rounded sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Nunito |
| 9 | Quicksand | `quicksand_*` | Rounded sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Quicksand |
| 10 | Comfortaa | `comfortaa_*` | Rounded display | SIL OFL 1.1 | https://fonts.google.com/specimen/Comfortaa |
| 11 | Lato | `lato_*` | Humanist sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Lato |
| 12 | Open Sans | `open_sans_*` | Humanist sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Open+Sans |
| 13 | Oswald | `oswald_*` | Condensed sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Oswald |
| 14 | Barlow Condensed | `barlow_condensed_*` | Condensed sans | SIL OFL 1.1 | https://fonts.google.com/specimen/Barlow+Condensed |
| 15 | Playfair Display | `playfair_display_*` | Serif display | SIL OFL 1.1 | https://fonts.google.com/specimen/Playfair+Display |
| 16 | Merriweather | `merriweather_*` | Serif | SIL OFL 1.1 | https://fonts.google.com/specimen/Merriweather |
| 17 | Lora | `lora_*` | Serif | SIL OFL 1.1 | https://fonts.google.com/specimen/Lora |
| 18 | Cinzel | `cinzel_*` | Elegant display | SIL OFL 1.1 | https://fonts.google.com/specimen/Cinzel |
| 19 | Roboto Slab | `roboto_slab_*` | Slab serif | Apache License 2.0 | https://fonts.google.com/specimen/Roboto+Slab |
| 20 | JetBrains Mono | `jetbrains_mono_*` | Monospace | SIL OFL 1.1 | https://fonts.google.com/specimen/JetBrains+Mono |
| 21 | Space Mono | `space_mono_*` | Monospace | SIL OFL 1.1 | https://fonts.google.com/specimen/Space+Mono |
| 22 | Bebas Neue | `bebas_neue_*` | Display | SIL OFL 1.1 | https://fonts.google.com/specimen/Bebas+Neue |
| 23 | Caveat | `caveat_*` | Handwritten | SIL OFL 1.1 | https://fonts.google.com/specimen/Caveat |

`*` = `<family>_regular.ttf` and `<family>_bold.ttf`.

Platform fallbacks (no assets bundled, no licence obligations beyond the Android platform itself):
`sans-serif` (Roboto), `serif` (Noto Serif), `monospace`, `sans-serif-condensed`, `casual`.

## Notes

- **Bebas Neue** is a single-weight family upstream, so `bebas_neue_bold.ttf` is the same face and
  bold text is synthesised by the text renderer. The UI states this ("Single weight face; bold is
  synthesised").
- All other families ship genuine 400 and 700 cut files.
- The SIL OFL permits bundling with an application, including commercial use, provided the font is
  not sold on its own and the copyright notice is retained. Apache 2.0 permits redistribution with
  the licence text. The original licence text for each family is available at the upstream URL above.
- Fonts are applied to Flex Launcher's own UI only; a launcher cannot change the system font.
