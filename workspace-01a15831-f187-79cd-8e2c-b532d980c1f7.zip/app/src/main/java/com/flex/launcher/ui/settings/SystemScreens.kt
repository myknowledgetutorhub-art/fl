package com.flex.launcher.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flex.launcher.BuildConfig
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.InlineNotice
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

@Composable
fun PermissionsScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val usageGranted by vm.usageAccessGranted.collectAsStateWithLifecycle()
    val isDefault by vm.isDefaultLauncher.collectAsStateWithLifecycle()

    SettingsScaffold(title = "Permissions", onBack = onBack) {
        InlineNotice("Flex Launcher requests no internet permission and contains no analytics or ads.")

        SectionTitle("Home app")
        SettingsCard {
            SettingsActionRow(
                "Default home app",
                { vm.openDefaultLauncherSettings() },
                "Required for Flex Launcher to act as your home screen",
                trailingText = if (isDefault) "Granted" else "Not set",
            )
        }

        SectionTitle("Usage access")
        SettingsCard {
            SettingsActionRow(
                "Usage access",
                { vm.openUsageAccessSettings() },
                "Optional. Lets Recent apps order apps opened from any launcher via UsageStats.",
                trailingText = if (usageGranted) "Granted" else "Not granted",
            )
            SettingsActionRow(
                "Refresh status",
                { vm.refreshPermissionState() },
                "Re-checks the permission (also refreshed when you return to the app)",
            )
        }

        SectionTitle("Permissions Flex Launcher declares")
        SettingsCard {
            PermissionInfo(
                "PACKAGE_USAGE_STATS",
                "Optional. Reads foreground-app events so Recent apps can be ordered. Data stays on device.",
            )
            HorizontalDivider()
            PermissionInfo(
                "SET_WALLPAPER",
                "Declared only so the “Change wallpaper” button can hand off to the system picker; " +
                    "Flex Launcher never writes wallpaper pixels itself.",
            )
            HorizontalDivider()
            PermissionInfo(
                "Package visibility (<queries>)",
                "Not a permission: Flex Launcher only declares that it needs to resolve launcher " +
                    "activities. QUERY_ALL_PACKAGES is not requested.",
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Flex Launcher does not request accessibility services, notification access, contacts, " +
                "location, camera, microphone or storage access.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun PermissionInfo(title: String, description: String) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    androidx.compose.foundation.layout.Column(Modifier.padding(16.dp)) {
        Text(title, style = type.body, color = colors.textPrimary)
        Spacer(Modifier.height(2.dp))
        Text(description, style = type.label, color = colors.textSecondary)
    }
}

@Composable
fun BackupScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val type = LocalFlexType.current
    val colors = LocalLauncherColors.current
    var confirmResetAll by remember { mutableStateOf(false) }
    var confirmResetAppearance by remember { mutableStateOf(false) }

    val createBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri -> if (uri != null) vm.exportBackup(uri) }

    val openBackup = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri -> if (uri != null) vm.importBackup(uri) }

    SettingsScaffold(title = "Backup & reset", onBack = onBack) {
        SectionTitle("Backup")
        SettingsCard {
            SettingsActionRow(
                "Export settings to a file",
                { createBackup.launch("flex-launcher-backup.json") },
                "Saves themes, fonts, layout, hidden apps and recent history as JSON",
            )
            SettingsActionRow(
                "Restore from a file",
                { openBackup.launch(arrayOf("application/json", "text/plain", "*/*")) },
                "Validates the file before applying it",
            )
        }

        SectionTitle("Reset")
        SettingsCard {
            SettingsActionRow(
                "Reset appearance settings",
                { confirmResetAppearance = true },
                "Theme, typography, icons, animations and status bar",
                destructive = true,
            )
            SettingsActionRow(
                "Reset all launcher preferences",
                { confirmResetAll = true },
                "Includes hidden apps, pinned apps and recent history",
                destructive = true,
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Backups are plain JSON written to a location you choose through Android's document " +
                "picker. They are not encrypted, so store them somewhere you trust. Flex Launcher " +
                "does not upload anything.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmResetAppearance) {
        AlertDialog(
            onDismissRequest = { confirmResetAppearance = false },
            title = { Text("Reset appearance?") },
            text = { Text("Theme, fonts, icons, animations and status-bar options return to defaults. Hidden apps and pins are kept.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmResetAppearance = false
                    vm.resetAppearance()
                }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { confirmResetAppearance = false }) { Text("Cancel") } },
        )
    }

    if (confirmResetAll) {
        AlertDialog(
            onDismissRequest = { confirmResetAll = false },
            title = { Text("Reset everything?") },
            text = { Text("Every Flex Launcher setting is erased, including hidden apps, pinned apps and recent history. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmResetAll = false
                    vm.resetEverything()
                }) { Text("Erase everything") }
            },
            dismissButton = { TextButton(onClick = { confirmResetAll = false }) { Text("Cancel") } },
        )
    }
}

@Composable
fun AboutScreen(vm: MainViewModel, prefs: LauncherPrefs, onBack: () -> Unit) {
    val type = LocalFlexType.current
    val colors = LocalLauncherColors.current
    val isDefault by vm.isDefaultLauncher.collectAsStateWithLifecycle()

    SettingsScaffold(title = "About", onBack = onBack, subtitle = "Flex Launcher ${BuildConfig.VERSION_NAME}") {
        SettingsCard {
            SettingsActionRow("Version", {}, "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            HorizontalDivider()
            SettingsActionRow("Package", {}, "com.flex.launcher")
            HorizontalDivider()
            SettingsActionRow("Build type", {}, BuildConfig.BUILD_TYPE)
            HorizontalDivider()
            SettingsActionRow(
                "Default home app",
                { vm.openDefaultLauncherSettings() },
                trailingText = if (isDefault) "Yes" else "No",
            )
        }

        SectionTitle("What's inside")
        Text(
            "• 20 named theme presets plus a full custom palette editor with HEX validation\n" +
                "• 28 font families (23 bundled TTF assets plus 5 platform families)\n" +
                "• 12 real icon masks with size, spacing, column and plate controls\n" +
                "• 8 animation styles with speed, per-surface selection and reduced motion\n" +
                "• Recent apps backed by UsageStats with a local-history fallback\n" +
                "• Hide apps, favourites/pins, dial pad, wallpaper picker, JSON backup\n" +
                "• Edge-to-edge transparent status bar with automatic icon contrast",
            style = type.body,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )

        SectionTitle("Platform limits you should know")
        Text(
            "• A launcher cannot show the system Recents screen contents; UsageStats is approximate.\n" +
                "• Launchers cannot change the system font, system-wide app-open animations or the " +
                "notification shade.\n" +
                "• Hiding an app does not disable, uninstall or hide it from other launchers.\n" +
                "• Third-party icons are drawn from each app's own assets; masks cannot redraw artwork.\n" +
                "• “Glass” effects are visual imitations inside the launcher window, not real system blur.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )

        SectionTitle("Privacy")
        Text(
            "No internet permission, no analytics, no ads, no telemetry. Usage data is read locally " +
                "and used only to order your Recent apps list. Hidden-app lists and preferences are " +
                "stored in app-private DataStore files.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
        Text(
            "Current configuration: ${prefs.hiddenApps.size} hidden apps · theme “${prefs.themeId}” · " +
                "font “${prefs.typography.font.displayName}”",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(28.dp))
    }
}
