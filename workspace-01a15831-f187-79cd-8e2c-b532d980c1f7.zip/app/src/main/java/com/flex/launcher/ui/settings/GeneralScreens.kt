package com.flex.launcher.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flex.launcher.BuildConfig
import com.flex.launcher.domain.model.AppSortMode
import com.flex.launcher.domain.model.DrawerSettings
import com.flex.launcher.domain.model.HomeSettings
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.StatusBarIconMode
import com.flex.launcher.domain.model.StatusBarSettings
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.InlineNotice
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SegmentedChoice
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.components.formatPercent
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

@Composable
fun HomeScreenSettings(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val isDefault by vm.isDefaultLauncher.collectAsStateWithLifecycle()
    val pinned by vm.pinnedApps.collectAsStateWithLifecycle()

    fun update(transform: (HomeSettings) -> HomeSettings) {
        vm.updatePrefs { it.copy(home = transform(it.home)) }
    }

    SettingsScaffold(title = "Home screen", onBack = onBack, subtitle = "${pinned.size} pinned") {
        InlineNotice(
            text = if (isDefault) "Flex Launcher is the default home app."
            else "Flex Launcher is not the default home app yet.",
        )
        SettingsCard {
            SettingsActionRow(
                if (isDefault) "Manage default home app" else "Set Flex Launcher as default",
                { vm.openDefaultLauncherSettings() },
                "Opens Android's default apps screen",
                trailingText = if (isDefault) "Default" else "Not default",
            )
            SettingsActionRow(
                "Change wallpaper",
                { vm.openWallpaperPicker() },
                "Opens the system wallpaper picker",
            )
        }

        SectionTitle("Widgets")
        SettingsCard {
            SettingsSwitchRow(
                "Clock",
                prefs.home.clockEnabled,
                { on -> update { it.copy(clockEnabled = on) } },
                "Large launcher clock at the top of the home screen",
            )
            SettingsSwitchRow(
                "24-hour time",
                prefs.home.use24Hour,
                { on -> update { it.copy(use24Hour = on) } },
                "Affects the launcher clock only",
            )
            SettingsSwitchRow(
                "Date",
                prefs.home.dateEnabled,
                { on -> update { it.copy(dateEnabled = on) } },
            )
            SettingsSwitchRow(
                "Show pinned apps grid",
                prefs.home.showHomeGrid,
                { on -> update { it.copy(showHomeGrid = on) } },
                "Home shortcuts you pinned from the app drawer",
            )
        }

        SectionTitle("Feedback")
        SettingsCard {
            SettingsSwitchRow(
                "Haptic feedback",
                prefs.hapticsEnabled,
                { on -> vm.updatePrefs { it.copy(hapticsEnabled = on) } },
                "Vibrates when you open or pin an app",
            )
        }

        SectionTitle("Pinned apps")
        SettingsCard {
            if (pinned.isEmpty()) {
                Text(
                    "No pinned apps yet. Long-press any app in the drawer and choose “Pin to home”.",
                    style = type.label,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(16.dp),
                )
            } else {
                pinned.forEachIndexed { index, app ->
                    SettingsActionRow(
                        title = app.label,
                        onClick = { vm.movePin(index, (index - 1).coerceAtLeast(0)) },
                        description = "Position ${index + 1} · tap to move up · unpin from the drawer's long-press menu",
                        trailingText = if (index == 0) null else "↑",
                        enabled = index > 0,
                    )
                    if (index != pinned.lastIndex) HorizontalDivider()
                }
                SettingsActionRow("Remove all pinned apps", {
                    vm.updatePrefs { it.copy(home = it.home.copy(pinnedApps = emptyList())) }
                }, destructive = true)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun DrawerSettingsScreen(
    vm: MainViewModel,
    onBack: () -> Unit,
    onOpenIcons: () -> Unit,
) {
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val type = LocalFlexType.current
    val colors = LocalLauncherColors.current

    SettingsScaffold(title = "App drawer", onBack = onBack) {
        SectionTitle("Sorting")
        SegmentedChoice(
            options = AppSortMode.entries,
            selected = prefs.drawer.sortMode,
            onSelect = { mode -> vm.updatePrefs { it.copy(drawer = it.drawer.copy(sortMode = mode)) } },
            label = { it.label },
        )

        SectionTitle("Sections")
        SettingsCard {
            SettingsSwitchRow(
                "Show recent apps section",
                prefs.drawer.showRecents,
                { on -> vm.updatePrefs { it.copy(drawer = it.drawer.copy(showRecents = on)) } },
                "Appears above favourites and all apps",
            )
            SettingsSwitchRow(
                "Show “All apps” header",
                prefs.drawer.showAllAppsHeader,
                { on -> vm.updatePrefs { it.copy(drawer = it.drawer.copy(showAllAppsHeader = on)) } },
            )
            SettingsActionRow("Grid columns and icon size", onOpenIcons, "Open Icons & shapes")
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Sorting changes the real ordering of installed apps. “Recently used” uses the same " +
                "ordering source as Recent apps (UsageStats when granted, local history otherwise).",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun StatusBarSettingsScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val type = LocalFlexType.current
    val colors = LocalLauncherColors.current

    fun update(transform: (StatusBarSettings) -> StatusBarSettings) {
        vm.updatePrefs { it.copy(statusBar = transform(it.statusBar).sanitized()) }
    }

    SettingsScaffold(title = "Status bar", onBack = onBack, subtitle = "Edge-to-edge launcher UI") {
        SectionTitle("Appearance")
        SettingsCard {
            SettingsSwitchRow(
                "Status bar scrim",
                prefs.statusBar.showScrim,
                { on -> update { it.copy(showScrim = on) } },
                "Adds a soft gradient behind status icons for readability on busy wallpapers",
            )
            SettingsSliderRow(
                "Scrim strength",
                prefs.statusBar.scrimAlpha,
                { v -> update { it.copy(scrimAlpha = v) } },
                StatusBarSettings.SCRIM_RANGE,
                valueLabel = ::formatPercent,
                onReset = { update { it.copy(scrimAlpha = 0.35f) } },
            )
        }

        SectionTitle("Icon colour")
        SegmentedChoice(
            options = StatusBarIconMode.entries,
            selected = prefs.statusBar.iconMode,
            onSelect = { mode -> update { it.copy(iconMode = mode) } },
            label = { it.label },
        )

        Spacer(Modifier.height(16.dp))
        Text(
            "Flex Launcher draws edge-to-edge: the status bar background is fully transparent on " +
                "the home screen so your wallpaper shows through, and content is inset below it. " +
                "Android decides the actual status-bar icon style on some OEM builds; the " +
                "“Automatic” option follows the readability of the current theme. This controls the " +
                "launcher's own window only — a launcher cannot restyle the notification shade.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun DialerSettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val type = LocalFlexType.current
    val colors = LocalLauncherColors.current
    SettingsScaffold(title = "Dial pad", onBack = onBack) {
        SectionTitle("About")
        Text(
            "Flex Launcher includes a dial-pad for quick number entry. The call button opens " +
                "Android's ACTION_DIAL intent, which is the system dialer pre-filled with the number " +
                "you typed — you still press call there.",
            style = type.body,
            color = colors.textPrimary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "No CALL_PHONE permission is requested, so Flex Launcher can never place a call by " +
                "itself. Contacts, call history and SMS are intentionally not accessed.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(16.dp))
        SettingsCard {
            SettingsActionRow("Test with a number", {
                vm.openIntent(
                    android.content.Intent(
                        android.content.Intent.ACTION_DIAL,
                        android.net.Uri.parse("tel:"),
                    ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }, "Opens your phone app's dialer")
        }
        Spacer(Modifier.height(24.dp))
    }
}
