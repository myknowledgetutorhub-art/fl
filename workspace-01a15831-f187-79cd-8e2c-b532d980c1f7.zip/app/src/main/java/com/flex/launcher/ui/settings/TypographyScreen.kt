package com.flex.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.typography.FontOption
import com.flex.launcher.domain.typography.FontOptions
import com.flex.launcher.domain.typography.TypographyLimits
import com.flex.launcher.domain.typography.TypographySettings
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors
import com.flex.launcher.ui.theme.toFontFamily

/** Font family picker + every typography control. Applies to the launcher UI only. */
@Composable
fun TypographyScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val typo = prefs.typography

    fun update(transform: (TypographySettings) -> TypographySettings) {
        vm.updatePrefs { it.copy(typography = transform(it.typography)) }
    }

    SettingsScaffold(title = "Fonts & typography", onBack = onBack, subtitle = typo.font.displayName) {
        // Live sample using current settings
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(colors.card)
                .padding(16.dp),
        ) {
            Column {
                Text("Flex Launcher", style = type.heading, color = colors.textPrimary)
                Text("App drawer · 24 apps installed", style = type.drawerLabel, color = colors.textSecondary)
                Text("Aa Bb Cc 0123", style = type.homeLabel.copy(fontSize = 20.sp), color = colors.primary)
            }
        }

        SectionTitle("Font family (${FontOptions.all.size} available)")
        SettingsCard {
            FontOptions.all.forEachIndexed { index, font ->
                FontRow(
                    option = font,
                    selected = typo.fontId == font.id,
                    previewStyle = type,
                    onSelect = { update { it.withFont(font.id) } },
                )
                if (index != FontOptions.all.lastIndex) HorizontalDivider()
            }
        }

        SectionTitle("Sizes")
        SettingsCard {
            SettingsSliderRow(
                "Home label size", typo.homeLabelSp,
                { v -> update { it.withHomeLabel(v) } },
                TypographyLimits.HOME_LABEL,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withHomeLabel(TypographyLimits.DEFAULT_HOME_LABEL) } },
            )
            SettingsSliderRow(
                "Drawer label size", typo.drawerLabelSp,
                { v -> update { it.withDrawerLabel(v) } },
                TypographyLimits.DRAWER_LABEL,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withDrawerLabel(TypographyLimits.DEFAULT_DRAWER_LABEL) } },
            )
            SettingsSliderRow(
                "Section heading size", typo.sectionHeadingSp,
                { v -> update { it.withHeading(v) } },
                TypographyLimits.SECTION_HEADING,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withHeading(TypographyLimits.DEFAULT_SECTION_HEADING) } },
            )
            SettingsSliderRow(
                "Search text size", typo.searchTextSp,
                { v -> update { it.withSearch(v) } },
                TypographyLimits.SEARCH,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withSearch(TypographyLimits.DEFAULT_SEARCH) } },
            )
            SettingsSliderRow(
                "Clock size", typo.clockSp,
                { v -> update { it.withClock(v) } },
                TypographyLimits.CLOCK,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withClock(TypographyLimits.DEFAULT_CLOCK) } },
            )
            SettingsSliderRow(
                "Date size", typo.dateSp,
                { v -> update { it.withDate(v) } },
                TypographyLimits.DATE,
                valueLabel = { "${it.toInt()} sp" },
                onReset = { update { it.withDate(TypographyLimits.DEFAULT_DATE) } },
            )
        }

        SectionTitle("Weight & spacing")
        SettingsCard {
            SettingsSliderRow(
                "Font weight", typo.fontWeight.toFloat(),
                { v -> update { it.withWeight(v.toInt()) } },
                TypographyLimits.FONT_WEIGHT,
                steps = 4,
                valueLabel = { it.toInt().toString() },
                onReset = { update { it.withWeight(TypographyLimits.DEFAULT_FONT_WEIGHT) } },
            )
            SettingsSliderRow(
                "Line spacing multiplier", typo.lineHeightMultiplier,
                { v -> update { it.withLineHeight(v) } },
                TypographyLimits.LINE_HEIGHT,
                valueLabel = { String.format(java.util.Locale.US, "%.2f×", it) },
                onReset = { update { it.withLineHeight(TypographyLimits.DEFAULT_LINE_HEIGHT) } },
            )
            SettingsSliderRow(
                "Letter spacing", typo.letterSpacingEm,
                { v -> update { it.withLetterSpacing(v) } },
                TypographyLimits.LETTER_SPACING,
                valueLabel = { String.format(java.util.Locale.US, "%.2f em", it) },
                onReset = { update { it.withLetterSpacing(TypographyLimits.DEFAULT_LETTER_SPACING) } },
            )
            SettingsSliderRow(
                "Text scaling preview", typo.textScale,
                { v -> update { it.withScale(v) } },
                TypographyLimits.TEXT_SCALE,
                valueLabel = { String.format(java.util.Locale.US, "%.2f×", it) },
                description = "Scales every launcher label without changing system settings",
                onReset = { update { it.withScale(TypographyLimits.DEFAULT_TEXT_SCALE) } },
            )
        }

        SectionTitle("Labels")
        SettingsCard {
            SettingsSwitchRow(
                title = "Show app labels",
                description = "Hide names on the home screen, app drawer and search results",
                checked = prefs.icons.showLabels,
                onCheckedChange = { show ->
                    vm.updatePrefs { it.copy(icons = it.icons.copy(showLabels = show)) }
                },
            )
            SettingsActionRow("Reset all typography", {
                vm.updatePrefs { it.copy(typography = TypographySettings.DEFAULT) }
            }, destructive = true)
        }
        Spacer(Modifier.height(28.dp))
        Text(
            "Fonts are applied to Flex Launcher only. Android does not allow a launcher to change the " +
                "system-wide font.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun FontRow(
    option: FontOption,
    selected: Boolean,
    previewStyle: com.flex.launcher.ui.theme.FlexType,
    onSelect: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val family = option.toFontFamily()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .background(if (selected) colors.primary.copy(alpha = 0.12f) else colors.card.copy(alpha = 0f))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .width(52.dp)
                .height(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, colors.textSecondary.copy(alpha = 0.25f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text("Aa", style = type.body.copy(fontFamily = family, fontSize = 18.sp), color = colors.textPrimary)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                option.displayName,
                style = previewStyle.body.copy(fontFamily = family),
                color = colors.textPrimary,
            )
            Text(
                buildString {
                    append(option.category.label)
                    if (option.source is com.flex.launcher.domain.typography.FontSource.System) {
                        append(" · system family")
                    }
                    if (option.note.isNotBlank()) append(" · ${option.note}")
                },
                style = type.label,
                color = colors.textSecondary,
            )
        }
        if (selected) {
            Text("✓", style = type.body, color = colors.primary)
        }
    }
}
