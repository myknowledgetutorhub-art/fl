package com.flex.launcher.domain.typography

import kotlinx.serialization.Serializable

/** Inclusive numeric bounds for every typography slider. Shared by UI and tests. */
object TypographyLimits {
    val HOME_LABEL = 8f..20f
    val DRAWER_LABEL = 8f..20f
    val SECTION_HEADING = 10f..28f
    val SEARCH = 10f..26f
    val CLOCK = 24f..96f
    val DATE = 8f..24f
    val FONT_WEIGHT = 300f..800f
    val LINE_HEIGHT = 0.8f..1.6f
    val LETTER_SPACING = 0f..0.10f
    val TEXT_SCALE = 0.8f..1.3f

    const val DEFAULT_HOME_LABEL = 12f
    const val DEFAULT_DRAWER_LABEL = 12f
    const val DEFAULT_SECTION_HEADING = 15f
    const val DEFAULT_SEARCH = 16f
    const val DEFAULT_CLOCK = 56f
    const val DEFAULT_DATE = 13f
    const val DEFAULT_FONT_WEIGHT = 500
    const val DEFAULT_LINE_HEIGHT = 1f
    const val DEFAULT_LETTER_SPACING = 0f
    const val DEFAULT_TEXT_SCALE = 1f
}

/**
 * All typography preferences. Values are sanitised on read and on write so a corrupted or
 * out-of-range preference can never break layout.
 */
@Serializable
data class TypographySettings(
    val fontId: String = FontOptions.DEFAULT_ID,
    val homeLabelSp: Float = TypographyLimits.DEFAULT_HOME_LABEL,
    val drawerLabelSp: Float = TypographyLimits.DEFAULT_DRAWER_LABEL,
    val sectionHeadingSp: Float = TypographyLimits.DEFAULT_SECTION_HEADING,
    val searchTextSp: Float = TypographyLimits.DEFAULT_SEARCH,
    val clockSp: Float = TypographyLimits.DEFAULT_CLOCK,
    val dateSp: Float = TypographyLimits.DEFAULT_DATE,
    val fontWeight: Int = TypographyLimits.DEFAULT_FONT_WEIGHT,
    val lineHeightMultiplier: Float = TypographyLimits.DEFAULT_LINE_HEIGHT,
    val letterSpacingEm: Float = TypographyLimits.DEFAULT_LETTER_SPACING,
    val textScale: Float = TypographyLimits.DEFAULT_TEXT_SCALE,
) {
    /** Returns a copy with every field inside its legal range and a known font id. */
    fun sanitized(): TypographySettings = copy(
        fontId = if (FontOptions.exists(fontId)) fontId else FontOptions.DEFAULT_ID,
        homeLabelSp = homeLabelSp.clampTo(TypographyLimits.HOME_LABEL),
        drawerLabelSp = drawerLabelSp.clampTo(TypographyLimits.DRAWER_LABEL),
        sectionHeadingSp = sectionHeadingSp.clampTo(TypographyLimits.SECTION_HEADING),
        searchTextSp = searchTextSp.clampTo(TypographyLimits.SEARCH),
        clockSp = clockSp.clampTo(TypographyLimits.CLOCK),
        dateSp = dateSp.clampTo(TypographyLimits.DATE),
        fontWeight = fontWeight.coerceIn(
            TypographyLimits.FONT_WEIGHT.start.toInt(),
            TypographyLimits.FONT_WEIGHT.endInclusive.toInt(),
        ),
        lineHeightMultiplier = lineHeightMultiplier.clampTo(TypographyLimits.LINE_HEIGHT),
        letterSpacingEm = letterSpacingEm.clampTo(TypographyLimits.LETTER_SPACING),
        textScale = textScale.clampTo(TypographyLimits.TEXT_SCALE),
    )

    // Effective (scale-aware) sizes used by the UI.
    val effectiveHomeLabel: Float get() = homeLabelSp * textScale
    val effectiveDrawerLabel: Float get() = drawerLabelSp * textScale
    val effectiveHeading: Float get() = sectionHeadingSp * textScale
    val effectiveSearch: Float get() = searchTextSp * textScale
    val effectiveClock: Float get() = clockSp * textScale
    val effectiveDate: Float get() = dateSp * textScale

    val font: FontOption get() = FontOptions.byId(fontId)

    fun withHomeLabel(v: Float) = copy(homeLabelSp = v).sanitized()
    fun withDrawerLabel(v: Float) = copy(drawerLabelSp = v).sanitized()
    fun withHeading(v: Float) = copy(sectionHeadingSp = v).sanitized()
    fun withSearch(v: Float) = copy(searchTextSp = v).sanitized()
    fun withClock(v: Float) = copy(clockSp = v).sanitized()
    fun withDate(v: Float) = copy(dateSp = v).sanitized()
    fun withWeight(v: Int) = copy(fontWeight = v).sanitized()
    fun withLineHeight(v: Float) = copy(lineHeightMultiplier = v).sanitized()
    fun withLetterSpacing(v: Float) = copy(letterSpacingEm = v).sanitized()
    fun withScale(v: Float) = copy(textScale = v).sanitized()
    fun withFont(id: String) = copy(fontId = id).sanitized()

    companion object {
        val DEFAULT = TypographySettings()
    }
}

internal fun Float.clampTo(range: ClosedFloatingPointRange<Float>): Float =
    if (isNaN()) range.start else coerceIn(range.start, range.endInclusive)
