package com.flex.launcher.data.prefs

import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import com.flex.launcher.domain.model.LauncherPrefs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json
import java.io.IOException

/**
 * Persists the whole [LauncherPrefs] document as a single JSON value.
 *
 * A single document keeps writes atomic and makes backup/restore a trivial round-trip.
 * Every read is sanitised, so a corrupted or hand-edited file degrades to defaults instead
 * of crashing the launcher.
 */
class PreferencesRepository(
    private val dataStore: DataStore<Preferences>,
    private val json: Json = defaultJson(),
) {

    val preferences: Flow<LauncherPrefs> = dataStore.data
        .catch { throwable ->
            if (throwable is IOException) {
                Log.e(TAG, "Preferences read failed, using defaults", throwable)
                emit(emptyPreferences())
            } else {
                throw throwable
            }
        }
        .map { decode(it[KEY]) }
        .distinctUntilChanged()

    /** Current snapshot; suspends only for the first read. */
    suspend fun current(): LauncherPrefs = preferences.first()

    suspend fun update(transform: (LauncherPrefs) -> LauncherPrefs) {
        dataStore.edit { prefs ->
            val updated = transform(decode(prefs[KEY])).sanitized()
            prefs[KEY] = json.encodeToString(LauncherPrefs.serializer(), updated)
        }
    }

    /** Replaces everything with [prefs] (used by restore). Values are sanitised first. */
    suspend fun replace(prefs: LauncherPrefs) {
        dataStore.edit { target ->
            target[KEY] = json.encodeToString(LauncherPrefs.serializer(), prefs.sanitized())
        }
    }

    /** Resets appearance-related settings but keeps hidden apps, pins and recents choices. */
    suspend fun resetAppearance() = update { current ->
        val defaults = LauncherPrefs.DEFAULT
        current.copy(
            themeId = defaults.themeId,
            customPalette = defaults.customPalette,
            themeMode = defaults.themeMode,
            amoledMode = defaults.amoledMode,
            dynamicColor = defaults.dynamicColor,
            backgroundOpacity = defaults.backgroundOpacity,
            cardCornerRadius = defaults.cardCornerRadius,
            density = defaults.density,
            typography = defaults.typography,
            icons = defaults.icons.copy(
                homeColumns = current.icons.homeColumns,
                drawerColumns = current.icons.drawerColumns,
            ),
            animations = defaults.animations,
            statusBar = defaults.statusBar,
            wallpaperDim = defaults.wallpaperDim,
        )
    }

    /** Full reset, including hidden apps and pins. Onboarding is skipped afterwards. */
    suspend fun resetAll() = replace(LauncherPrefs.DEFAULT.copy(onboardingCompleted = true))

    fun encode(prefs: LauncherPrefs): String = json.encodeToString(LauncherPrefs.serializer(), prefs)

    fun decode(raw: String?): LauncherPrefs {
        if (raw.isNullOrBlank()) return LauncherPrefs.DEFAULT
        return try {
            json.decodeFromString(LauncherPrefs.serializer(), raw).sanitized()
        } catch (e: Exception) {
            Log.w(TAG, "Stored preferences could not be decoded; falling back to defaults", e)
            LauncherPrefs.DEFAULT
        }
    }

    companion object {
        private const val TAG = "PreferencesRepository"
        val KEY = stringPreferencesKey("launcher_prefs_json")

        fun defaultJson(): Json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
            coerceInputValues = true
            prettyPrint = false
        }
    }
}
