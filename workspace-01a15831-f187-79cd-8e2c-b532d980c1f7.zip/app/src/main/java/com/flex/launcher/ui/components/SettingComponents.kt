package com.flex.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors
import kotlin.math.roundToInt

/** Rounded, themed container used by every settings block. */
@Composable
fun SettingsCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    val colors = LocalLauncherColors.current
    val corner = colors.cardCornerRadius
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(corner))
            .background(colors.card.copy(alpha = 0.86f))
            .padding(vertical = 4.dp),
        content = content,
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    val colors = LocalLauncherColors.current
    Text(
        text = text.uppercase(),
        style = LocalFlexType.current.label.copy(letterSpacing = 1.2.sp),
        color = colors.textSecondary,
        fontWeight = FontWeight.SemiBold,
        modifier = modifier.padding(start = 8.dp, top = 18.dp, bottom = 8.dp),
    )
}

@Composable
fun SettingsHeader(text: String, modifier: Modifier = Modifier) {
    val colors = LocalLauncherColors.current
    Text(
        text = text,
        style = LocalFlexType.current.heading,
        color = colors.textPrimary,
        modifier = modifier.padding(start = 8.dp, top = 6.dp, bottom = 6.dp),
    )
}

@Composable
fun SettingsSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    description: String? = null,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = type.body,
                color = if (enabled) colors.textPrimary else colors.textSecondary.copy(alpha = 0.6f),
            )
            if (description != null) {
                Spacer(Modifier.height(2.dp))
                Text(description, style = type.label, color = colors.textSecondary)
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = colors.background,
                checkedTrackColor = colors.primary,
                uncheckedThumbColor = colors.textSecondary,
                uncheckedTrackColor = colors.card,
            ),
        )
    }
}

@Composable
fun SettingsActionRow(
    title: String,
    onClick: () -> Unit,
    description: String? = null,
    trailingText: String? = null,
    enabled: Boolean = true,
    destructive: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = type.body,
                color = when {
                    !enabled -> colors.textSecondary.copy(alpha = 0.5f)
                    destructive -> Color(0xFFEF5350)
                    else -> colors.textPrimary
                },
            )
            if (description != null) {
                Spacer(Modifier.height(2.dp))
                Text(description, style = type.label, color = colors.textSecondary)
            }
        }
        if (trailingText != null) {
            Text(trailingText, style = type.label, color = colors.textSecondary)
            Spacer(Modifier.width(6.dp))
        }
        Icon(
            Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = colors.textSecondary.copy(alpha = if (enabled) 0.8f else 0.3f),
        )
    }
}

@Composable
fun SettingsSliderRow(
    title: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    valueLabel: (Float) -> String = { "%.0f".format(it) },
    description: String? = null,
    onReset: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = type.body, color = colors.textPrimary, modifier = Modifier.weight(1f))
            Text(valueLabel(value), style = type.label, color = colors.primary)
            if (onReset != null) {
                Spacer(Modifier.width(10.dp))
                Text(
                    "Reset",
                    style = type.label,
                    color = colors.textSecondary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable(onClick = onReset)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        if (description != null) {
            Text(description, style = type.label, color = colors.textSecondary)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = colors.primary,
                activeTrackColor = colors.primary,
                inactiveTrackColor = colors.textSecondary.copy(alpha = 0.25f),
            ),
        )
    }
}

/** Segmented control built from simple text chips (accessible 48dp touch targets). */
@Composable
fun <T> SegmentedChoice(
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) colors.primary else colors.card)
                    .clickable { onSelect(option) }
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label(option),
                    style = type.label,
                    color = if (isSelected) com.flex.launcher.ui.theme.contrastOn(colors.primary) else colors.textPrimary,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
fun ValueChip(text: String, modifier: Modifier = Modifier) {
    val colors = LocalLauncherColors.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(colors.card)
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
    }
}

/** Formats a float for a slider read-out. */
fun formatOneDecimal(value: Float): String = "%.1f".format(value)

fun formatPercent(value: Float): String = "${value.roundToInt()}%"

fun iconSizeDp(size: Float): String = "${size.roundToInt()} dp"
