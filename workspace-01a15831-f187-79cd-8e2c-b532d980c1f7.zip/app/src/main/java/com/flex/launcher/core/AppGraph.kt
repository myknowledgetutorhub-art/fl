package com.flex.launcher.core

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStoreFile
import com.flex.launcher.data.apps.AppIconLoader
import com.flex.launcher.data.apps.AppRepository
import com.flex.launcher.data.prefs.PreferencesRepository
import com.flex.launcher.data.prefs.RecentAppsStore
import com.flex.launcher.data.recents.UsageStatsSource
import com.flex.launcher.data.wallpaper.WallpaperColorSource
import com.flex.launcher.launcher.LauncherActions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.plus

/**
 * Small manual dependency container. A full DI framework would be overkill for a single
 * module app; this keeps the graph explicit, testable and free of reflection.
 */
class AppGraph(context: Context) {

    val applicationContext: Context = context.applicationContext

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val preferenceStore: DataStore<Preferences> = PreferenceDataStoreFactory.create(
        scope = appScope + Dispatchers.IO,
        produceFile = { applicationContext.preferencesDataStoreFile("flex_launcher_prefs") },
    )

    private val recentStoreDataStore: DataStore<Preferences> = PreferenceDataStoreFactory.create(
        scope = appScope + Dispatchers.IO,
        produceFile = { applicationContext.preferencesDataStoreFile("flex_launcher_recents") },
    )

    val preferences: PreferencesRepository = PreferencesRepository(preferenceStore)

    val recentAppsStore: RecentAppsStore = RecentAppsStore(recentStoreDataStore)

    val appRepository: AppRepository = AppRepository(applicationContext, appScope)

    val iconLoader: AppIconLoader = AppIconLoader(appRepository)

    val usageStats: UsageStatsSource = UsageStatsSource(applicationContext)

    val wallpaperColors: WallpaperColorSource = WallpaperColorSource(applicationContext)

    val actions: LauncherActions = LauncherActions(applicationContext, appRepository, recentAppsStore)
}
