package com.flex.launcher.domain.model

import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.icons.IconSettings
import com.flex.launcher.domain.theme.ThemePalette
import com.flex.launcher.domain.typography.TypographySettings
import kotlinx.serialization.Serializable

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class LayoutDensity(val label: String, val spacingScale: Float) {
    COMPACT("Compact", 0.8f),
    NORMAL("Normal", 1.0f),
    COMFORTABLE("Comfortable", 1.2f);
}

enum class AppSortMode(val label: String) {
    ALPHABETICAL("Alphabetical"),
    RECENT("Recently used"),
}

enum class StatusBarIconMode(val label: String) {
    AUTO("Automatic"),
    DARK("Dark icons"),
    LIGHT("Light icons"),
}

@Serializable
data class RecentSettings(
    val enabled: Boolean = true,
    val maxItems: Int = 6,
    val useUsageAccess: Boolean = true,
    val showOnHome: Boolean = false,
) {
    fun sanitized() = copy(maxItems = maxItems.coerceIn(MIN_ITEMS, MAX_ITEMS))

    companion object {
        const val MIN_ITEMS = 3
        const val MAX_ITEMS = 12
        val ITEMS_RANGE = MIN_ITEMS..MAX_ITEMS
        val DEFAULT = RecentSettings()
    }
}

@Serializable
data class HomeSettings(
    val clockEnabled: Boolean = true,
    val dateEnabled: Boolean = true,
    val use24Hour: Boolean = false,
    val showHomeGrid: Boolean = true,
    val pinnedApps: List<String> = emptyList(),
) {
    companion object {
        val DEFAULT = HomeSettings()
    }
}

@Serializable
data class DrawerSettings(
    val sortMode: AppSortMode = AppSortMode.ALPHABETICAL,
    val showRecents: Boolean = true,
    val showAllAppsHeader: Boolean = true,
) {
    companion object {
        val DEFAULT = DrawerSettings()
    }
}

@Serializable
data class StatusBarSettings(
    val iconMode: StatusBarIconMode = StatusBarIconMode.AUTO,
    val showScrim: Boolean = false,
    val scrimAlpha: Float = 0.35f,
) {
    fun sanitized() = copy(scrimAlpha = if (scrimAlpha.isNaN()) 0.35f else scrimAlpha.coerceIn(0f, 0.8f))

    companion object {
        val SCRIM_RANGE = 0f..0.8f
        val DEFAULT = StatusBarSettings()
    }
}

/**
 * Single source of truth for every persisted launcher preference. Serialised to JSON in
 * DataStore so backup/restore and tests operate on one typed model.
 */
@Serializable
data class LauncherPrefs(
    val schemaVersion: Int = 1,
    val themeId: String = "midnight_black",
    val customPalette: ThemePalette = ThemePalette.DEFAULT,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val amoledMode: Boolean = false,
    val dynamicColor: Boolean = false,
    val backgroundOpacity: Float = 100f,
    val cardCornerRadius: Float = 20f,
    val density: LayoutDensity = LayoutDensity.NORMAL,
    val typography: TypographySettings = TypographySettings.DEFAULT,
    val icons: IconSettings = IconSettings.DEFAULT,
    val animations: AnimationSettings = AnimationSettings.DEFAULT,
    val recents: RecentSettings = RecentSettings.DEFAULT,
    val home: HomeSettings = HomeSettings.DEFAULT,
    val drawer: DrawerSettings = DrawerSettings.DEFAULT,
    val hiddenApps: Set<String> = emptySet(),
    val statusBar: StatusBarSettings = StatusBarSettings.DEFAULT,
    val hapticsEnabled: Boolean = true,
    val wallpaperDim: Float = 0f,
    val onboardingCompleted: Boolean = false,
) {
    /** Forces every value into its legal range; safe to call on untrusted (imported) data. */
    fun sanitized(): LauncherPrefs = copy(
        backgroundOpacity = backgroundOpacity.orDefault(100f).coerceIn(0f, 100f),
        cardCornerRadius = cardCornerRadius.orDefault(20f).coerceIn(0f, 36f),
        wallpaperDim = wallpaperDim.orDefault(0f).coerceIn(0f, 80f),
        typography = typography.sanitized(),
        icons = icons.sanitized(),
        animations = animations.sanitized(),
        recents = recents.sanitized(),
        statusBar = statusBar.sanitized(),
        hiddenApps = hiddenApps.filter { it.isNotBlank() }.toSet(),
    )

    companion object {
        val CARD_RADIUS_RANGE = 0f..36f
        val WALLPAPER_DIM_RANGE = 0f..80f
        val BACKGROUND_OPACITY_RANGE = 0f..100f
        val DEFAULT = LauncherPrefs()
    }
}

private fun Float.orDefault(fallback: Float): Float = if (isNaN()) fallback else this
