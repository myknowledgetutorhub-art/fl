package com.flex.launcher.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import com.flex.launcher.core.util.ColorMath
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.StatusBarIconMode
import com.flex.launcher.domain.model.ThemeMode
import com.flex.launcher.domain.theme.GradientDirection
import com.flex.launcher.domain.theme.ThemePalette
import com.flex.launcher.domain.theme.ThemePresets

/** Resolved, Compose-ready colour set for the launcher UI. */
@Immutable
data class LauncherColors(
    val background: Color,
    val backgroundGradient: List<Color>,
    val gradientDirection: GradientDirection,
    val surface: Color,
    val card: Color,
    val primary: Color,
    val secondary: Color,
    val accent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val isLight: Boolean,
    val statusBarIconsDark: Boolean,
    val backgroundOpacity: Float,
    val cardCornerRadius: androidx.compose.ui.unit.Dp = 20.dp,
) {
    /** Surface colour that already accounts for the background opacity. */
    val drawerSurface: Color get() = surface.copy(alpha = (backgroundOpacity / 100f).coerceIn(0.35f, 1f))
    val cardOpaque: Color get() = card
}

/** True when the system is currently in dark mode. */
fun isSystemDark(prefs: LauncherPrefs, systemDark: Boolean): Boolean = when (prefs.themeMode) {
    ThemeMode.DARK -> true
    ThemeMode.LIGHT -> false
    ThemeMode.SYSTEM -> systemDark
}

/**
 * Turns preferences into concrete colours: preset or custom palette, light/dark/AMOLED
 * overrides, optional Material You dynamic colours and the wallpaper-derived palette.
 */
fun resolveLauncherColors(
    prefs: LauncherPrefs,
    systemDark: Boolean,
    wallpaperPalette: ThemePalette?,
    dynamicScheme: ColorScheme?,
): LauncherColors {
    val base: ThemePalette = when (prefs.themeId) {
        ThemePresets.CUSTOM_ID -> prefs.customPalette
        ThemePresets.SYSTEM_ID, "wallpaper" -> wallpaperPalette
            ?: ThemePresets.byId("midnight_black").palette
        else -> ThemePresets.byId(prefs.themeId).palette
    }

    val wantDark = isSystemDark(prefs, systemDark)
    var palette = if (wantDark) {
        if (base.isLight) base.toDarkVariant() else base
    } else {
        if (base.isLight) base else base.toLightVariant()
    }

    if (prefs.amoledMode && wantDark) {
        palette = palette.copy(
            background = 0xFF000000.toInt(),
            surface = ColorMath.blend(0xFF000000.toInt(), palette.surface, 0.25f),
            card = ColorMath.blend(0xFF000000.toInt(), palette.card, 0.35f),
        )
    }

    var primary = palette.primary
    var secondary = palette.secondary
    var accent = palette.accent
    var surface = palette.surface
    var card = palette.card
    var background = palette.background

    if (prefs.dynamicColor && dynamicScheme != null) {
        primary = dynamicScheme.primary.toArgb()
        secondary = dynamicScheme.secondary.toArgb()
        accent = dynamicScheme.tertiary.toArgb()
        surface = dynamicScheme.surface.toArgb()
        card = dynamicScheme.surfaceVariant.toArgb()
        background = dynamicScheme.background.toArgb()
    }

    val backgroundCompose = Color(background)
    val textPrimary = Color(palette.readableText(background))
    val textSecondary = Color(palette.readableSecondaryText(background))

    val iconsDark = when (prefs.statusBar.iconMode) {
        StatusBarIconMode.AUTO -> backgroundCompose.luminance() > 0.5f
        StatusBarIconMode.DARK -> true
        StatusBarIconMode.LIGHT -> false
    }

    return LauncherColors(
        background = backgroundCompose,
        backgroundGradient = palette.gradient.map { Color(it) },
        gradientDirection = palette.direction,
        surface = Color(surface),
        card = Color(card),
        primary = Color(primary),
        secondary = Color(secondary),
        accent = Color(accent),
        textPrimary = textPrimary,
        textSecondary = textSecondary,
        isLight = !wantDark,
        statusBarIconsDark = iconsDark,
        backgroundOpacity = prefs.backgroundOpacity,
        cardCornerRadius = prefs.cardCornerRadius.dp,
    )
}

/** Material 3 colour scheme derived from the launcher colours, so widgets stay themed. */
fun LauncherColors.toMaterialColorScheme(): ColorScheme {
    val onSurface = textPrimary
    val base = if (isLight) {
        lightColorScheme(
            primary = primary,
            onPrimary = contrastOn(primary),
            secondary = secondary,
            onSecondary = contrastOn(secondary),
            tertiary = accent,
            onTertiary = contrastOn(accent),
            background = background,
            onBackground = onSurface,
            surface = surface,
            onSurface = onSurface,
            surfaceVariant = card,
            onSurfaceVariant = textSecondary,
            outline = textSecondary.copy(alpha = 0.6f),
        )
    } else {
        darkColorScheme(
            primary = primary,
            onPrimary = contrastOn(primary),
            secondary = secondary,
            onSecondary = contrastOn(secondary),
            tertiary = accent,
            onTertiary = contrastOn(accent),
            background = background,
            onBackground = onSurface,
            surface = surface,
            onSurface = onSurface,
            surfaceVariant = card,
            onSurfaceVariant = textSecondary,
            outline = textSecondary.copy(alpha = 0.6f),
        )
    }
    return base
}

/** Picks black or white text for a filled component of [color]. */
fun contrastOn(color: Color): Color =
    if (color.luminance() > 0.45f) Color(0xFF101319) else Color.White
