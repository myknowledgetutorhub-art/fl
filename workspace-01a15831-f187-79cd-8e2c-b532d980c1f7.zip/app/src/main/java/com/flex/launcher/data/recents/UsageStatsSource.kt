package com.flex.launcher.data.recents

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Thin, defensive wrapper around [UsageStatsManager].
 *
 * Platform reality (documented in the README): UsageStats does not expose the system Recents
 * screen, and it only reports what the platform recorded. Timestamps can be coarse or missing
 * for apps that were never opened since the stats window began.
 */
class UsageStatsSource(private val context: Context) {

    private val manager: UsageStatsManager?
        get() = runCatching {
            context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
        }.getOrNull()

    /** True when the user granted "Usage access" to this app in system settings. */
    fun hasPermission(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName,
                )
            }
        }.getOrNull() ?: return false
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Returns `packageName -> last time the app moved to the foreground`, newest first.
     * Empty map when permission is missing or the platform returns nothing.
     */
    suspend fun lastUsed(days: Int = 14): Map<String, Long> = withContext(Dispatchers.IO) {
        if (!hasPermission()) return@withContext emptyMap()
        val service = manager ?: return@withContext emptyMap()
        val end = System.currentTimeMillis()
        val start = end - days.coerceIn(1, 90) * DAY_MS
        val result = HashMap<String, Long>()
        try {
            val events = service.queryEvents(start, end)
            val event = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val type = event.eventType
                @Suppress("DEPRECATION")
                val isForeground = type == UsageEvents.Event.ACTIVITY_RESUMED ||
                    (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                        type == UsageEvents.Event.MOVE_TO_FOREGROUND)
                if (isForeground) {
                    val pkg = event.packageName ?: continue
                    if (pkg.isBlank() || pkg == context.packageName) continue
                    val ts = event.timeStamp
                    if ((result[pkg] ?: 0L) < ts) result[pkg] = ts
                }
            }
            if (result.isEmpty()) {
                // Some OEM builds emit no activity events; aggregate stats still carry
                // lastTimeUsed, which is a reasonable (if coarser) ordering signal.
                service.queryUsageStats(UsageStatsManager.INTERVAL_WEEKLY, start, end)?.forEach { stat ->
                    val pkg = stat.packageName ?: return@forEach
                    if (pkg.isBlank() || pkg == context.packageName) return@forEach
                    val ts = stat.lastTimeUsed
                    if (ts > (result[pkg] ?: 0L)) result[pkg] = ts
                }
            }
        } catch (e: Exception) {
            // SecurityException when access was revoked mid-flight; never crash the launcher.
            Log.w(TAG, "UsageStats query failed", e)
            return@withContext emptyMap()
        }
        result
    }

    /** Intent that opens the system "Usage access" screen, or null when unavailable. */
    fun settingsIntent(): Intent? {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) intent else null
    }

    companion object {
        private const val TAG = "UsageStatsSource"
        private const val DAY_MS = 24L * 60L * 60L * 1000L
    }
}
