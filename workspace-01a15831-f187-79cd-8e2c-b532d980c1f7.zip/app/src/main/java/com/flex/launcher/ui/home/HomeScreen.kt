package com.flex.launcher.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.theme.GradientDirection
import com.flex.launcher.ui.components.AppIcon
import com.flex.launcher.ui.components.EmptyState
import com.flex.launcher.ui.components.clickableNoRipple
import com.flex.launcher.ui.theme.FlexType
import com.flex.launcher.ui.theme.LocalAnimationSettings
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors
import com.flex.launcher.ui.theme.LauncherColors
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Wallpaper-visible background: theme colour at the configured opacity, plus gradient + dim. */
@Composable
fun LauncherBackground(prefs: LauncherPrefs, colors: LauncherColors, modifier: Modifier = Modifier) {
    val opacity = (prefs.backgroundOpacity / 100f).coerceIn(0f, 1f)
    val animations = LocalAnimationSettings.current
    val themeSpec = if (animations.motionAllowed) {
        androidx.compose.animation.core.tween<androidx.compose.ui.graphics.Color>(
            durationMillis = animations.duration(320),
        )
    } else {
        androidx.compose.animation.core.snap()
    }
    val animatedBackground by androidx.compose.animation.animateColorAsState(
        targetValue = colors.background.copy(alpha = opacity),
        animationSpec = themeSpec,
        label = "launcher-background",
    )
    Box(modifier.fillMaxSize()) {
        val brush = when {
            colors.backgroundGradient.size >= 2 -> when (colors.gradientDirection) {
                GradientDirection.TOP_BOTTOM -> Brush.verticalGradient(colors.backgroundGradient)
                GradientDirection.BOTTOM_TOP -> Brush.verticalGradient(colors.backgroundGradient.reversed())
                GradientDirection.LEFT_RIGHT -> Brush.horizontalGradient(colors.backgroundGradient)
                GradientDirection.DIAGONAL -> Brush.linearGradient(colors.backgroundGradient)
                GradientDirection.RADIAL -> Brush.radialGradient(colors.backgroundGradient)
                GradientDirection.NONE -> null
            }
            else -> null
        }
        if (brush != null) {
            Box(Modifier.fillMaxSize().background(brush).background(colors.background.copy(alpha = opacity * 0.55f)))
        } else {
            Box(Modifier.fillMaxSize().background(animatedBackground))
        }
        if (prefs.wallpaperDim > 0f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = (prefs.wallpaperDim / 100f).coerceIn(0f, 0.8f))),
            )
        }
    }
}

/** Live clock/date widget. Updates once a minute — no continuous animation. */
@Composable
fun ClockWidget(
    use24Hour: Boolean,
    showDate: Boolean,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(15_000L)
            now = LocalDateTime.now()
        }
    }
    val timeFormatter = remember(use24Hour) {
        DateTimeFormatter.ofPattern(if (use24Hour) "HH:mm" else "h:mm", Locale.getDefault())
    }
    val dateFormatter = remember {
        DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.getDefault())
    }
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = now.format(timeFormatter),
            style = type.clock,
            color = colors.textPrimary,
            maxLines = 1,
        )
        if (showDate) {
            Text(
                text = now.format(dateFormatter),
                style = type.date,
                color = colors.textSecondary,
                maxLines = 1,
            )
        }
    }
}

/** A home-screen app tile (icon + optional label). */
@Composable
fun HomeAppTile(
    entry: AppEntry,
    prefs: LauncherPrefs,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickableNoRipple(onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        AppIcon(
            entry = entry,
            size = prefs.icons.sizeDp.dp,
            shape = IconShape.fromId(prefs.icons.shapeId),
            showPlate = prefs.icons.backgroundPlate,
            plateColor = Color(prefs.icons.backgroundPlateColor),
        )
        if (prefs.icons.showLabels) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = entry.label,
                style = type.homeLabel,
                color = colors.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** Compact recent-apps strip shown on the home surface when enabled. */
@Composable
fun HomeRecentRow(
    recents: List<com.flex.launcher.domain.model.RecentApp>,
    prefs: LauncherPrefs,
    onLaunch: (AppEntry) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column(modifier.fillMaxWidth()) {
        Text(
            "Recently used",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
        )
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(prefs.icons.spacingDp.dp),
            contentPadding = PaddingValues(horizontal = 2.dp),
        ) {
            items(recents, key = { it.app.key }) { recent ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(64.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickableNoRipple { onLaunch(recent.app) }
                        .padding(vertical = 4.dp),
                ) {
                    AppIcon(
                        entry = recent.app,
                        size = (prefs.icons.sizeDp * 0.8f).dp,
                        shape = IconShape.fromId(prefs.icons.shapeId),
                        showPlate = prefs.icons.backgroundPlate,
                        plateColor = Color(prefs.icons.backgroundPlateColor),
                    )
                    Text(
                        recent.app.label,
                        style = type.label,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        }
    }
}

data class HomeCallbacks(
    val onLaunch: (AppEntry) -> Unit,
    val onOpenDrawer: () -> Unit,
    val onOpenSettings: () -> Unit,
    val onOpenDialer: () -> Unit,
    val onSetDefaultLauncher: () -> Unit,
)

/** The launcher home surface. */
@Composable
fun HomeScreen(
    prefs: LauncherPrefs,
    colors: LauncherColors,
    pinned: List<AppEntry>,
    recents: List<com.flex.launcher.domain.model.RecentApp> = emptyList(),
    isDefaultLauncher: Boolean,
    loadingApps: Boolean,
    callbacks: HomeCallbacks,
    modifier: Modifier = Modifier,
) {
    val type = LocalFlexType.current
    val configuration = LocalConfiguration.current
    val spacing = (prefs.icons.spacingDp * prefs.density.spacingScale).dp
    val wideLayout = configuration.screenWidthDp >= 600
    var swipeDistance by remember { mutableStateOf(0f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { swipeDistance = 0f },
                    onDragEnd = {
                        if (swipeDistance < -80f) callbacks.onOpenDrawer()
                        swipeDistance = 0f
                    },
                ) { _, dragAmount ->
                    swipeDistance += dragAmount
                }
            }
            .padding(horizontal = if (wideLayout) 40.dp else 16.dp),
    ) {
        // Top row: default-launcher hint + settings/dialer shortcuts
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (!isDefaultLauncher) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(colors.card.copy(alpha = 0.9f))
                        .clickableNoRipple(callbacks.onSetDefaultLauncher)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Filled.Warning,
                        contentDescription = null,
                        tint = colors.accent,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("Set as default", style = type.label, color = colors.textPrimary)
                }
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = callbacks.onOpenDialer) {
                Icon(Icons.Filled.Phone, contentDescription = "Open dial pad", tint = colors.textSecondary)
            }
            IconButton(onClick = callbacks.onOpenSettings) {
                Icon(Icons.Filled.Settings, contentDescription = "Launcher settings", tint = colors.textSecondary)
            }
        }

        Spacer(Modifier.height(if (wideLayout) 64.dp else 36.dp))

        if (prefs.home.clockEnabled || prefs.home.dateEnabled) {
            ClockWidget(
                use24Hour = prefs.home.use24Hour,
                showDate = prefs.home.dateEnabled,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(if (wideLayout) 48.dp else 28.dp))
        }

        if (prefs.recents.enabled && prefs.recents.showOnHome && recents.isNotEmpty()) {
            HomeRecentRow(recents = recents, prefs = prefs, onLaunch = callbacks.onLaunch)
            Spacer(Modifier.height(14.dp))
        }

        if (prefs.home.showHomeGrid) {
            if (pinned.isEmpty()) {
                EmptyState(
                    title = "Your home screen is empty",
                    message = if (loadingApps) {
                        "Reading installed apps…"
                    } else {
                        "Open the app drawer, long-press an app and choose “Pin to home” to add shortcuts here."
                    },
                    actionLabel = "Open app drawer",
                    onAction = callbacks.onOpenDrawer,
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(prefs.icons.homeColumns),
                    contentPadding = PaddingValues(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(spacing),
                    verticalArrangement = Arrangement.spacedBy(spacing),
                    modifier = Modifier.weight(1f),
                ) {
                    items(pinned, key = { it.key }) { entry ->
                        HomeAppTile(
                            entry = entry,
                            prefs = prefs,
                            onClick = { callbacks.onLaunch(entry) },
                        )
                    }
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        Spacer(Modifier.weight(1f))

        // Bottom bar: drawer handle + search entry point
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(colors.card.copy(alpha = 0.9f))
                    .clickableNoRipple(callbacks.onOpenDrawer)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Search apps",
                    style = type.search,
                    color = colors.textSecondary,
                )
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(colors.primary.copy(alpha = 0.92f))
                    .clickableNoRipple(callbacks.onOpenDrawer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.Add,
                    contentDescription = "Open app drawer",
                    tint = colors.background,
                )
            }
        }
    }
}
