package com.flex.launcher.core.util

/**
 * Strict HEX colour parsing/formatting used by the Theme Studio.
 *
 * Supported inputs (whitespace and a leading '#' are tolerated):
 *  - `#RGB`        (shorthand, expanded to `#RRGGBB`)
 *  - `#RRGGBB`     (opaque colour)
 *  - `#AARRGGBB`   (colour with alpha, Android ordering)
 *
 * Colours are represented as ARGB [Int] values throughout the app.
 */
object HexColor {

    private val SHORT = Regex("^#?[0-9a-fA-F]{3}$")
    private val RGB = Regex("^#?[0-9a-fA-F]{6}$")
    private val ARGB = Regex("^#?[0-9a-fA-F]{8}$")

    /** True when [raw] is a colour this app can parse. */
    fun isValid(raw: String): Boolean {
        val v = raw.trim()
        return SHORT.matches(v) || RGB.matches(v) || ARGB.matches(v)
    }

    /**
     * Parses [raw] into an ARGB int, or `null` when the input is not a valid colour.
     * Never throws.
     */
    fun parse(raw: String?): Int? {
        if (raw == null) return null
        val value = raw.trim()
        if (!isValid(value)) return null
        val hex = value.removePrefix("#")
        return try {
            when (hex.length) {
                3 -> {
                    val r = hex[0].digitToInt(16)
                    val g = hex[1].digitToInt(16)
                    val b = hex[2].digitToInt(16)
                    argb(255, r * 17, g * 17, b * 17)
                }
                6 -> argb(255, hex.substring(0, 2).toInt(16), hex.substring(2, 4).toInt(16), hex.substring(4, 6).toInt(16))
                8 -> hex.toLong(16).toInt()
                else -> null
            }
        } catch (_: NumberFormatException) {
            null
        }
    }

    /** Returns `#RRGGBB` (or `#AARRGGBB` when [includeAlpha] is set). */
    fun format(color: Int, includeAlpha: Boolean = false): String {
        val a = (color ushr 24) and 0xFF
        val r = (color ushr 16) and 0xFF
        val g = (color ushr 8) and 0xFF
        val b = color and 0xFF
        return if (includeAlpha) {
            String.format(java.util.Locale.US, "#%02X%02X%02X%02X", a, r, g, b)
        } else {
            String.format(java.util.Locale.US, "#%02X%02X%02X", r, g, b)
        }
    }

    /** Parses [raw] and returns its canonical `#RRGGBB` form, or `null` when invalid. */
    fun normalize(raw: String?): String? = parse(raw)?.let { format(it) }

    private fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        (a shl 24) or (r shl 16) or (g shl 8) or b
}

/** Perceptual helpers used to guarantee readable themes and status-bar icon contrast. */
object ColorMath {

    /** Relative luminance per WCAG 2.1. [color] is opaque ARGB. */
    fun relativeLuminance(color: Int): Double {
        fun channel(c: Int): Double {
            val s = c / 255.0
            return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
        }
        val r = channel((color ushr 16) and 0xFF)
        val g = channel((color ushr 8) and 0xFF)
        val b = channel(color and 0xFF)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    /** WCAG contrast ratio between two opaque colours (1.0 .. 21.0). */
    fun contrastRatio(a: Int, b: Int): Double {
        val la = relativeLuminance(a)
        val lb = relativeLuminance(b)
        val lighter = maxOf(la, lb)
        val darker = minOf(la, lb)
        return (lighter + 0.05) / (darker + 0.05)
    }

    /** True when a colour is "dark" and therefore needs light content on top of it. */
    fun isDark(color: Int): Boolean = relativeLuminance(color) < 0.45

    /** Blends [overlay] onto [base] using [alpha] in 0f..1f (result is opaque). */
    fun blend(base: Int, overlay: Int, alpha: Float): Int {
        val a = alpha.coerceIn(0f, 1f)
        fun mix(bc: Int, oc: Int): Int = ((oc * a) + (bc * (1f - a))).toInt().coerceIn(0, 255)
        val r = mix((base ushr 16) and 0xFF, (overlay ushr 16) and 0xFF)
        val g = mix((base ushr 8) and 0xFF, (overlay ushr 8) and 0xFF)
        val b = mix(base and 0xFF, overlay and 0xFF)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    /** Returns [preferred] when it has at least [minRatio] contrast on [background], else white/black. */
    fun ensureContrast(background: Int, preferred: Int, minRatio: Double = 4.5): Int {
        if (contrastRatio(background, preferred) >= minRatio) return preferred
        val light = 0xFFFFFFFF.toInt()
        val dark = 0xFF101114.toInt()
        return if (contrastRatio(background, light) >= contrastRatio(background, dark)) light else dark
    }
}
