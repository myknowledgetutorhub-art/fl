package com.flex.launcher.data.prefs

import com.flex.launcher.domain.model.LauncherPrefs
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/** Marker stored in every backup file so a random JSON file can never be applied. */
const val FLEX_BACKUP_TAG = "Flex Launcher"

@Serializable
data class BackupPayload(
    val app: String = FLEX_BACKUP_TAG,
    val schemaVersion: Int = 1,
    val exportedAtEpochMillis: Long = 0L,
    val prefs: LauncherPrefs = LauncherPrefs.DEFAULT,
    val recentHistory: Map<String, Long> = emptyMap(),
)

/** JSON export/import of launcher preferences (manual, file-based backup). */
object BackupCodec {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = true
        coerceInputValues = true
    }

    fun encode(payload: BackupPayload): String =
        json.encodeToString(BackupPayload.serializer(), payload)

    /**
     * Parses and validates a backup file. A structurally valid JSON document that is *not*
     * a Flex Launcher backup (no `app` marker and no `prefs` object) is rejected instead of
     * silently overwriting the user's settings with defaults.
     */
    fun decode(text: String): Result<BackupPayload> {
        return try {
        val root = json.parseToJsonElement(text) as? kotlinx.serialization.json.JsonObject
            ?: return Result.failure(IllegalArgumentException("That file is not a Flex Launcher backup"))
        if (!root.containsKey("prefs") || !root.containsKey("app")) {
            return Result.failure(IllegalArgumentException("That file is not a Flex Launcher backup"))
        }
        if (root["app"]?.toString()?.trim('"') != FLEX_BACKUP_TAG) {
            return Result.failure(IllegalArgumentException("That backup belongs to a different app"))
        }
        val payload = json.decodeFromString(BackupPayload.serializer(), text)
        if (payload.prefs.schemaVersion > LauncherPrefs.DEFAULT.schemaVersion) {
            Result.failure(IllegalArgumentException("Backup was created by a newer version of Flex Launcher"))
        } else {
            Result.success(payload.copy(prefs = payload.prefs.sanitized()))
        }
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("That file is not a valid Flex Launcher backup", e))
        }
    }
}
