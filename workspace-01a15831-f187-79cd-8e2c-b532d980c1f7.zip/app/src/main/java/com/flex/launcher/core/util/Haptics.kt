package com.flex.launcher.core.util

import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView

/** Small wrapper so haptic feedback honours the user's preference and never throws. */
class Haptics(private val view: View?) {
    fun tap() {
        val target = view ?: return
        runCatching {
            target.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
    }

    fun longPress() {
        val target = view ?: return
        runCatching {
            target.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
    }
}

@Composable
fun rememberHaptics(enabled: Boolean): Haptics {
    val view = LocalView.current
    return remember(enabled, view) {
        if (enabled) Haptics(view) else Haptics(null)
    }
}
