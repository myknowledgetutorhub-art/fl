package com.flex.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flex.launcher.core.util.HexColor
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.LayoutDensity
import com.flex.launcher.domain.model.ThemeMode
import com.flex.launcher.domain.theme.ThemePresets
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SegmentedChoice
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.components.formatPercent
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/** Theme Studio: 20 presets, custom palette entry point, and theme-level options. */
@Composable
fun ThemeStudioScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
    onEditCustom: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current

    SettingsScaffold(title = "Theme Studio", onBack = onBack, subtitle = "Live preview below") {
        ThemePreviewCard(prefs)

        SectionTitle("Presets")
        ThemePresets.all.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                row.forEach { preset ->
                    PresetTile(
                        title = preset.name,
                        swatch = preset.palette.background,
                        accent = preset.palette.primary,
                        secondary = preset.palette.accent,
                        selected = prefs.themeId == preset.id,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            vm.updatePrefs { it.copy(themeId = preset.id) }
                        },
                    )
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
        }

        SectionTitle("Advanced")
        SettingsCard {
            SettingsActionRow(
                "Custom theme${if (prefs.themeId == ThemePresets.CUSTOM_ID) " (active)" else ""}",
                onEditCustom,
                "Pick every colour, gradient and surface yourself",
            )
            SettingsActionRow(
                "Wallpaper colours${if (prefs.themeId == "wallpaper") " (active)" else ""}",
                {
                    vm.updatePrefs { it.copy(themeId = "wallpaper") }
                    vm.postMessage("Deriving colours from your wallpaper…")
                },
                "Derive a palette from the current wallpaper",
            )
            SettingsSwitchRow(
                title = "Pure AMOLED black",
                description = "Force a #000000 background in dark mode (saves power on OLED)",
                checked = prefs.amoledMode,
                onCheckedChange = { enabled -> vm.updatePrefs { it.copy(amoledMode = enabled) } },
            )
            SettingsSwitchRow(
                title = "Material You colours",
                description = "Use Android 12+ system dynamic colours (overrides preset colours)",
                checked = prefs.dynamicColor,
                onCheckedChange = { enabled -> vm.updatePrefs { it.copy(dynamicColor = enabled) } },
            )
        }

        SectionTitle("Mode")
        SegmentedChoice(
            options = ThemeMode.entries,
            selected = prefs.themeMode,
            onSelect = { mode -> vm.updatePrefs { it.copy(themeMode = mode) } },
            label = { mode -> mode.name.lowercase().replaceFirstChar { it.uppercase() } },
        )
        SegmentedChoice(
            options = LayoutDensity.entries,
            selected = prefs.density,
            onSelect = { density -> vm.updatePrefs { it.copy(density = density) } },
            label = { it.label },
        )

        SectionTitle("Surfaces")
        SettingsCard {
            SettingsSliderRow(
                title = "Background opacity",
                value = prefs.backgroundOpacity,
                onValueChange = { v -> vm.updatePrefs { it.copy(backgroundOpacity = v) } },
                range = LauncherPrefs.BACKGROUND_OPACITY_RANGE,
                valueLabel = ::formatPercent,
                description = "Lower values let the system wallpaper show through",
                onReset = { vm.updatePrefs { it.copy(backgroundOpacity = 100f) } },
            )
            SettingsSliderRow(
                title = "Corner radius",
                value = prefs.cardCornerRadius,
                onValueChange = { v -> vm.updatePrefs { it.copy(cardCornerRadius = v) } },
                range = LauncherPrefs.CARD_RADIUS_RANGE,
                valueLabel = { "${it.toInt()} dp" },
                onReset = { vm.updatePrefs { it.copy(cardCornerRadius = 20f) } },
            )
            SettingsSliderRow(
                title = "Wallpaper dim",
                value = prefs.wallpaperDim,
                onValueChange = { v -> vm.updatePrefs { it.copy(wallpaperDim = v) } },
                range = LauncherPrefs.WALLPAPER_DIM_RANGE,
                valueLabel = ::formatPercent,
                description = "Darkens the wallpaper to improve icon legibility",
                onReset = { vm.updatePrefs { it.copy(wallpaperDim = 0f) } },
            )
        }

        Spacer(Modifier.height(24.dp))
        Text(
            "AMOLED, Material You and opacity changes apply to the launcher interface immediately.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(8.dp),
        )
    }
}

@Composable
private fun PresetTile(
    title: String,
    swatch: Int,
    accent: Int,
    secondary: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(colors.card.copy(alpha = 0.9f))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) colors.primary else colors.textSecondary.copy(alpha = 0.2f),
                shape = RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Color(swatch)),
            )
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(14.dp).clip(CircleShape).background(Color(accent)))
            Spacer(Modifier.width(4.dp))
            Box(Modifier.size(14.dp).clip(CircleShape).background(Color(secondary)))
        }
        Spacer(Modifier.height(8.dp))
        Text(
            title,
            style = type.label,
            color = colors.textPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Compact live preview of the launcher surfaces using the *current* preferences. */
@Composable
private fun ThemePreviewCard(prefs: LauncherPrefs) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val opacity = (prefs.backgroundOpacity / 100f).coerceIn(0f, 1f)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xFF2A2F3A))
            .padding(1.dp),
    ) {
        Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(22.dp))) {
            val gradient = colors.backgroundGradient
            if (gradient.size >= 2) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .background(Brush.verticalGradient(gradient)),
                )
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .background(colors.background.copy(alpha = opacity)),
            )
            Column(Modifier.padding(16.dp)) {
                Text("12:45", style = type.clock.copy(fontSize = type.heading.fontSize * 2), color = colors.textPrimary)
                Text("Saturday, 20 October", style = type.date, color = colors.textSecondary)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    repeat(4) { index ->
                        Box(
                            Modifier
                                .size(prefs.icons.sizeDp.dp * 0.62f)
                                .clip(RoundedCornerShape((prefs.cardCornerRadius / 2).dp))
                                .background(
                                    listOf(colors.primary, colors.secondary, colors.accent, colors.card)[index]
                                        .copy(alpha = 0.9f),
                                ),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("App drawer · Recents · Favourites", style = type.label, color = colors.textSecondary)
            }
        }
    }
}
