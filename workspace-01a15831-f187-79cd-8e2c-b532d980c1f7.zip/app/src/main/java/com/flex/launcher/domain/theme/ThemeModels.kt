package com.flex.launcher.domain.theme

import com.flex.launcher.core.util.ColorMath
import kotlinx.serialization.Serializable

/** Direction of the optional background gradient. */
enum class GradientDirection(val label: String) {
    NONE("None"),
    TOP_BOTTOM("Top to bottom"),
    LEFT_RIGHT("Left to right"),
    DIAGONAL("Diagonal"),
    RADIAL("Radial"),
    BOTTOM_TOP("Bottom to top");

    companion object {
        fun fromName(name: String?): GradientDirection =
            entries.firstOrNull { it.name == name } ?: NONE
    }
}

/**
 * The full colour model of the launcher interface. All values are ARGB ints so the
 * model can be persisted, validated, exported to JSON and unit tested without Android.
 */
@Serializable
data class ThemePalette(
    val background: Int = 0xFF0B0F14.toInt(),
    val surface: Int = 0xFF121821.toInt(),
    val card: Int = 0xFF1A2230.toInt(),
    val primary: Int = 0xFF7AA2F7.toInt(),
    val secondary: Int = 0xFF9D7CD8.toInt(),
    val accent: Int = 0xFF7DCFFF.toInt(),
    val textPrimary: Int = 0xFFE7ECF5.toInt(),
    val textSecondary: Int = 0xFF93A0B5.toInt(),
    val gradient: List<Int> = emptyList(),
    val gradientDirection: String = GradientDirection.NONE.name,
    val isLight: Boolean = false,
    val isAmoled: Boolean = false,
) {
    val direction: GradientDirection get() = GradientDirection.fromName(gradientDirection)

    /** Background that is guaranteed readable: AMOLED mode forces pure black. */
    fun effectiveBackground(amoledMode: Boolean): Int =
        if (amoledMode) 0xFF000000.toInt() else background

    /** Primary text colour adjusted for readability against [bg]. */
    fun readableText(bg: Int): Int = ColorMath.ensureContrast(bg, textPrimary, 4.5)

    /** Secondary text colour adjusted for readability against [bg]. */
    fun readableSecondaryText(bg: Int): Int =
        ColorMath.ensureContrast(bg, textSecondary, 3.0)

    /**
     * Light-mode conversion used when the user picks "Light" but the chosen preset is dark
     * (and vice-versa). Keeps hue identity, flips lightness.
     */
    fun toLightVariant(): ThemePalette = copy(
        background = lighten(background, 0.92f),
        surface = lighten(surface, 0.96f),
        card = lighten(card, 0.90f),
        textPrimary = 0xFF101319.toInt(),
        textSecondary = 0xFF4C5563.toInt(),
        isLight = true,
        isAmoled = false,
        gradient = gradient.map { lighten(it, 0.94f) },
    )

    fun toDarkVariant(): ThemePalette = copy(
        background = darken(background, 0.86f),
        surface = darken(surface, 0.80f),
        card = darken(card, 0.72f),
        textPrimary = 0xFFF1F4F9.toInt(),
        textSecondary = 0xFFA6B0C0.toInt(),
        isLight = false,
        gradient = gradient.map { darken(it, 0.85f) },
    )

    private fun mix(color: Int, target: Int, amount: Float): Int = ColorMath.blend(color, target, amount)
    private fun lighten(color: Int, amount: Float): Int = mix(color, 0xFFFFFFFF.toInt(), amount)
    private fun darken(color: Int, amount: Float): Int = mix(color, 0xFF000000.toInt(), amount)

    companion object {
        val DEFAULT = ThemePalette()
    }
}

/** A named, ready-to-use theme. */
data class ThemePreset(
    val id: String,
    val name: String,
    val description: String,
    val palette: ThemePalette,
)

/** The 20 bundled presets required by the product spec. */
object ThemePresets {

    const val CUSTOM_ID = "custom"
    const val SYSTEM_ID = "system_dynamic"

    private fun p(
        id: String,
        name: String,
        description: String,
        bg: Long,
        surface: Long,
        card: Long,
        primary: Long,
        secondary: Long,
        accent: Long,
        text: Long,
        textSecondary: Long,
        gradient: List<Long> = emptyList(),
        direction: GradientDirection = GradientDirection.NONE,
        light: Boolean = false,
        amoled: Boolean = false,
    ) = ThemePreset(
        id = id,
        name = name,
        description = description,
        palette = ThemePalette(
            background = bg.toInt(),
            surface = surface.toInt(),
            card = card.toInt(),
            primary = primary.toInt(),
            secondary = secondary.toInt(),
            accent = accent.toInt(),
            textPrimary = text.toInt(),
            textSecondary = textSecondary.toInt(),
            gradient = gradient.map { it.toInt() },
            gradientDirection = direction.name,
            isLight = light,
            isAmoled = amoled,
        ),
    )

    val all: List<ThemePreset> = listOf(
        p("pure_amoled", "Pure AMOLED Black", "True #000000 pixels for OLED panels",
            0xFF000000, 0xFF07070A, 0xFF101014, 0xFF8AB4FF, 0xFFB79CFF, 0xFF5EEAD4,
            0xFFFFFFFF, 0xFFAAB2C0, amoled = true),
        p("midnight_black", "Midnight Black", "Cool near-black with soft blue accents",
            0xFF0B0F14, 0xFF121821, 0xFF1A2230, 0xFF7AA2F7, 0xFF9D7CD8, 0xFF7DCFFF,
            0xFFE7ECF5, 0xFF93A0B5),
        p("graphite_gray", "Graphite Gray", "Neutral grey studio look",
            0xFF17181A, 0xFF212226, 0xFF2A2C31, 0xFFC7CDD6, 0xFF9AA3AF, 0xFF8FA1FF,
            0xFFF2F4F7, 0xFFA8AEBA),
        p("dark_titanium", "Dark Titanium", "Brushed metal with warm gold highlights",
            0xFF1B1D1F, 0xFF24272A, 0xFF2E3236, 0xFFD5A96B, 0xFF8C939A, 0xFFE8C48A,
            0xFFEDEFF1, 0xFFA6ADB4),
        p("ocean_blue", "Ocean Blue", "Deep water blues and cyan",
            0xFF06131F, 0xFF0B1E2E, 0xFF10293C, 0xFF38BDF8, 0xFF22D3EE, 0xFF67E8F9,
            0xFFE6F6FF, 0xFF94B8CC),
        p("arctic_blue", "Arctic Blue", "Crisp light theme with icy blues",
            0xFFF2F7FB, 0xFFFFFFFF, 0xFFE6EFF7, 0xFF1D6FB8, 0xFF4C93CB, 0xFF0EA5A5,
            0xFF0B1B2A, 0xFF4A6478, light = true),
        p("neon_cyberpunk", "Neon Cyberpunk", "Hot magenta and electric cyan",
            0xFF0A0118, 0xFF150429, 0xFF1E0838, 0xFFFF2E97, 0xFF00F0FF, 0xFFB6FF00,
            0xFFFFF3FB, 0xFFC4A6D8,
            gradient = listOf(0xFF1A0330, 0xFF0A0118, 0xFF07000F),
            direction = GradientDirection.TOP_BOTTOM),
        p("purple_aurora", "Purple Aurora", "Violet glow on a night sky",
            0xFF120A24, 0xFF1B1035, 0xFF251546, 0xFFA78BFA, 0xFFC4B5FD, 0xFF67E8F9,
            0xFFF3EEFF, 0xFFB3A6D0,
            gradient = listOf(0xFF2A1550, 0xFF120A24), direction = GradientDirection.DIAGONAL),
        p("deep_violet", "Deep Violet", "Rich violet with fuchsia accents",
            0xFF0F0820, 0xFF181030, 0xFF211543, 0xFF8B5CF6, 0xFFD946EF, 0xFFF0ABFC,
            0xFFF1E9FF, 0xFFAFA0CC),
        p("emerald_green", "Emerald Green", "Deep green with fresh mint",
            0xFF04140E, 0xFF0A2118, 0xFF0F2E21, 0xFF34D399, 0xFF10B981, 0xFF6EE7B7,
            0xFFE6FFF5, 0xFF94BFAE),
        p("forest_green", "Forest Green", "Muted woodland greens",
            0xFF0E1A12, 0xFF17281B, 0xFF1F3625, 0xFF86C36B, 0xFFB7D08C, 0xFFD9E8A8,
            0xFFF0F7EC, 0xFFA9BCA2),
        p("sunset_orange", "Sunset Orange", "Warm dusk gradient with amber light",
            0xFF1A0D06, 0xFF26140A, 0xFF331B0E, 0xFFFB923C, 0xFFF97316, 0xFFFCD34D,
            0xFFFFF3E8, 0xFFC9A791,
            gradient = listOf(0xFF3A1608, 0xFF1A0D06), direction = GradientDirection.BOTTOM_TOP),
        p("rose_pink", "Rose Pink", "Soft rose with pink highlights",
            0xFF1B0A12, 0xFF27101B, 0xFF341624, 0xFFFB7185, 0xFFF472B6, 0xFFFBCFE8,
            0xFFFFF1F6, 0xFFCDA4B4),
        p("ruby_red", "Ruby Red", "Bold crimson on charcoal",
            0xFF150507, 0xFF210A0D, 0xFF2D0F13, 0xFFEF4444, 0xFFF87171, 0xFFFCA5A5,
            0xFFFFF1F1, 0xFFC9A0A0),
        p("golden_luxury", "Golden Luxury", "Black tie gold on deep charcoal",
            0xFF12100A, 0xFF1C1911, 0xFF26221A, 0xFFE3B341, 0xFFC9A227, 0xFFF5D06F,
            0xFFFBF6E9, 0xFFBFB393),
        p("pastel_dreams", "Pastel Dreams", "Airy pastel light theme",
            0xFFFBF6FF, 0xFFFFFFFF, 0xFFF2E9FF, 0xFF8B5CF6, 0xFFEC4899, 0xFF0EA5E9,
            0xFF2B2140, 0xFF6B5B85, light = true,
            gradient = listOf(0xFFFDF6FF, 0xFFEFF6FF), direction = GradientDirection.TOP_BOTTOM),
        p("minimal_white", "Minimal White", "Clean monochrome light theme",
            0xFFFFFFFF, 0xFFF7F7F8, 0xFFEFEFF1, 0xFF1A1A1A, 0xFF4B4B4B, 0xFF2563EB,
            0xFF0A0A0A, 0xFF5C5C5C, light = true),
        p("warm_sand", "Warm Sand", "Natural desert tones",
            0xFFF6EEE0, 0xFFFFF9F0, 0xFFEFE2CC, 0xFFA9713B, 0xFFC79A6B, 0xFF6F8F6A,
            0xFF2E2418, 0xFF6E5D48, light = true),
        p("frosted_glass", "Frosted Glass", "Layered translucent-blue surfaces",
            0xFF131A22, 0xFF1B2430, 0xFF26313F, 0xFFA5C8FF, 0xFFCFE3FF, 0xFF9FE8DC,
            0xFFF2F7FF, 0xFFB7C7DA,
            gradient = listOf(0xFF223246, 0xFF0E141B), direction = GradientDirection.DIAGONAL),
        p("gradient_galaxy", "Gradient Galaxy", "Nebula gradient with cosmic accents",
            0xFF0D0722, 0xFF1A0F38, 0xFF241349, 0xFFC084FC, 0xFF60A5FA, 0xFFF472B6,
            0xFFF5EEFF, 0xFFB6A6D6,
            gradient = listOf(0xFF1B0B3A, 0xFF3A0B5C, 0xFF0B1030), direction = GradientDirection.DIAGONAL),
    )

    fun byId(id: String): ThemePreset = all.firstOrNull { it.id == id } ?: all[0]

    fun exists(id: String): Boolean = id == CUSTOM_ID || id == SYSTEM_ID || all.any { it.id == id }
}
