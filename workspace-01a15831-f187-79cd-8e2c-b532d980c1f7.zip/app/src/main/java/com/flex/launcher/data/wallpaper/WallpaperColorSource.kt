package com.flex.launcher.data.wallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import com.flex.launcher.core.util.ColorMath
import com.flex.launcher.domain.theme.GradientDirection
import com.flex.launcher.domain.theme.ThemePalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Derives a launcher palette from the device wallpaper using androidx Palette.
 *
 * This is a *derived* colour scheme (drawn from the wallpaper image), not system-level
 * transparency: the launcher still draws its own surfaces. On Android 12+ the user can also
 * enable Material You dynamic colours, which are read from the platform in the UI layer.
 */
class WallpaperColorSource(private val context: Context) {

    suspend fun extractPalette(): ThemePalette? = withContext(Dispatchers.IO) {
        try {
            val wallpaperManager = WallpaperManager.getInstance(context)
            val drawable = wallpaperManager.drawable ?: return@withContext null
            val bitmap: Bitmap = drawable.toBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val palette = Palette.from(bitmap).clearFilters().generate()

            val dominant = palette.getDominantSwatch()?.rgb
            val vibrant = palette.getVibrantSwatch()?.rgb
                ?: palette.getLightVibrantSwatch()?.rgb
            val muted = palette.getMutedSwatch()?.rgb ?: palette.getDarkMutedSwatch()?.rgb
            val base = dominant ?: vibrant ?: return@withContext null

            val isLightWallpaper = !ColorMath.isDark(base)
            val background = if (isLightWallpaper) {
                ColorMath.blend(base, 0xFFFFFFFF.toInt(), 0.82f)
            } else {
                ColorMath.blend(base, 0xFF000000.toInt(), 0.80f)
            }
            val surface = ColorMath.blend(background, base, 0.18f)
            val card = ColorMath.blend(background, base, 0.30f)
            val primary = ColorMath.ensureContrast(background, vibrant ?: base, 3.0)
            val secondary = ColorMath.ensureContrast(background, muted ?: base, 3.0)
            val accent = ColorMath.ensureContrast(background, palette.getLightVibrantSwatch()?.rgb ?: primary, 3.0)

            ThemePalette(
                background = background,
                surface = surface,
                card = card,
                primary = primary,
                secondary = secondary,
                accent = accent,
                textPrimary = if (isLightWallpaper) 0xFF101319.toInt() else 0xFFF4F7FB.toInt(),
                textSecondary = if (isLightWallpaper) 0xFF4A5462.toInt() else 0xFFB7C1D0.toInt(),
                gradient = listOf(background, ColorMath.blend(background, base, 0.35f)),
                gradientDirection = GradientDirection.TOP_BOTTOM.name,
                isLight = isLightWallpaper,
                isAmoled = false,
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not derive colours from the wallpaper", e)
            null
        }
    }

    companion object {
        private const val TAG = "WallpaperColorSource"
    }
}
