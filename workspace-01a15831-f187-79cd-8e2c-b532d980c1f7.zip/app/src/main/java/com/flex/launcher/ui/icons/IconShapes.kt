package com.flex.launcher.ui.icons

import androidx.compose.foundation.shape.GenericShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.icons.Corner
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.icons.ShapeGeometry
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sign
import kotlin.math.sin

/**
 * Converts the pure [ShapeGeometry] model into real Compose clipping [Shape]s.
 * Every shape produces a distinct path — nothing here is a label-only stub.
 */
object IconShapeRenderer {

    fun shapeFor(iconShape: IconShape): Shape = GenericShape { size, _ ->
        buildPath(iconShape.geometry, size)
    }

    fun buildPath(geometry: ShapeGeometry, size: Size): Path {
        val path = Path()
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return path
        val minSide = minOf(w, h)
        when (geometry) {
            ShapeGeometry.Circle -> path.addOval(Rect(Offset.Zero, size))

            ShapeGeometry.Rect -> path.addRect(Rect(Offset.Zero, size))

            is ShapeGeometry.RoundedRect -> path.addRoundRect(
                RoundRect(Rect(Offset.Zero, size), CornerRadius(minSide * geometry.radiusRatio)),
            )

            is ShapeGeometry.Superellipse -> {
                val n = geometry.exponent.coerceIn(2f, 8f)
                val steps = 96
                val a = w / 2f
                val b = h / 2f
                for (i in 0..steps) {
                    val t = (i.toFloat() / steps) * 2f * Math.PI.toFloat()
                    val ct = cos(t)
                    val st = sin(t)
                    val x = a * sign(ct) * Math.pow(abs(ct).toDouble(), 2.0 / n).toFloat()
                    val y = b * sign(st) * Math.pow(abs(st).toDouble(), 2.0 / n).toFloat()
                    if (i == 0) path.moveTo(a + x, b + y) else path.lineTo(a + x, b + y)
                }
                path.close()
            }

            is ShapeGeometry.Teardrop -> buildTeardrop(path, size, geometry)

            is ShapeGeometry.RegularPolygon -> {
                val points = regularPolygonPoints(
                    sides = geometry.sides.coerceIn(3, 12),
                    size = size,
                    rotationDeg = geometry.rotationDeg,
                    inset = geometry.inset,
                )
                path.roundedPolygon(points, radius = minSide * 0.02f)
            }

            is ShapeGeometry.Flower -> {
                val lobes = geometry.lobes.coerceAtLeast(3)
                val amplitude = geometry.amplitude.coerceIn(0.02f, 0.35f)
                val steps = 144
                for (i in 0..steps) {
                    val t = (i.toFloat() / steps) * 2f * Math.PI.toFloat()
                    val r = 0.5f * (1f + amplitude * cos(lobes * t))
                    val x = w / 2f + cos(t) * w / 2f * r
                    val y = h / 2f + sin(t) * h / 2f * r
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
            }

            ShapeGeometry.Pebble -> {
                val steps = 144
                for (i in 0..steps) {
                    val t = (i.toFloat() / steps) * 2f * Math.PI.toFloat()
                    val r = 0.5f * (1f + 0.05f * sin(3f * t + 0.8f) + 0.03f * cos(2f * t - 0.4f))
                    val x = w / 2f + cos(t) * w / 2f * r
                    val y = h / 2f + sin(t) * h / 2f * r
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
            }

            ShapeGeometry.Shield -> buildShield(path, size)

            is ShapeGeometry.RoundedDiamond -> {
                val points = listOf(
                    Offset(w / 2f, 0f),
                    Offset(w, h / 2f),
                    Offset(w / 2f, h),
                    Offset(0f, h / 2f),
                )
                path.roundedPolygon(points, radius = minSide * geometry.radiusRatio)
            }
        }
        return path
    }

    private fun buildTeardrop(path: Path, size: Size, geometry: ShapeGeometry.Teardrop) {
        val w = size.width
        val h = size.height
        val r = minOf(w, h) * geometry.radiusRatio.coerceIn(0.1f, 0.5f)
        val sharpAt = geometry.sharpCorner
        // One sharp corner, three rounded corners: built explicitly so the sharp corner is real.
        when (sharpAt) {
            Corner.BOTTOM_RIGHT -> {
                path.moveTo(r, 0f)
                path.lineTo(w - r, 0f)
                path.quadraticTo(w, 0f, w, r)
                path.lineTo(w, h)                 // sharp corner
                path.lineTo(r, h)
                path.quadraticTo(0f, h, 0f, h - r)
                path.lineTo(0f, r)
                path.quadraticTo(0f, 0f, r, 0f)
                path.close()
            }
            Corner.TOP_RIGHT -> {
                path.moveTo(0f, r)
                path.lineTo(w, 0f)                // sharp corner
                path.lineTo(w, h - r)
                path.quadraticTo(w, h, w - r, h)
                path.lineTo(r, h)
                path.quadraticTo(0f, h, 0f, h - r)
                path.quadraticTo(0f, 0f, 0f, r)
                path.close()
            }
            Corner.BOTTOM_LEFT -> {
                path.moveTo(r, 0f)
                path.lineTo(w - r, 0f)
                path.quadraticTo(w, 0f, w, r)
                path.lineTo(w, h - r)
                path.quadraticTo(w, h, w - r, h)
                path.lineTo(0f, h)                // sharp corner
                path.lineTo(0f, r)
                path.quadraticTo(0f, 0f, r, 0f)
                path.close()
            }
            Corner.TOP_LEFT -> {
                path.moveTo(0f, 0f)               // sharp corner
                path.lineTo(w - r, 0f)
                path.quadraticTo(w, 0f, w, r)
                path.lineTo(w, h - r)
                path.quadraticTo(w, h, w - r, h)
                path.lineTo(r, h)
                path.quadraticTo(0f, h, 0f, h - r)
                path.close()
            }
        }
    }

    private fun buildShield(path: Path, size: Size) {
        val w = size.width
        val h = size.height
        path.moveTo(w * 0.06f, h * 0.10f)
        path.quadraticTo(w * 0.5f, h * 0.02f, w * 0.94f, h * 0.10f)
        path.lineTo(w * 0.94f, h * 0.54f)
        path.cubicTo(w * 0.94f, h * 0.78f, w * 0.72f, h * 0.92f, w * 0.5f, h * 0.99f)
        path.cubicTo(w * 0.28f, h * 0.92f, w * 0.06f, h * 0.78f, w * 0.06f, h * 0.54f)
        path.close()
    }

    private fun regularPolygonPoints(
        sides: Int,
        size: Size,
        rotationDeg: Float,
        inset: Float,
    ): List<Offset> {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = minOf(size.width, size.height) / 2f * inset.coerceIn(0.5f, 1f)
        return (0 until sides).map { i ->
            val angle = Math.toRadians((rotationDeg - 90f + i * 360f / sides).toDouble())
            Offset(
                cx + (radius * cos(angle)).toFloat(),
                cy + (radius * sin(angle)).toFloat(),
            )
        }
    }

    /** Builds a closed polygon whose corners are rounded with [radius] pixels. */
    private fun Path.roundedPolygon(points: List<Offset>, radius: Float) {
        if (points.size < 3) return
        val n = points.size
        for (i in 0 until n) {
            val prev = points[(i - 1 + n) % n]
            val curr = points[i]
            val next = points[(i + 1) % n]
            val v1 = prev - curr
            val v2 = next - curr
            val len1 = v1.getDistance()
            val len2 = v2.getDistance()
            if (len1 == 0f || len2 == 0f) continue
            val d = minOf(radius, len1 / 2f, len2 / 2f)
            val p1 = curr + v1 * (d / len1)
            val p2 = curr + v2 * (d / len2)
            if (i == 0) moveTo(p1.x, p1.y) else lineTo(p1.x, p1.y)
            if (d <= 0.01f) lineTo(curr.x, curr.y) else quadraticTo(curr.x, curr.y, p2.x, p2.y)
        }
        close()
    }

    /** Convenience for previews: the default icon size in dp. */
    val PreviewSize = 56.dp
}
