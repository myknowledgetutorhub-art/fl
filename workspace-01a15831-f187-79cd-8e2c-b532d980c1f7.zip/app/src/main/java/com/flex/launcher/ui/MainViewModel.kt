package com.flex.launcher.ui

import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.flex.launcher.FlexLauncherApp
import com.flex.launcher.core.AppGraph
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.AppQuery
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.RecentApp
import com.flex.launcher.domain.model.RecentResolver
import com.flex.launcher.domain.theme.ThemePalette
import com.flex.launcher.launcher.LaunchOutcome
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface AppsState {
    data object Loading : AppsState
    data class Content(val apps: List<AppEntry>) : AppsState
    data class Error(val message: String) : AppsState
}

data class UiMessage(val text: String, val id: Long = System.nanoTime())

/**
 * Single activity-scoped ViewModel. Preferences, apps and recents are exposed as immutable
 * state; every mutation goes through the repositories so nothing is faked in the UI.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val graph: AppGraph = (application as FlexLauncherApp).graph
    private val context = application.applicationContext

    /** Icon loader used by the UI to resolve real app icons with a bounded cache. */
    val iconLoader get() = graph.iconLoader

    val prefs: StateFlow<LauncherPrefs> = graph.preferences.preferences
        .catch { throwable ->
            Log.e(TAG, "Preference stream failed", throwable)
            emit(LauncherPrefs.DEFAULT)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, LauncherPrefs.DEFAULT)

    val appsState: StateFlow<AppsState> = graph.appRepository.observeApps()
        .map<List<AppEntry>, AppsState> { AppsState.Content(it) }
        .catch { throwable ->
            Log.e(TAG, "App list failed", throwable)
            emit(AppsState.Error(throwable.message ?: "Could not read installed apps"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppsState.Loading)

    private val localHistory = graph.recentAppsStore.history
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    private val usageTimestamps = MutableStateFlow<Map<String, Long>>(emptyMap())

    private val _usageAccessGranted = MutableStateFlow(false)
    val usageAccessGranted: StateFlow<Boolean> = _usageAccessGranted.asStateFlow()

    private val _wallpaperPalette = MutableStateFlow<ThemePalette?>(null)
    val wallpaperPalette: StateFlow<ThemePalette?> = _wallpaperPalette.asStateFlow()

    private val _isDefaultLauncher = MutableStateFlow(false)
    val isDefaultLauncher: StateFlow<Boolean> = _isDefaultLauncher.asStateFlow()

    private val _homeRequests = Channel<Unit>(Channel.CONFLATED)
    /** Emits when Android delivers a HOME intent, so the UI can return to the launcher surface. */
    val homeRequests = _homeRequests.receiveAsFlow()

    private val _messages = Channel<UiMessage>(Channel.BUFFERED)
    val messages = _messages.receiveAsFlow()

    /** All launchable apps, with hidden ones removed. */
    val visibleApps: StateFlow<List<AppEntry>> = combine(appsState, prefs) { state, p ->
        val apps = (state as? AppsState.Content)?.apps ?: emptyList()
        AppQuery.visible(apps, p.hiddenApps)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Recent apps: UsageStats first (when granted), local history as the always-on fallback. */
    val recentApps: StateFlow<List<RecentApp>> = combine(
        visibleApps,
        prefs,
        localHistory,
        usageTimestamps,
        _usageAccessGranted,
    ) { apps, p, local, usage, granted ->
        if (!p.recents.enabled) emptyList()
        else RecentResolver.resolve(
            apps = apps,
            usageStats = if (p.recents.useUsageAccess) usage else emptyMap(),
            localHistory = local,
            hidden = p.hiddenApps,
            limit = p.recents.maxItems,
            preferUsageStats = p.recents.useUsageAccess && granted,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** package -> last used timestamp, used by "recently used" sorting. */
    val recencyRank: StateFlow<Map<String, Long>> = combine(usageTimestamps, localHistory) { usage, local ->
        buildMap {
            putAll(local)
            usage.forEach { (pkg, ts) -> put(pkg, maxOf(ts, local[pkg] ?: 0L)) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyMap())

    /** Apps pinned to the home screen, in the user's chosen order. */
    val pinnedApps: StateFlow<List<AppEntry>> = combine(visibleApps, prefs) { apps, p ->
        val byKey = apps.associateBy { it.key }
        p.home.pinnedApps.mapNotNull { key ->
            byKey[key] ?: apps.firstOrNull { it.packageName == key }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val allAppsIncludingHidden: StateFlow<List<AppEntry>> = appsState
        .map { (it as? AppsState.Content)?.apps ?: emptyList() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        refreshPermissionState()
        refreshUsageStats()
    }

    // ---------------------------------------------------------------- preferences

    fun updatePrefs(transform: (LauncherPrefs) -> LauncherPrefs) {
        viewModelScope.launch {
            runCatching { graph.preferences.update(transform) }
                .onFailure {
                    Log.e(TAG, "Failed to persist preferences", it)
                    _messages.send(UiMessage("Could not save that setting"))
                }
        }
    }

    fun resetAppearance() = viewModelScope.launch {
        runCatching { graph.preferences.resetAppearance() }
            .onSuccess { _messages.send(UiMessage("Appearance reset to defaults")) }
            .onFailure { _messages.send(UiMessage("Could not reset appearance")) }
    }

    fun resetEverything() = viewModelScope.launch {
        runCatching {
            graph.preferences.resetAll()
            graph.recentAppsStore.clear()
        }.onSuccess { _messages.send(UiMessage("All launcher settings were reset")) }
            .onFailure { _messages.send(UiMessage("Could not reset settings")) }
    }

    fun completeOnboarding() = updatePrefs { it.copy(onboardingCompleted = true) }

    /** Called from MainActivity.onNewIntent when the HOME intent arrives. */
    fun onHomeIntentReceived() {
        viewModelScope.launch { _homeRequests.send(Unit) }
        refreshPermissionState()
        refreshUsageStats()
    }

    // ---------------------------------------------------------------- launching

    fun launchApp(entry: AppEntry) {
        viewModelScope.launch {
            when (val outcome = graph.actions.launchApp(entry)) {
                is LaunchOutcome.Failed -> _messages.send(UiMessage(outcome.message))
                else -> Unit
            }
        }
    }

    fun dial(number: String) {
        when (val outcome = graph.actions.dial(number)) {
            is LaunchOutcome.Failed -> notify(outcome.message)
            else -> Unit
        }
    }

    fun openWallpaperPicker() = handle(graph.actions.openWallpaperPicker())
    fun openUsageAccessSettings() = handle(graph.actions.openUsageAccessSettings())
    fun openDefaultLauncherSettings() = handle(graph.actions.openDefaultLauncherSettings())
    fun openAppInfo(packageName: String) = handle(graph.actions.openAppInfo(packageName))
    fun openIntent(intent: Intent) = handle(graph.actions.openIntent(intent))

    private fun handle(outcome: LaunchOutcome) {
        if (outcome is LaunchOutcome.Failed) notify(outcome.message)
    }

    /** Shows a message in the global snackbar (used by UI-side feature feedback). */
    fun postMessage(text: String) = notify(text)

    private fun notify(text: String) {
        viewModelScope.launch { _messages.send(UiMessage(text)) }
    }

    // ---------------------------------------------------------------- permissions

    fun refreshPermissionState() {
        _usageAccessGranted.value = graph.usageStats.hasPermission()
        _isDefaultLauncher.value = computeIsDefaultLauncher()
    }

    /** Called on ON_RESUME so returning from system settings refreshes real state. */
    fun onScreenResumed() {
        refreshPermissionState()
        refreshUsageStats()
    }

    fun refreshUsageStats() {
        viewModelScope.launch {
            if (!graph.usageStats.hasPermission()) {
                usageTimestamps.value = emptyMap()
                return@launch
            }
            val stats = withContext(Dispatchers.IO) { graph.usageStats.lastUsed() }
            usageTimestamps.value = stats
        }
    }

    fun clearRecentHistory() = viewModelScope.launch {
        runCatching { graph.recentAppsStore.clear() }
            .onSuccess {
                _messages.send(
                    UiMessage(
                        "Flex Launcher history cleared. Android's own usage records are managed by the system.",
                    ),
                )
            }
            .onFailure { _messages.send(UiMessage("Could not clear recent history")) }
    }

    fun refreshApps() {
        viewModelScope.launch { graph.appRepository.load() }
    }

    private fun computeIsDefaultLauncher(): Boolean = runCatching {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        @Suppress("DEPRECATION")
        val resolved = context.packageManager.resolveActivity(
            homeIntent,
            PackageManager.MATCH_DEFAULT_ONLY,
        )
        resolved?.activityInfo?.packageName == context.packageName
    }.getOrDefault(false)

    // ---------------------------------------------------------------- backup

    /** Writes a JSON backup to a user-picked document. Errors are surfaced, never swallowed. */
    fun exportBackup(uri: android.net.Uri) = viewModelScope.launch {
        val payload = com.flex.launcher.data.prefs.BackupPayload(
            exportedAtEpochMillis = System.currentTimeMillis(),
            prefs = prefs.value,
            recentHistory = graph.recentAppsStore.history.first(),
        )
        val text = com.flex.launcher.data.prefs.BackupCodec.encode(payload)
        val result = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                } ?: error("Could not open the selected file")
            }
        }
        result.onSuccess { _messages.send(UiMessage("Backup saved")) }
            .onFailure {
                Log.e(TAG, "Backup export failed", it)
                _messages.send(UiMessage("Backup failed: ${it.message ?: "unknown error"}"))
            }
    }

    /** Reads and validates a backup file, then replaces preferences. */
    fun importBackup(uri: android.net.Uri) = viewModelScope.launch {
        val textResult = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.readBytes().toString(Charsets.UTF_8)
                } ?: error("Could not open the selected file")
            }
        }
        val text = textResult.getOrElse {
            Log.e(TAG, "Backup read failed", it)
            _messages.send(UiMessage("Could not read that file"))
            return@launch
        }
        val payload = com.flex.launcher.data.prefs.BackupCodec.decode(text)
        payload.onSuccess { data ->
            runCatching {
                graph.preferences.replace(data.prefs)
                graph.recentAppsStore.restore(data.recentHistory)
            }.onSuccess { _messages.send(UiMessage("Backup restored")) }
                .onFailure {
                    Log.e(TAG, "Backup apply failed", it)
                    _messages.send(UiMessage("Backup could not be applied"))
                }
        }.onFailure { error ->
            _messages.send(UiMessage(error.message ?: "That backup is not valid"))
        }
    }

    // ---------------------------------------------------------------- hide apps

    fun setAppHidden(packageName: String, hidden: Boolean) {
        if (packageName == context.packageName) {
            notify("Flex Launcher cannot hide itself")
            return
        }
        updatePrefs { current ->
            val next = current.hiddenApps.toMutableSet()
            if (hidden) next += packageName else next -= packageName
            current.copy(hiddenApps = next)
        }
    }

    fun clearHiddenApps() = updatePrefs { it.copy(hiddenApps = emptySet()) }

    // ---------------------------------------------------------------- favourites

    fun togglePinned(entry: AppEntry) {
        updatePrefs { current ->
            val pins = current.home.pinnedApps.toMutableList()
            if (pins.contains(entry.key)) pins.remove(entry.key) else pins.add(entry.key)
            current.copy(home = current.home.copy(pinnedApps = pins))
        }
    }

    /** This launcher's own package name — it may never be hidden. */
    fun selfPackageName(): String = context.packageName

    fun isPinned(entry: AppEntry): Boolean = prefs.value.home.pinnedApps.contains(entry.key)

    fun movePin(from: Int, to: Int) {
        updatePrefs { current ->
            val pins = current.home.pinnedApps.toMutableList()
            if (from in pins.indices && to in pins.indices) {
                val item = pins.removeAt(from)
                pins.add(to, item)
            }
            current.copy(home = current.home.copy(pinnedApps = pins))
        }
    }

    suspend fun wallpaperPaletteNow(): ThemePalette? =
        graph.wallpaperColors.extractPalette().also { _wallpaperPalette.value = it }

    companion object {
        private const val TAG = "MainViewModel"
    }
}
