package com.flex.launcher.ui.drawer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.AppQuery
import com.flex.launcher.domain.model.AppSortMode
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.RecentApp
import com.flex.launcher.domain.model.RecentSource
import com.flex.launcher.domain.animations.AnimationScope
import com.flex.launcher.ui.animations.LauncherAnimations
import com.flex.launcher.ui.components.AppIcon
import com.flex.launcher.ui.components.EmptyState
import com.flex.launcher.ui.components.LauncherSearchField
import com.flex.launcher.ui.components.LoadingState
import com.flex.launcher.ui.components.clickableNoRipple
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

data class DrawerCallbacks(
    val onLaunch: (AppEntry) -> Unit,
    val onClose: () -> Unit,
    val onOpenSettings: () -> Unit,
    val onPinToggle: (AppEntry) -> Unit,
    val onHide: (AppEntry) -> Unit,
    val onAppInfo: (AppEntry) -> Unit,
    val onOpenUsageSettings: () -> Unit,
    val onSortChange: (AppSortMode) -> Unit,
)

/**
 * Full app drawer: Recent apps first, then favourites, then the complete alphabetical list.
 * Search and sorting operate on the real installed-app list.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppDrawer(
    prefs: LauncherPrefs,
    apps: List<AppEntry>,
    recents: List<RecentApp>,
    pinned: List<AppEntry>,
    recencyRank: Map<String, Long>,
    query: String,
    onQueryChange: (String) -> Unit,
    appsLoading: Boolean,
    appsError: String?,
    usageAccessGranted: Boolean,
    callbacks: DrawerCallbacks,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val opacity = (prefs.backgroundOpacity / 100f).coerceIn(0.55f, 1f)

    val spacing = (prefs.icons.spacingDp * prefs.density.spacingScale).dp
    val filtered = remember(apps, query) { AppQuery.search(apps, query) }
    val sorted = remember(filtered, prefs.drawer.sortMode, recencyRank) {
        AppQuery.sorted(filtered, prefs.drawer.sortMode, recencyRank)
    }
    val isSearching = query.isNotBlank()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background.copy(alpha = opacity)),
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = if (isSearching) "${sorted.size} result${if (sorted.size == 1) "" else "s"}" else "Apps",
                    style = type.heading,
                    color = colors.textPrimary,
                    modifier = Modifier.padding(start = 6.dp),
                )
                Spacer(Modifier.weight(1f))
                SortToggle(prefs.drawer.sortMode, callbacks.onSortChange)
                IconButton(onClick = callbacks.onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Close app drawer", tint = colors.textPrimary)
                }
                IconButton(onClick = callbacks.onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Launcher settings", tint = colors.textSecondary)
                }
            }

            LauncherSearchField(
                query = query,
                onQueryChange = onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                testTag = "drawer_search",
            )

            when {
                appsLoading && apps.isEmpty() -> LoadingState()
                appsError != null && apps.isEmpty() -> EmptyState(
                    title = "Installed apps unavailable",
                    message = appsError,
                )
                else -> LazyVerticalGrid(
                    columns = GridCells.Fixed(prefs.icons.drawerColumns),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(spacing / 2),
                    verticalArrangement = Arrangement.spacedBy(spacing),
                    modifier = Modifier.fillMaxSize().navigationBarsPadding(),
                ) {
                    if (prefs.drawer.showRecents && prefs.recents.enabled) {
                        item(span = { GridItemSpan(maxLineSpan) }, key = "recent_header") {
                            SearchAwareVisibility(!isSearching, prefs) {
                                SectionHeaderRow(
                                    title = "Recent apps",
                                    trailing = if (usageAccessGranted) null else "Limited",
                                )
                            }
                        }
                        item(span = { GridItemSpan(maxLineSpan) }, key = "recent_row") {
                            SearchAwareVisibility(!isSearching, prefs) {
                                RecentsRow(
                                    recents = recents,
                                    usageAccessGranted = usageAccessGranted,
                                    onLaunch = callbacks.onLaunch,
                                    onOpenUsageSettings = callbacks.onOpenUsageSettings,
                                )
                            }
                        }
                    }

                    if (!isSearching && pinned.isNotEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }, key = "fav_header") {
                            SectionHeaderRow(title = "Favourites")
                        }
                        item(span = { GridItemSpan(maxLineSpan) }, key = "fav_row") {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(14.dp),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp),
                            ) {
                                items(pinned, key = { it.key }) { entry ->
                                    DrawerAppItem(
                                        entry = entry,
                                        prefs = prefs,
                                        onClick = { callbacks.onLaunch(entry) },
                                        isPinned = true,
                                        onPinToggle = callbacks.onPinToggle,
                                        onHide = callbacks.onHide,
                                        onAppInfo = callbacks.onAppInfo,
                                    )
                                }
                            }
                        }
                    }

                    if (!isSearching && prefs.drawer.showAllAppsHeader) {
                        item(span = { GridItemSpan(maxLineSpan) }, key = "all_header") {
                            SectionHeaderRow(title = "All apps", trailing = "${sorted.size}")
                        }
                    }

                    if (sorted.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }, key = "empty") {
                            EmptyState(
                                title = if (isSearching) "No apps match “$query”" else "No apps found",
                                message = if (isSearching) {
                                    "Try a different name, or clear the search field."
                                } else {
                                    "Flex Launcher could not find any launchable apps on this device. " +
                                        "If you have hidden apps, reset the list in Settings › Hide Apps."
                                },
                                actionLabel = if (isSearching) "Clear search" else null,
                                onAction = if (isSearching) ({ onQueryChange("") }) else null,
                            )
                        }
                    } else {
                        items(sorted, key = { it.key }) { entry ->
                            DrawerAppItem(
                                entry = entry,
                                prefs = prefs,
                                onClick = { callbacks.onLaunch(entry) },
                                isPinned = pinned.any { it.key == entry.key },
                                onPinToggle = callbacks.onPinToggle,
                                onHide = callbacks.onHide,
                                onAppInfo = callbacks.onAppInfo,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeaderRow(title: String, trailing: String? = null) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 6.dp, start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = type.heading, color = colors.textPrimary)
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            Text(trailing, style = type.label, color = colors.textSecondary)
        }
        Spacer(Modifier.weight(1f))
    }
}

@Composable
private fun SortToggle(current: AppSortMode, onChange: (AppSortMode) -> Unit) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val next = if (current == AppSortMode.ALPHABETICAL) AppSortMode.RECENT else AppSortMode.ALPHABETICAL
    Box(
        modifier = Modifier
            .heightIn(min = 36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(colors.card)
            .clickableNoRipple { onChange(next) }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (current == AppSortMode.ALPHABETICAL) "A–Z" else "Recent",
            style = type.label,
            color = colors.textSecondary,
        )
    }
}

@Composable
private fun RecentsRow(
    recents: List<RecentApp>,
    usageAccessGranted: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onOpenUsageSettings: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    if (recents.isEmpty()) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(colors.card.copy(alpha = 0.7f))
                .padding(16.dp),
        ) {
            Text("No recent apps yet", style = type.body, color = colors.textPrimary)
            Spacer(Modifier.height(4.dp))
            Text(
                if (usageAccessGranted) {
                    "Apps you open from Flex Launcher will appear here."
                } else {
                    "Grant Usage access to also see apps opened from other launchers, or keep using this " +
                        "local history. Only launches made through Flex Launcher are tracked right now."
                },
                style = type.label,
                color = colors.textSecondary,
            )
            if (!usageAccessGranted) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Open Usage access settings",
                    style = type.label,
                    color = colors.accent,
                    modifier = Modifier.clickableNoRipple(onOpenUsageSettings),
                )
            }
        }
        return
    }
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
    ) {
        items(recents, key = { it.app.key }) { recent ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(72.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickableNoRipple { onLaunch(recent.app) }
                    .padding(vertical = 4.dp),
            ) {
                AppIcon(
                    entry = recent.app,
                    size = 48.dp,
                    shape = IconShape.SQUIRCLE,
                    showPlate = false,
                    plateColor = Color.Transparent,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    recent.app.label,
                    style = type.label,
                    color = colors.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                )
                Text(
                    relativeTime(recent.lastUsedMillis),
                    style = type.label.copy(fontSize = type.label.fontSize * 0.85f),
                    color = colors.textSecondary.copy(
                        alpha = if (recent.source == RecentSource.LOCAL_HISTORY) 0.7f else 1f,
                    ),
                    maxLines = 1,
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DrawerAppItem(
    entry: AppEntry,
    prefs: LauncherPrefs,
    onClick: () -> Unit,
    isPinned: Boolean,
    onPinToggle: (AppEntry) -> Unit,
    onHide: (AppEntry) -> Unit,
    onAppInfo: (AppEntry) -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    var menuOpen by remember { mutableStateOf(false) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .testTag("app_item_${entry.packageName}")
            .combinedClickable(
                onClick = onClick,
                onLongClick = { menuOpen = true },
            )
            .padding(vertical = 6.dp),
    ) {
        Box {
            AppIcon(
                entry = entry,
                size = prefs.icons.sizeDp.dp,
                shape = IconShape.fromId(prefs.icons.shapeId),
                showPlate = prefs.icons.backgroundPlate,
                plateColor = Color(prefs.icons.backgroundPlateColor),
            )
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text(if (isPinned) "Remove from home" else "Pin to home") },
                    onClick = {
                        menuOpen = false
                        onPinToggle(entry)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Hide app") },
                    onClick = {
                        menuOpen = false
                        onHide(entry)
                    },
                )
                DropdownMenuItem(
                    text = { Text("App info") },
                    onClick = {
                        menuOpen = false
                        onAppInfo(entry)
                    },
                )
            }
        }
        if (prefs.icons.showLabels) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = entry.label,
                style = type.drawerLabel,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }
    }
}

/** "5 min ago" style label for the recents row. */
fun relativeTime(timestamp: Long, now: Long = System.currentTimeMillis()): String {
    if (timestamp <= 0L) return ""
    val delta = now - timestamp
    return when {
        delta < 60_000L -> "now"
        delta < 3_600_000L -> "${delta / 60_000L} min"
        delta < 86_400_000L -> "${delta / 3_600_000L} h"
        delta < 7 * 86_400_000L -> "${delta / 86_400_000L} d"
        else -> {
            val formatter = DateTimeFormatter.ofPattern("d MMM", Locale.getDefault())
            Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).format(formatter)
        }
    }
}

/**
 * Applies the user's "Search results" animation style when the drawer switches between the
 * browsing layout (recents / favourites) and live search results.
 */
@Composable
private fun SearchAwareVisibility(
    visible: Boolean,
    prefs: LauncherPrefs,
    content: @Composable () -> Unit,
) {
    val enter = LauncherAnimations.enter(prefs.animations, AnimationScope.SEARCH)
    val exit = LauncherAnimations.exit(prefs.animations, AnimationScope.SEARCH)
    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = enter,
        exit = exit,
    ) {
        content()
    }
}
