package com.flex.launcher.domain.typography

import com.flex.launcher.R

/** Where a font family comes from. */
sealed interface FontSource {
    /** A real TTF bundled in `res/font` (see docs/FONT-LICENSES.md). */
    data class Bundled(val regularRes: Int, val boldRes: Int) : FontSource

    /** A font family provided by the Android platform (fallback / system look). */
    data class System(val familyName: String) : FontSource
}

enum class FontCategory(val label: String) {
    GROTESK("Neutral grotesk"),
    GEOMETRIC("Geometric sans"),
    ROUNDED("Rounded sans"),
    HUMANIST("Humanist sans"),
    CONDENSED("Condensed sans"),
    SERIF("Serif"),
    SLAB("Slab serif"),
    MONO("Monospaced"),
    DISPLAY("Display"),
    HANDWRITTEN("Handwritten"),
    SYSTEM("System family"),
}

data class FontOption(
    val id: String,
    val displayName: String,
    val category: FontCategory,
    val source: FontSource,
    val license: String,
    val note: String = "",
)

/**
 * Every selectable font. 23 families ship as real bundled TTF assets and 5 are platform
 * families, giving 28 distinct choices (spec requires at least 24).
 */
object FontOptions {

    private fun bundled(
        id: String,
        name: String,
        category: FontCategory,
        regular: Int,
        bold: Int,
        license: String = "SIL Open Font License 1.1",
        note: String = "",
    ) = FontOption(id, name, category, FontSource.Bundled(regular, bold), license, note)

    val all: List<FontOption> = listOf(
        bundled("inter", "Inter", FontCategory.GROTESK, R.font.inter_regular, R.font.inter_bold),
        bundled("poppins", "Poppins", FontCategory.GEOMETRIC, R.font.poppins_regular, R.font.poppins_bold),
        bundled("montserrat", "Montserrat", FontCategory.GEOMETRIC, R.font.montserrat_regular, R.font.montserrat_bold),
        bundled("outfit", "Outfit", FontCategory.GEOMETRIC, R.font.outfit_regular, R.font.outfit_bold),
        bundled("dm_sans", "DM Sans", FontCategory.GEOMETRIC, R.font.dm_sans_regular, R.font.dm_sans_bold),
        bundled("space_grotesk", "Space Grotesk", FontCategory.GROTESK, R.font.space_grotesk_regular, R.font.space_grotesk_bold),
        bundled("rubik", "Rubik", FontCategory.ROUNDED, R.font.rubik_regular, R.font.rubik_bold),
        bundled("nunito", "Nunito", FontCategory.ROUNDED, R.font.nunito_regular, R.font.nunito_bold),
        bundled("quicksand", "Quicksand", FontCategory.ROUNDED, R.font.quicksand_regular, R.font.quicksand_bold),
        bundled("comfortaa", "Comfortaa", FontCategory.ROUNDED, R.font.comfortaa_regular, R.font.comfortaa_bold),
        bundled("lato", "Lato", FontCategory.HUMANIST, R.font.lato_regular, R.font.lato_bold),
        bundled("open_sans", "Open Sans", FontCategory.HUMANIST, R.font.open_sans_regular, R.font.open_sans_bold),
        bundled("oswald", "Oswald", FontCategory.CONDENSED, R.font.oswald_regular, R.font.oswald_bold),
        bundled("barlow_condensed", "Barlow Condensed", FontCategory.CONDENSED, R.font.barlow_condensed_regular, R.font.barlow_condensed_bold),
        bundled("playfair_display", "Playfair Display", FontCategory.SERIF, R.font.playfair_display_regular, R.font.playfair_display_bold),
        bundled("merriweather", "Merriweather", FontCategory.SERIF, R.font.merriweather_regular, R.font.merriweather_bold),
        bundled("lora", "Lora", FontCategory.SERIF, R.font.lora_regular, R.font.lora_bold),
        bundled("cinzel", "Cinzel", FontCategory.DISPLAY, R.font.cinzel_regular, R.font.cinzel_bold, note = "Elegant Roman-capital display face"),
        bundled("roboto_slab", "Roboto Slab", FontCategory.SLAB, R.font.roboto_slab_regular, R.font.roboto_slab_bold, license = "Apache License 2.0"),
        bundled("jetbrains_mono", "JetBrains Mono", FontCategory.MONO, R.font.jetbrains_mono_regular, R.font.jetbrains_mono_bold),
        bundled("space_mono", "Space Mono", FontCategory.MONO, R.font.space_mono_regular, R.font.space_mono_bold),
        bundled("bebas_neue", "Bebas Neue", FontCategory.DISPLAY, R.font.bebas_neue_regular, R.font.bebas_neue_bold, note = "Single weight face; bold is synthesised"),
        bundled("caveat", "Caveat", FontCategory.HANDWRITTEN, R.font.caveat_regular, R.font.caveat_bold),
        FontOption("system_sans", "System Sans (Roboto)", FontCategory.SYSTEM, FontSource.System("sans-serif"), "Platform font"),
        FontOption("system_serif", "System Serif (Noto Serif)", FontCategory.SYSTEM, FontSource.System("serif"), "Platform font"),
        FontOption("system_mono", "System Mono", FontCategory.SYSTEM, FontSource.System("monospace"), "Platform font"),
        FontOption("system_condensed", "System Condensed", FontCategory.SYSTEM, FontSource.System("sans-serif-condensed"), "Platform font"),
        FontOption("system_casual", "System Casual", FontCategory.SYSTEM, FontSource.System("casual"), "Platform font"),
    )

    const val DEFAULT_ID = "inter"

    fun byId(id: String): FontOption = all.firstOrNull { it.id == id } ?: all.first { it.id == DEFAULT_ID }

    fun exists(id: String): Boolean = all.any { it.id == id }
}
