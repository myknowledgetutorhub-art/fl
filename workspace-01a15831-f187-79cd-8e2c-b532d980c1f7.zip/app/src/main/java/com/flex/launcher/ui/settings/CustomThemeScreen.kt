package com.flex.launcher.ui.settings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.theme.GradientDirection
import com.flex.launcher.domain.theme.ThemePalette
import com.flex.launcher.domain.theme.ThemePresets
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.ColorHexField
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SegmentedChoice
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/** Full custom palette editor with HEX validation and instant application. */
@Composable
fun CustomThemeScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val palette = prefs.customPalette

    fun update(transform: (ThemePalette) -> ThemePalette) {
        vm.updatePrefs { current ->
            current.copy(
                themeId = ThemePresets.CUSTOM_ID,
                customPalette = transform(current.customPalette),
            )
        }
    }

    SettingsScaffold(title = "Custom theme", onBack = onBack, subtitle = "Changes apply instantly") {
        SectionTitle("Brand colours")
        SettingsCard {
            ColorHexField("Primary", palette.primary) { c -> update { it.copy(primary = c) } }
            ColorHexField("Secondary", palette.secondary) { c -> update { it.copy(secondary = c) } }
            ColorHexField("Accent", palette.accent) { c -> update { it.copy(accent = c) } }
        }

        SectionTitle("Surfaces")
        SettingsCard {
            ColorHexField("Background", palette.background) { c -> update { it.copy(background = c) } }
            ColorHexField("Surface", palette.surface) { c -> update { it.copy(surface = c) } }
            ColorHexField("Card", palette.card) { c -> update { it.copy(card = c) } }
        }

        SectionTitle("Text")
        SettingsCard {
            ColorHexField("Primary text", palette.textPrimary) { c -> update { it.copy(textPrimary = c) } }
            ColorHexField("Secondary text", palette.textSecondary) { c -> update { it.copy(textSecondary = c) } }
        }

        SectionTitle("Gradient")
        SettingsCard {
            val hasGradient = palette.gradient.size >= 2
            if (hasGradient) {
                ColorHexField("Gradient start", palette.gradient[0]) { c ->
                    update { p -> p.copy(gradient = listOf(c) + p.gradient.drop(1)) }
                }
                ColorHexField("Gradient end", palette.gradient[1]) { c ->
                    update { p -> p.copy(gradient = p.gradient.take(1) + c) }
                }
                SegmentedChoice(
                    options = GradientDirection.entries,
                    selected = palette.direction,
                    onSelect = { dir -> update { it.copy(gradientDirection = dir.name) } },
                    label = { it.label.take(9) },
                )
                SettingsActionRow("Remove gradient", {
                    update { it.copy(gradient = emptyList(), gradientDirection = GradientDirection.NONE.name) }
                })
            } else {
                SettingsActionRow(
                    "Add a background gradient",
                    { update { it.copy(gradient = listOf(it.background, it.primary)) } },
                    "Blends two colours behind the launcher",
                )
            }
        }

        SectionTitle("Palette helpers")
        SettingsCard {
            SettingsActionRow("Derive from theme presets", {
                update { current ->
                    ThemePresets.all.firstOrNull { it.palette.background == current.background }?.palette
                        ?: ThemePresets.byId("midnight_black").palette
                }
            }, "Pulls the closest matching preset colours")
            SettingsActionRow("Reset custom colours", {
                vm.updatePrefs { it.copy(customPalette = ThemePalette.DEFAULT) }
            }, destructive = true)
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Text colours are automatically corrected if contrast falls below the accessibility " +
                "threshold, so labels stay readable.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(28.dp))
    }
}
