package com.flex.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.Image
import androidx.compose.ui.unit.sp
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.ui.icons.IconShapeRenderer
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalIconLoader
import com.flex.launcher.ui.theme.LocalLauncherColors
import androidx.compose.runtime.remember

/**
 * Renders the *real* application icon, clipped by the user's icon shape.
 *
 * Missing / unreadable icons degrade to a themed monogram (first letter of the label) instead
 * of a blank square or a crash.
 */
@Composable
fun AppIcon(
    entry: AppEntry,
    size: Dp,
    shape: IconShape,
    showPlate: Boolean,
    plateColor: Color,
    modifier: Modifier = Modifier,
) {
    val loader = LocalIconLoader.current
    val density = LocalDensity.current
    val sizePx = with(density) { size.roundToPx() }
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current

    val bitmap: ImageBitmap? by produceState<ImageBitmap?>(initialValue = null, entry.key, sizePx) {
        value = loader?.icon(entry, sizePx)
    }

    val clipShape = remember(shape) { IconShapeRenderer.shapeFor(shape) }
    val fallbackShape = remember(shape) {
        if (shape == IconShape.CIRCLE) RoundedCornerShape(percent = 50) else RoundedCornerShape(percent = 28)
    }

    Box(
        modifier = modifier
            .size(size)
            .then(if (showPlate) Modifier.background(plateColor, clipShape) else Modifier)
            .clip(clipShape),
        contentAlignment = Alignment.Center,
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!,
                contentDescription = entry.label,
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(size),
            )
        } else {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(fallbackShape)
                    .background(colors.primary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = entry.label.take(1).uppercase(),
                    style = type.label.copy(fontSize = (size.value * 0.42f).sp),
                    color = colors.primary,
                    textAlign = TextAlign.Center,
                )
            }
        }
    }
}
