package com.flex.launcher.data.apps

import android.graphics.Bitmap
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.flex.launcher.domain.model.AppEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Converts real PackageManager [android.graphics.drawable.Drawable] icons into [ImageBitmap]s
 * with a bounded LRU cache so a 400-app drawer does not exhaust the heap.
 */
class AppIconLoader(private val repository: AppRepository) {

    private val cache = object : LruCache<String, ImageBitmap>(MAX_BYTES) {
        override fun sizeOf(key: String, value: ImageBitmap): Int =
            value.width * value.height * 4
    }

    suspend fun icon(entry: AppEntry, sizePx: Int): ImageBitmap? = withContext(Dispatchers.IO) {
        val target = sizePx.coerceIn(32, 256)
        val key = "${entry.key}@$target"
        cache.get(key)?.let { return@withContext it }

        val drawable = repository.loadIcon(entry) ?: return@withContext null
        val bitmap = runCatching {
            drawable.toBitmap(target, target, Bitmap.Config.ARGB_8888).asImageBitmap()
        }.getOrNull() ?: return@withContext null
        cache.put(key, bitmap)
        bitmap
    }

    fun clear() = cache.evictAll()

    companion object {
        private const val MAX_BYTES = 12 * 1024 * 1024
    }
}
