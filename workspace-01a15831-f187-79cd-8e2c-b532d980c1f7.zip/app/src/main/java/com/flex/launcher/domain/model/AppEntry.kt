package com.flex.launcher.domain.model

/**
 * A launchable application activity discovered through PackageManager.
 * Contains no Android types so it can be sorted, filtered and tested on the JVM.
 */
data class AppEntry(
    val packageName: String,
    val activityName: String,
    val label: String,
) {
    /** Stable identity used for favourites and hidden-app persistence. */
    val key: String get() = "$packageName/$activityName"

    /** Sort key: lower-cased, accent-stripped label. */
    val sortKey: String get() = normalizeForSort(label)
}

/** Diacritic-insensitive, case-insensitive normalisation used for sorting and search. */
fun normalizeForSort(text: String): String {
    val decomposed = java.text.Normalizer.normalize(text, java.text.Normalizer.Form.NFD)
    return decomposed.replace(Regex("\\p{Mn}+"), "").lowercase().trim()
}

enum class RecentSource { USAGE_STATS, LOCAL_HISTORY }

data class RecentApp(
    val app: AppEntry,
    val lastUsedMillis: Long,
    val source: RecentSource,
)

/** Pure sorting/filtering/search helpers (unit tested). */
object AppQuery {

    fun visible(apps: List<AppEntry>, hidden: Set<String>): List<AppEntry> =
        apps.filter { it.packageName !in hidden }

    fun alphabetical(apps: List<AppEntry>): List<AppEntry> =
        apps.sortedWith(compareBy({ it.sortKey }, { it.packageName }, { it.activityName }))

    /**
     * Sorts by the supplied recency map (package -> last used). Unknown packages fall back
     * to alphabetical order and always sort after known ones.
     */
    fun byRecent(apps: List<AppEntry>, recency: Map<String, Long>): List<AppEntry> =
        apps.sortedWith(
            compareByDescending<AppEntry> { recency[it.packageName] ?: Long.MIN_VALUE }
                .thenBy { it.sortKey },
        )

    /**
     * Case/diacritic-insensitive search. Matches label, and also package name (useful when
     * an app's visible name differs from its package). Blank query returns [apps] unchanged.
     */
    fun search(apps: List<AppEntry>, query: String): List<AppEntry> {
        val q = normalizeForSort(query)
        if (q.isBlank()) return apps
        return apps.filter { app ->
            app.sortKey.contains(q) || app.packageName.lowercase().contains(q)
        }
    }

    fun sorted(apps: List<AppEntry>, mode: AppSortMode, recency: Map<String, Long>): List<AppEntry> =
        when (mode) {
            AppSortMode.ALPHABETICAL -> alphabetical(apps)
            AppSortMode.RECENT -> byRecent(apps, recency)
        }
}
