package com.flex.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.AppQuery
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.AppIcon
import com.flex.launcher.ui.components.EmptyState
import com.flex.launcher.ui.components.LauncherSearchField
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/**
 * Hide Apps management. Hidden packages are filtered from the home collections, the drawer
 * and search. This is a launcher-level filter only — it is NOT a vault and does not disable
 * or uninstall anything.
 */
@Composable
fun HideAppsScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val allApps by vm.allAppsIncludingHidden.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }

    val listed = remember(allApps, query) {
        AppQuery.alphabetical(AppQuery.search(allApps, query))
            .filter { it.packageName != vm.selfPackageName() }
    }
    val hiddenCount = prefs.hiddenApps.size

    SettingsScaffoldFixed(
        title = "Hide apps",
        onBack = onBack,
        subtitle = "$hiddenCount hidden · ${listed.size} available",
    ) {
        Column(Modifier.fillMaxSize()) {
            LauncherSearchField(
                query = query,
                onQueryChange = { query = it },
                placeholder = "Search installed apps",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Tap an app to hide or unhide it",
                    style = type.label,
                    color = colors.textSecondary,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    "Reset",
                    style = type.label,
                    color = Color(0xFFEF5350),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = hiddenCount > 0) { confirmReset = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                )
            }

            if (listed.isEmpty()) {
                EmptyState(
                    title = "No matching apps",
                    message = if (query.isBlank()) {
                        "No launchable apps were found on this device."
                    } else {
                        "Nothing matches “$query”."
                    },
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    items(listed, key = { it.key }) { app ->
                        HideAppRow(
                            app = app,
                            hidden = app.packageName in prefs.hiddenApps,
                            onToggle = { hidden -> vm.setAppHidden(app.packageName, hidden) },
                        )
                    }
                    item {
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Hiding an app only removes it from Flex Launcher. It stays installed, " +
                                "visible in Android Settings and other launchers, and it is not disabled " +
                                "at the system level. Flex Launcher cannot hide itself so you never lose " +
                                "access to these settings.",
                            style = type.label,
                            color = colors.textSecondary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                        )
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Unhide all apps?") },
            text = {
                Text(
                    "All $hiddenCount hidden apps will reappear in Flex Launcher. " +
                        "Installed apps themselves are not affected.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    vm.clearHiddenApps()
                    vm.postMessage("All hidden apps are visible again")
                }) { Text("Unhide all") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            },
        )
    }
}

@Composable
private fun HideAppRow(app: AppEntry, hidden: Boolean, onToggle: (Boolean) -> Unit) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (hidden) colors.primary.copy(alpha = 0.10f) else Color.Transparent)
            .clickable { onToggle(!hidden) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(
            entry = app,
            size = 38.dp,
            shape = IconShape.ROUNDED_SQUARE,
            showPlate = false,
            plateColor = Color.Transparent,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                app.label,
                style = type.body,
                color = colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                app.packageName,
                style = type.label,
                color = colors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (hidden) {
            Icon(Icons.Filled.Check, contentDescription = "Hidden", tint = colors.primary)
            Spacer(Modifier.width(8.dp))
        }
        Checkbox(
            checked = hidden,
            onCheckedChange = { onToggle(it) },
            colors = CheckboxDefaults.colors(checkedColor = colors.primary),
        )
    }
}
