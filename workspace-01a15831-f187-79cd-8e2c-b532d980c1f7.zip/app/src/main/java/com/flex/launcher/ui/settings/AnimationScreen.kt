package com.flex.launcher.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.animations.AnimationStyle
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.animations.LauncherAnimations
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/** Motion settings with a real, replayable preview of the selected style. */
@Composable
fun AnimationScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val anim = prefs.animations
    var previewVisible by remember { mutableStateOf(true) }

    fun update(transform: (AnimationSettings) -> AnimationSettings) {
        vm.updatePrefs { it.copy(animations = transform(it.animations).sanitized()) }
    }

    SettingsScaffold(title = "Animations", onBack = onBack, subtitle = anim.drawerStyle.label) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(colors.card)
                .padding(14.dp),
        ) {
            Column {
                Text("Preview · ${anim.drawerStyle.label}", style = type.label, color = colors.textSecondary)
                Spacer(Modifier.height(8.dp))
                AnimatedVisibility(
                    visible = previewVisible,
                    enter = LauncherAnimations.enterFor(anim.drawerStyle, anim),
                    exit = LauncherAnimations.exitFor(anim.drawerStyle, anim),
                ) {
                    Column {
                        repeat(3) { index ->
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(22.dp)
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when (index) {
                                            0 -> colors.primary.copy(alpha = 0.8f)
                                            1 -> colors.secondary.copy(alpha = 0.6f)
                                            else -> colors.accent.copy(alpha = 0.45f)
                                        },
                                    ),
                            )
                        }
                    }
                }
                Spacer(Modifier.weight(1f))
                Text(
                    if (previewVisible) "Tap “Replay” to run it again" else "Hidden — tap Replay",
                    style = type.label,
                    color = colors.textSecondary,
                )
            }
        }
        SettingsActionRow(
            "Replay preview",
            { previewVisible = false },
            "Hides the sample, then plays the enter transition again",
        )
        // Re-show after hiding so the enter transition runs.
        LaunchedEffect(previewVisible) {
            if (!previewVisible) {
                delay(140)
                previewVisible = true
            }
        }

        SectionTitle("Motion")
        SettingsCard {
            SettingsSwitchRow(
                title = "Enable animations",
                description = "Turn off for maximum performance or battery saving",
                checked = anim.enabled,
                onCheckedChange = { on -> update { it.copy(enabled = on) } },
            )
            SettingsSwitchRow(
                title = "Reduced motion",
                description = "Respects accessibility preferences by disabling all transitions",
                checked = anim.reducedMotion,
                onCheckedChange = { on -> update { it.copy(reducedMotion = on) } },
            )
            SettingsSliderRow(
                "Animation speed", anim.speed,
                { v -> update { it.copy(speed = v) } },
                AnimationSettings.SPEED,
                valueLabel = { String.format(java.util.Locale.US, "%.2f×", it) },
                description = "1.00× is the default duration; higher values are faster",
                onReset = { update { it.copy(speed = 1f) } },
            )
        }

        SectionTitle("Style per surface")
        StylePicker("App drawer", anim.drawerStyle) { style ->
            update { it.copy(drawerStyleId = style.id) }
        }
        StylePicker("Settings screens", anim.sheetStyle) { style ->
            update { it.copy(sheetStyleId = style.id) }
        }
        StylePicker("Search results", anim.searchStyle) { style ->
            update { it.copy(searchStyleId = style.id) }
        }
        StylePicker("Theme changes", anim.themeStyle) { style ->
            update { it.copy(themeStyleId = style.id) }
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Launchers cannot change the system's app-open animation. These settings cover Flex " +
                "Launcher's own surfaces (drawer, settings, search results).",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StylePicker(
    title: String,
    selected: AnimationStyle,
    onSelect: (AnimationStyle) -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, top = 12.dp, bottom = 6.dp),
        ) {
            Text(title.uppercase(), style = type.label, color = colors.textSecondary)
        }
        AnimationStyle.all.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                row.forEach { style ->
                    val isSelected = style == selected
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) colors.primary.copy(alpha = 0.14f) else colors.card)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) colors.primary else colors.textSecondary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(14.dp),
                            )
                            .clickable { onSelect(style) }
                            .padding(10.dp),
                    ) {
                        Text(style.label, style = type.body, color = colors.textPrimary, maxLines = 1)
                        Text(
                            style.description,
                            style = type.label.copy(fontSize = type.label.fontSize * 0.9f),
                            color = colors.textSecondary,
                            maxLines = 2,
                        )
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
