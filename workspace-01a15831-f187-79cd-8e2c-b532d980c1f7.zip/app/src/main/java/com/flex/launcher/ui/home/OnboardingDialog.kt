package com.flex.launcher.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/** First-run guide. Every button performs a real action. */
@Composable
fun OnboardingDialog(
    usageGranted: Boolean,
    onOpenUsageSettings: () -> Unit,
    onSetDefaultLauncher: () -> Unit,
    onDone: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    var step by rememberSaveable { mutableStateOf(0) }

    val steps = listOf(
        Triple(
            "Welcome to Flex Launcher",
            "Flex Launcher is a home screen replacement. Nothing changes until you set it as your " +
                "default HOME app — Android always asks you to confirm that.",
            "Continue",
        ),
        Triple(
            "Set Flex Launcher as your default",
            "Open Android's default-app screen and choose Flex Launcher for Home. You can switch " +
                "back at any time in the same screen.",
            "Open default app settings",
        ),
        Triple(
            "Optional: Usage access",
            "Recent apps can use Android's UsageStats data. That requires the separate “Usage access” " +
                "permission. Flex Launcher also works without it using its own local history.",
            "Open Usage access settings",
        ),
    )

    Dialog(onDismissRequest = onDone) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = colors.card),
        ) {
            Column(Modifier.padding(22.dp)) {
                Text(steps[step].first, style = type.heading, color = colors.textPrimary)
                Spacer(Modifier.height(8.dp))
                Text(steps[step].second, style = type.body, color = colors.textSecondary)
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextButton(onClick = onDone) { Text("Skip") }
                    Spacer(Modifier.padding(4.dp))
                    Button(
                        onClick = {
                            when (step) {
                                1 -> onSetDefaultLauncher()
                                2 -> if (!usageGranted) onOpenUsageSettings()
                            }
                            if (step >= steps.lastIndex) onDone() else step += 1
                        },
                    ) {
                        Text(if (step == steps.lastIndex) "Start using Flex Launcher" else steps[step].third)
                    }
                }
            }
        }
    }
}
