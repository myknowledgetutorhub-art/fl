package com.flex.launcher.ui.settings

/** Navigation routes for the settings subtree. */
object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val HOME_SCREEN = "settings/home-screen"
    const val RECENTS = "settings/recents"
    const val DRAWER = "settings/drawer"
    const val HIDE_APPS = "settings/hide-apps"
    const val THEME = "settings/theme"
    const val CUSTOM_THEME = "settings/theme/custom"
    const val TYPOGRAPHY = "settings/typography"
    const val ICONS = "settings/icons"
    const val ANIMATIONS = "settings/animations"
    const val STATUS_BAR = "settings/status-bar"
    const val DIALER = "settings/dialer"
    const val PERMISSIONS = "settings/permissions"
    const val BACKUP = "settings/backup"
    const val ABOUT = "settings/about"
}
