package com.flex.launcher.domain.model

/**
 * Merges system UsageStats data with the locally observed launch history.
 *
 * UsageStats is authoritative when available (it survives launcher data clears and reflects
 * launches made from any launcher) but it can be unavailable because the user never granted
 * Usage Access. The local history is always maintained as a fallback, so the Recent Apps
 * section is never empty for no reason and never fake.
 */
object RecentResolver {

    /**
     * @param preferUsageStats when false the system UsageStats data is ignored completely
     *   (the user disabled usage tracking, or Usage access was not granted). The local history
     *   then becomes the only source, which keeps the section honest instead of mixing
     *   partially-available system data with local launches.
     */
    fun resolve(
        apps: List<AppEntry>,
        usageStats: Map<String, Long>,
        localHistory: Map<String, Long>,
        hidden: Set<String>,
        limit: Int,
        preferUsageStats: Boolean,
    ): List<RecentApp> {
        if (limit <= 0) return emptyList()
        val byPackage = apps.groupBy { it.packageName }
        val merged = LinkedHashMap<String, Pair<Long, RecentSource>>()

        fun consider(source: RecentSource, values: Map<String, Long>, canOverride: Boolean) {
            values.forEach { (pkg, ts) ->
                if (pkg in hidden || pkg !in byPackage) return@forEach
                val existing = merged[pkg]
                if (existing == null || canOverride || ts > existing.first) {
                    merged[pkg] = ts to source
                }
            }
        }

        if (preferUsageStats && usageStats.isNotEmpty()) {
            consider(RecentSource.USAGE_STATS, usageStats, canOverride = true)
            // Local history fills gaps only where UsageStats knows nothing. It never
            // overrides a fresher system timestamp.
            consider(RecentSource.LOCAL_HISTORY, localHistory, canOverride = false)
        } else {
            // UsageStats disabled or unavailable: local launches only.
            consider(RecentSource.LOCAL_HISTORY, localHistory, canOverride = true)
        }

        return merged.entries
            .sortedByDescending { it.value.first }
            .mapNotNull { (pkg, value) ->
                val app = byPackage[pkg]?.firstOrNull() ?: return@mapNotNull null
                RecentApp(app, value.first, value.second)
            }
            .take(limit)
    }
}
