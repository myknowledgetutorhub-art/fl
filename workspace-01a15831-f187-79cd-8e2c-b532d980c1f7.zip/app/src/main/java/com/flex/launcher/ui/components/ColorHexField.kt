package com.flex.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.flex.launcher.core.util.HexColor
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/**
 * HEX colour editor with live validation. Invalid input never reaches preferences; the field
 * shows exactly what is wrong instead of silently discarding the value.
 */
@Composable
fun ColorHexField(
    label: String,
    color: Int,
    modifier: Modifier = Modifier,
    onColorChange: (Int) -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    var text by remember { mutableStateOf(HexColor.format(color)) }
    var error by remember { mutableStateOf<String?>(null) }

    // Keep the field in sync when the colour changes elsewhere (preset switch / reset).
    LaunchedEffect(color) {
        if (HexColor.parse(text) != color) {
            text = HexColor.format(color)
            error = null
        }
    }

    Column(modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(label, style = type.body, color = colors.textPrimary)
        Spacer(Modifier.size(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(color))
                    .border(1.dp, colors.textSecondary.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            )
            Spacer(Modifier.width(10.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { input ->
                    text = input
                    val parsed = HexColor.parse(input)
                    if (parsed == null) {
                        error = "Enter #RRGGBB or #AARRGGBB"
                    } else {
                        error = null
                        onColorChange(parsed)
                    }
                },
                singleLine = true,
                isError = error != null,
                label = { Text("#RRGGBB") },
                supportingText = error?.let { { Text(it) } },
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Characters,
                    imeAction = ImeAction.Done,
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = colors.textPrimary,
                    unfocusedTextColor = colors.textPrimary,
                    focusedBorderColor = colors.primary,
                    unfocusedBorderColor = colors.textSecondary.copy(alpha = 0.4f),
                    errorBorderColor = Color(0xFFEF5350),
                    focusedLabelColor = colors.primary,
                    unfocusedLabelColor = colors.textSecondary,
                    errorSupportingTextColor = Color(0xFFEF5350),
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("color_field_$label"),
            )
        }
    }
}

/** Row of quick swatches for the custom theme editor. */
@Composable
fun SwatchRow(
    swatches: List<Int>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        swatches.forEach { value ->
            Box(
                Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Color(value))
                    .border(
                        width = if (value == selected) 2.dp else 1.dp,
                        color = if (value == selected) colors.primary else colors.textSecondary.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(9.dp),
                    )
                    .clickableNoRipple { onSelect(value) },
            )
        }
    }
}
