package com.flex.launcher.ui

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.flex.launcher.domain.animations.AnimationScope
import com.flex.launcher.domain.theme.ThemePresets
import com.flex.launcher.ui.animations.LauncherAnimations
import com.flex.launcher.ui.home.LauncherScreen
import com.flex.launcher.ui.settings.AboutScreen
import com.flex.launcher.ui.settings.AnimationScreen
import com.flex.launcher.ui.settings.BackupScreen
import com.flex.launcher.ui.settings.CustomThemeScreen
import com.flex.launcher.ui.settings.DialerSettingsScreen
import com.flex.launcher.ui.settings.DrawerSettingsScreen
import com.flex.launcher.ui.settings.HideAppsScreen
import com.flex.launcher.ui.settings.HomeScreenSettings
import com.flex.launcher.ui.settings.IconStudioScreen
import com.flex.launcher.ui.settings.PermissionsScreen
import com.flex.launcher.ui.settings.RecentsSettingsScreen
import com.flex.launcher.ui.settings.Routes
import com.flex.launcher.ui.settings.SettingsHomeScreen
import com.flex.launcher.ui.settings.StatusBarSettingsScreen
import com.flex.launcher.ui.settings.ThemeStudioScreen
import com.flex.launcher.ui.settings.TypographyScreen
import com.flex.launcher.ui.theme.FlexTheme
import com.flex.launcher.ui.theme.FlexType
import com.flex.launcher.ui.theme.resolveLauncherColors

/**
 * Root composable: resolves the theme from preferences, controls system-bar appearance and
 * hosts the launcher + settings navigation graph.
 */
@Composable
fun FlexApp(vm: MainViewModel) {
    val prefs by vm.prefs.collectAsStateWithLifecycle()
    val wallpaperPalette by vm.wallpaperPalette.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

    val dynamicScheme = remember(prefs.dynamicColor, systemDark) {
        if (prefs.dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (systemDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else {
            null
        }
    }

    val colors = remember(prefs, systemDark, wallpaperPalette, dynamicScheme) {
        resolveLauncherColors(prefs, systemDark, wallpaperPalette, dynamicScheme)
    }
    val type = remember(prefs.typography) { FlexType.from(prefs.typography) }

    // The wallpaper-derived palette is only computed when that theme is selected.
    LaunchedEffect(prefs.themeId) {
        if (prefs.themeId == "wallpaper" && wallpaperPalette == null) {
            vm.wallpaperPaletteNow()
        }
    }

    FlexTheme(
        colors = colors,
        type = type,
        animations = prefs.animations,
        iconLoader = vm.iconLoader,
    ) {
        SystemBarAppearance(lightIcons = colors.statusBarIconsDark)

        val navController = rememberNavController()
        val snackbarHostState = remember { SnackbarHostState() }

        LaunchedEffect(Unit) {
            vm.messages.collect { message -> snackbarHostState.showSnackbar(message.text) }
        }
        LaunchedEffect(Unit) {
            vm.homeRequests.collect {
                navController.popBackStack(Routes.HOME, inclusive = false)
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(colors.background),
        ) {
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                enterTransition = { LauncherAnimations.enter(prefs.animations, AnimationScope.SHEET) },
                exitTransition = { LauncherAnimations.exit(prefs.animations, AnimationScope.SHEET) },
                popEnterTransition = { LauncherAnimations.enter(prefs.animations, AnimationScope.SHEET) },
                popExitTransition = { LauncherAnimations.exit(prefs.animations, AnimationScope.SHEET) },
            ) {
                composable(Routes.HOME) {
                    LauncherScreen(
                        vm = vm,
                        prefs = prefs,
                        colors = colors,
                        onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                    )
                }
                composable(Routes.SETTINGS) {
                    SettingsHomeScreen(
                        vm = vm,
                        prefs = prefs,
                        onBack = { navController.popBackStack() },
                        onNavigate = { route -> navController.navigate(route) },
                    )
                }
                composable(Routes.HOME_SCREEN) {
                    HomeScreenSettings(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.RECENTS) {
                    RecentsSettingsScreen(
                        vm = vm,
                        prefs = prefs,
                        onBack = { navController.popBackStack() },
                        onOpenPermissions = { navController.navigate(Routes.PERMISSIONS) },
                    )
                }
                composable(Routes.DRAWER) {
                    DrawerSettingsScreen(
                        vm = vm,
                        onBack = { navController.popBackStack() },
                        onOpenIcons = { navController.navigate(Routes.ICONS) },
                    )
                }
                composable(Routes.HIDE_APPS) {
                    HideAppsScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.THEME) {
                    ThemeStudioScreen(
                        vm = vm,
                        prefs = prefs,
                        onBack = { navController.popBackStack() },
                        onEditCustom = { navController.navigate(Routes.CUSTOM_THEME) },
                    )
                }
                composable(Routes.CUSTOM_THEME) {
                    CustomThemeScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.TYPOGRAPHY) {
                    TypographyScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.ICONS) {
                    IconStudioScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.ANIMATIONS) {
                    AnimationScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.STATUS_BAR) {
                    StatusBarSettingsScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.DIALER) {
                    DialerSettingsScreen(vm, onBack = { navController.popBackStack() })
                }
                composable(Routes.PERMISSIONS) {
                    PermissionsScreen(vm, onBack = { navController.popBackStack() })
                }
                composable(Routes.BACKUP) {
                    BackupScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
                composable(Routes.ABOUT) {
                    AboutScreen(vm, prefs, onBack = { navController.popBackStack() })
                }
            }

            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(16.dp),
            )
        }
    }
}

/** Keeps status/navigation bar icon contrast in sync with the active theme. */
@Composable
private fun SystemBarAppearance(lightIcons: Boolean) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = lightIcons
            controller.isAppearanceLightNavigationBars = lightIcons
        }
    }
}
