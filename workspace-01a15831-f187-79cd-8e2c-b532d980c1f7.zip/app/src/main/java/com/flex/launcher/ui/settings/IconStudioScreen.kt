package com.flex.launcher.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.icons.IconSettings
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.ColorHexField
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.icons.IconShapeRenderer
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

/** 12 genuine icon masks plus sizing, spacing, columns and plate options. */
@Composable
fun IconStudioScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val icons = prefs.icons

    fun update(transform: (IconSettings) -> IconSettings) {
        vm.updatePrefs { it.copy(icons = transform(it.icons).sanitized()) }
    }

    SettingsScaffold(title = "Icons & shapes", onBack = onBack, subtitle = icons.shape.label) {
        SectionTitle("Shape (${IconShape.all.size} masks)")
        Box(Modifier.fillMaxWidth()) {
            Column {
                IconShape.all.chunked(4).forEach { row ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                    ) {
                        row.forEach { shape ->
                            ShapeTile(
                                shape = shape,
                                selected = icons.shapeId == shape.id,
                                onClick = { update { it.copy(shapeId = shape.id) } },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                    Spacer(Modifier.height(10.dp))
                }
            }
        }

        SectionTitle("Size & layout")
        SettingsCard {
            SettingsSliderRow(
                "Icon size", icons.sizeDp,
                { v -> update { it.copy(sizeDp = v) } },
                IconSettings.ICON_SIZE,
                valueLabel = { "${it.toInt()} dp" },
                onReset = { update { it.copy(sizeDp = IconSettings.DEFAULT.sizeDp) } },
            )
            SettingsSliderRow(
                "Icon spacing", icons.spacingDp,
                { v -> update { it.copy(spacingDp = v) } },
                IconSettings.ICON_SPACING,
                valueLabel = { "${it.toInt()} dp" },
                onReset = { update { it.copy(spacingDp = IconSettings.DEFAULT.spacingDp) } },
            )
            SettingsSliderRow(
                "Home screen columns", icons.homeColumns.toFloat(),
                { v -> update { it.copy(homeColumns = v.toInt()) } },
                IconSettings.HOME_COLUMNS.start.toFloat()..IconSettings.HOME_COLUMNS.endInclusive.toFloat(),
                steps = 3,
                valueLabel = { it.toInt().toString() },
                onReset = { update { it.copy(homeColumns = IconSettings.DEFAULT.homeColumns) } },
            )
            SettingsSliderRow(
                "App drawer columns", icons.drawerColumns.toFloat(),
                { v -> update { it.copy(drawerColumns = v.toInt()) } },
                IconSettings.DRAWER_COLUMNS.start.toFloat()..IconSettings.DRAWER_COLUMNS.endInclusive.toFloat(),
                steps = 3,
                valueLabel = { it.toInt().toString() },
                onReset = { update { it.copy(drawerColumns = IconSettings.DEFAULT.drawerColumns) } },
            )
        }

        SectionTitle("Labels & background")
        SettingsCard {
            SettingsSwitchRow(
                title = "Show icon labels",
                description = "Applies to home screen, drawer and search results",
                checked = icons.showLabels,
                onCheckedChange = { show -> update { it.copy(showLabels = show) } },
            )
            SettingsActionRow(
                "Label sizes",
                { },
                "Home and drawer label sizes live in Fonts & typography",
            )
            SettingsSwitchRow(
                title = "Icon background plate",
                description = "Draws a coloured shape behind transparent icons",
                checked = icons.backgroundPlate,
                onCheckedChange = { plate -> update { it.copy(backgroundPlate = plate) } },
            )
            if (icons.backgroundPlate) {
                ColorHexField("Plate colour", icons.backgroundPlateColor and 0xFFFFFF or (0xFF shl 24)) { c ->
                    update { it.copy(backgroundPlateColor = c) }
                }
            }
            SettingsActionRow("Reset icons & shapes", {
                vm.updatePrefs {
                    it.copy(
                        icons = IconSettings.DEFAULT.copy(
                            homeColumns = it.icons.homeColumns,
                            drawerColumns = it.icons.drawerColumns,
                        ),
                    )
                }
            }, destructive = true)
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Android draws third-party icons from each app's provided assets (adaptive or legacy). " +
                "Flex Launcher can only mask those assets — it cannot redraw an app's artwork, and legacy " +
                "icons with baked-in transparency will show the plate/holes they were shipped with.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ShapeTile(
    shape: IconShape,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val mask = IconShapeRenderer.shapeFor(shape)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) colors.primary.copy(alpha = 0.12f) else colors.card.copy(alpha = 0.6f))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) colors.primary else colors.textSecondary.copy(alpha = 0.15f),
                shape = RoundedCornerShape(14.dp),
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(mask)
                .background(
                    Brush.linearGradient(listOf(colors.primary, colors.secondary)),
                ),
        )
        Spacer(Modifier.height(6.dp))
        Text(
            shape.label,
            style = type.label.copy(fontSize = type.label.fontSize * 0.85f),
            color = colors.textSecondary,
            maxLines = 1,
        )
    }
}
