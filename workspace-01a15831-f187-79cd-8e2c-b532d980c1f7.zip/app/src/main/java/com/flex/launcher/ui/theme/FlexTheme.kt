package com.flex.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.flex.launcher.data.apps.AppIconLoader
import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.theme.ThemePresets

val LocalLauncherColors = staticCompositionLocalOf<LauncherColors> {
    val palette = ThemePresets.byId("midnight_black").palette
    LauncherColors(
        background = Color(palette.background),
        backgroundGradient = emptyList(),
        gradientDirection = palette.direction,
        surface = Color(palette.surface),
        card = Color(palette.card),
        primary = Color(palette.primary),
        secondary = Color(palette.secondary),
        accent = Color(palette.accent),
        textPrimary = Color(palette.textPrimary),
        textSecondary = Color(palette.textSecondary),
        isLight = false,
        statusBarIconsDark = false,
        backgroundOpacity = 100f,
    )
}

val LocalFlexType = staticCompositionLocalOf { FlexType.Default }
val LocalAnimationSettings = staticCompositionLocalOf { AnimationSettings.DEFAULT }
val LocalIconLoader = staticCompositionLocalOf<AppIconLoader?> { null }

/**
 * Provides launcher colours, typography and motion settings to the whole UI and keeps
 * Material 3 components in sync with the user's theme.
 */
@Composable
fun FlexTheme(
    colors: LauncherColors,
    type: FlexType,
    animations: AnimationSettings,
    iconLoader: AppIconLoader? = null,
    content: @Composable () -> Unit,
) {
    val materialScheme = remember(colors) { colors.toMaterialColorScheme() }
    val materialTypography = remember(type.fontFamily) { Typography().withFont(type.fontFamily) }
    CompositionLocalProvider(
        LocalLauncherColors provides colors,
        LocalFlexType provides type,
        LocalAnimationSettings provides animations,
        LocalIconLoader provides iconLoader,
    ) {
        MaterialTheme(
            colorScheme = materialScheme,
            typography = materialTypography,
            content = content,
        )
    }
}
