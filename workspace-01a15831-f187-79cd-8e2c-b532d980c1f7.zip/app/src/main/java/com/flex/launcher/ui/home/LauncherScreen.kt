package com.flex.launcher.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flex.launcher.domain.animations.AnimationScope
import com.flex.launcher.domain.dialer.DialerIntents
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.ui.AppsState
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.animations.LauncherAnimations
import com.flex.launcher.core.util.rememberHaptics
import com.flex.launcher.ui.dialer.DialerScreen
import com.flex.launcher.ui.dialer.dialErrorOrNull
import com.flex.launcher.ui.drawer.AppDrawer
import com.flex.launcher.ui.drawer.DrawerCallbacks
import com.flex.launcher.ui.theme.LauncherColors

/**
 * Root launcher surface: home screen, app drawer overlay, dial-pad overlay and first-run
 * experience. Everything is state-driven so process death / rotation restores correctly
 * (drawer + dial-pad state are rememberSaveable).
 */
@Composable
fun LauncherScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    colors: LauncherColors,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val appsState by vm.appsState.collectAsStateWithLifecycle()
    val visibleApps by vm.visibleApps.collectAsStateWithLifecycle()
    val recents by vm.recentApps.collectAsStateWithLifecycle()
    val pinned by vm.pinnedApps.collectAsStateWithLifecycle()
    val usageGranted by vm.usageAccessGranted.collectAsStateWithLifecycle()
    val isDefault by vm.isDefaultLauncher.collectAsStateWithLifecycle()
    val recencyRank by vm.recencyRank.collectAsStateWithLifecycle()

    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var dialerOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var dialNumber by rememberSaveable { mutableStateOf("") }
    var dialError by rememberSaveable { mutableStateOf<String?>(null) }
    var showOnboarding by rememberSaveable { mutableStateOf(!prefs.onboardingCompleted) }
    val haptics = rememberHaptics(prefs.hapticsEnabled)

    BackHandler(enabled = drawerOpen || dialerOpen) {
        when {
            dialerOpen -> dialerOpen = false
            drawerOpen -> {
                drawerOpen = false
                query = ""
            }
        }
    }

    // Refresh permission + usage data whenever the launcher becomes visible again.
    LaunchedEffect(Unit) { vm.onScreenResumed() }

    Box(modifier.fillMaxSize()) {
        LauncherBackground(prefs = prefs, colors = colors)

        if (prefs.statusBar.showScrim) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Black.copy(alpha = prefs.statusBar.scrimAlpha),
                                Color.Transparent,
                            ),
                        ),
                    ),
            )
        }

        HomeScreen(
            prefs = prefs,
            colors = colors,
            pinned = pinned,
            recents = recents,
            isDefaultLauncher = isDefault,
            loadingApps = appsState is AppsState.Loading,
            callbacks = HomeCallbacks(
                onLaunch = { entry ->
                    haptics.tap()
                    vm.launchApp(entry)
                },
                onOpenDrawer = { drawerOpen = true },
                onOpenSettings = onOpenSettings,
                onOpenDialer = {
                    dialNumber = ""
                    dialError = null
                    dialerOpen = true
                },
                onSetDefaultLauncher = { vm.openDefaultLauncherSettings() },
            ),
        )

        AnimatedVisibility(
            visible = drawerOpen,
            enter = LauncherAnimations.enter(prefs.animations, AnimationScope.DRAWER),
            exit = LauncherAnimations.exit(prefs.animations, AnimationScope.DRAWER),
        ) {
            AppDrawer(
                prefs = prefs,
                apps = visibleApps,
                recents = recents,
                pinned = pinned,
                recencyRank = recencyRank,
                query = query,
                onQueryChange = { query = it },
                appsLoading = appsState is AppsState.Loading,
                appsError = (appsState as? AppsState.Error)?.message,
                usageAccessGranted = usageGranted,
                callbacks = DrawerCallbacks(
                    onLaunch = { entry: AppEntry ->
                        haptics.tap()
                        vm.launchApp(entry)
                        drawerOpen = false
                        query = ""
                    },
                    onClose = {
                        drawerOpen = false
                        query = ""
                    },
                    onOpenSettings = {
                        drawerOpen = false
                        onOpenSettings()
                    },
                    onPinToggle = { entry ->
                        haptics.longPress()
                        vm.togglePinned(entry)
                        vm.postMessage(
                            if (vm.isPinned(entry)) "${entry.label} removed from home"
                            else "${entry.label} pinned to home",
                        )
                    },
                    onHide = { entry ->
                        vm.setAppHidden(entry.packageName, true)
                        vm.postMessage("${entry.label} hidden — manage it in Settings › Hide Apps")
                    },
                    onAppInfo = { entry -> vm.openAppInfo(entry.packageName) },
                    onOpenUsageSettings = { vm.openUsageAccessSettings() },
                    onSortChange = { mode ->
                        vm.updatePrefs { it.copy(drawer = it.drawer.copy(sortMode = mode)) }
                    },
                ),
            )
        }

        AnimatedVisibility(
            visible = dialerOpen,
            enter = LauncherAnimations.enter(prefs.animations, AnimationScope.SHEET),
            exit = LauncherAnimations.exit(prefs.animations, AnimationScope.SHEET),
        ) {
            DialerScreen(
                number = dialNumber,
                onNumberChange = {
                    dialNumber = it
                    dialError = dialErrorOrNull(it)
                },
                error = dialError,
                onDial = {
                    val error = DialerIntents.validationError(dialNumber)
                    if (error != null) {
                        dialError = error
                    } else {
                        vm.dial(dialNumber)
                        dialerOpen = false
                    }
                },
                onDismiss = { dialerOpen = false },
            )
        }

        if (showOnboarding) {
            OnboardingDialog(
                usageGranted = usageGranted,
                onOpenUsageSettings = { vm.openUsageAccessSettings() },
                onSetDefaultLauncher = { vm.openDefaultLauncherSettings() },
                onDone = {
                    showOnboarding = false
                    vm.completeOnboarding()
                },
            )
        }
    }
}
