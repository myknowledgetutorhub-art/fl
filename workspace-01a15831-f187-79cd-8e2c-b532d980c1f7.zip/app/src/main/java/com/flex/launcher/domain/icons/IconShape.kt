package com.flex.launcher.domain.icons

import kotlinx.serialization.Serializable

/**
 * Pure geometry description of an icon mask. Kept free of Compose types so the geometry can
 * be unit tested on the JVM; `ui/icons/IconShapeRenderer.kt` converts it to a Compose [Shape].
 */
@Serializable
sealed interface ShapeGeometry {
    /** Circle inscribed in the frame. */
    data object Circle : ShapeGeometry

    /** Axis-aligned rectangle with [radiusRatio] of the shorter side as corner radius. */
    data class RoundedRect(val radiusRatio: Float) : ShapeGeometry

    /** Plain rectangle. */
    data object Rect : ShapeGeometry

    /** Superellipse (squircle) with exponent [exponent]; 4f ≈ classic squircle. */
    data class Superellipse(val exponent: Float) : ShapeGeometry

    /** Rounded square with a single sharp corner at [sharpCorner]. */
    data class Teardrop(val sharpCorner: Corner, val radiusRatio: Float = 0.42f) : ShapeGeometry

    /** Regular polygon with [sides] vertices, flat-top or point-up per [rotationDeg]. */
    data class RegularPolygon(val sides: Int, val rotationDeg: Float = 0f, val inset: Float = 0.98f) : ShapeGeometry

    /** Polar flower with [lobes] petals. */
    data class Flower(val lobes: Int, val amplitude: Float = 0.16f) : ShapeGeometry

    /** Organic, slightly irregular pebble. */
    data object Pebble : ShapeGeometry

    /** Classic shield: flat top, pointed bottom. */
    data object Shield : ShapeGeometry

    /** Diamond with rounded vertices. */
    data class RoundedDiamond(val radiusRatio: Float = 0.22f) : ShapeGeometry
}

enum class Corner { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }

enum class IconShape(
    val id: String,
    val label: String,
    val geometry: ShapeGeometry,
) {
    CIRCLE("circle", "Circle", ShapeGeometry.Circle),
    ROUNDED_SQUARE("rounded_square", "Rounded square", ShapeGeometry.RoundedRect(0.22f)),
    SQUARE("square", "Square", ShapeGeometry.Rect),
    SQUIRCLE("squircle", "Squircle", ShapeGeometry.Superellipse(4f)),
    TEARDROP("teardrop", "Teardrop", ShapeGeometry.Teardrop(Corner.BOTTOM_RIGHT, 0.42f)),
    HEXAGON("hexagon", "Hexagon", ShapeGeometry.RegularPolygon(6, 0f)),
    OCTAGON("octagon", "Octagon", ShapeGeometry.RegularPolygon(8, 22.5f)),
    DIAMOND("diamond", "Diamond", ShapeGeometry.RegularPolygon(4, 0f, 0.99f)),
    FLOWER("flower", "Flower", ShapeGeometry.Flower(4, 0.18f)),
    PEBBLE("pebble", "Pebble", ShapeGeometry.Pebble),
    SHIELD("shield", "Shield", ShapeGeometry.Shield),
    ROUNDED_DIAMOND("rounded_diamond", "Rounded diamond", ShapeGeometry.RoundedDiamond(0.24f));

    companion object {
        const val DEFAULT_ID = "squircle"
        val all: List<IconShape> = entries
        fun fromId(id: String?): IconShape = entries.firstOrNull { it.id == id } ?: SQUIRCLE
    }
}

/** Icon presentation preferences (shape, size, spacing, label visibility). */
@Serializable
data class IconSettings(
    val shapeId: String = IconShape.DEFAULT_ID,
    val sizeDp: Float = 56f,
    val spacingDp: Float = 12f,
    val showLabels: Boolean = true,
    val backgroundPlate: Boolean = false,
    val backgroundPlateColor: Int = 0x33FFFFFF,
    val homeColumns: Int = 4,
    val drawerColumns: Int = 4,
) {
    val shape: IconShape get() = IconShape.fromId(shapeId)

    fun sanitized(): IconSettings = copy(
        shapeId = IconShape.fromId(shapeId).id,
        sizeDp = sizeDp.clamp(ICON_SIZE),
        spacingDp = spacingDp.clamp(ICON_SPACING),
        homeColumns = homeColumns.coerceIn(HOME_COLUMNS.start, HOME_COLUMNS.endInclusive),
        drawerColumns = drawerColumns.coerceIn(DRAWER_COLUMNS.start, DRAWER_COLUMNS.endInclusive),
    )

    companion object {
        val ICON_SIZE = 36f..96f
        val ICON_SPACING = 0f..28f
        val HOME_COLUMNS = 3..7
        val DRAWER_COLUMNS = 3..7
        val DEFAULT = IconSettings()
    }
}

private fun Float.clamp(range: ClosedFloatingPointRange<Float>): Float =
    if (isNaN()) range.start else coerceIn(range.start, range.endInclusive)
