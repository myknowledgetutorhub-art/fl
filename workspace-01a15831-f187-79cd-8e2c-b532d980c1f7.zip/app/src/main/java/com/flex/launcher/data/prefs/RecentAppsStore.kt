package com.flex.launcher.data.prefs

import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import java.io.IOException

/**
 * Locally observed launch history: `packageName -> epochMillis` of the last launch made
 * through Flex Launcher. Used as the fallback for the Recent Apps section when Usage Access
 * has not been granted, and to break ties. Nothing leaves the device.
 */
class RecentAppsStore(
    private val dataStore: DataStore<Preferences>,
    private val json: Json = Json { ignoreUnknownKeys = true },
) {

    val history: Flow<Map<String, Long>> = dataStore.data
        .catch { throwable ->
            if (throwable is IOException) emit(emptyPreferences()) else throw throwable
        }
        .map { decode(it[KEY]) }
        .distinctUntilChanged()

    suspend fun recordLaunch(packageName: String, timestamp: Long = System.currentTimeMillis()) {
        if (packageName.isBlank()) return
        dataStore.edit { prefs ->
            val current = decode(prefs[KEY]).toMutableMap()
            current[packageName] = timestamp
            // Keep the map bounded so it cannot grow without limit.
            val trimmed = current.entries
                .sortedByDescending { it.value }
                .take(MAX_ENTRIES)
                .associate { it.key to it.value }
            prefs[KEY] = encode(trimmed)
        }
    }

    /** Replaces the whole history (used by backup restore). */
    suspend fun restore(history: Map<String, Long>) {
        dataStore.edit { prefs ->
            val trimmed = history.entries.sortedByDescending { it.value }.take(MAX_ENTRIES)
                .associate { it.key to it.value }
            prefs[KEY] = encode(trimmed)
        }
    }

    suspend fun clear() {
        dataStore.edit { it.remove(KEY) }
    }

    suspend fun snapshot(): Map<String, Long> = history.first()

    fun encode(history: Map<String, Long>): String =
        json.encodeToString(HISTORY_SERIALIZER, history)

    fun decode(raw: String?): Map<String, Long> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            json.decodeFromString(HISTORY_SERIALIZER, raw)
        } catch (e: Exception) {
            Log.w(TAG, "Recent history could not be decoded; resetting", e)
            emptyMap()
        }
    }

    companion object {
        private val HISTORY_SERIALIZER = MapSerializer(String.serializer(), Long.serializer())
        private const val TAG = "RecentAppsStore"
        private const val MAX_ENTRIES = 60
        val KEY = stringPreferencesKey("recent_history_json")
    }
}
