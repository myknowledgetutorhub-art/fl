package com.flex.launcher.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.runtime.Immutable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import android.graphics.Typeface
import com.flex.launcher.domain.typography.FontOption
import com.flex.launcher.domain.typography.FontSource
import com.flex.launcher.domain.typography.TypographySettings

/** Resolves a [FontOption] to a usable Compose [FontFamily]. */
fun FontOption.toFontFamily(): FontFamily = when (val s = source) {
    is FontSource.Bundled -> FontFamily(
        Font(s.regularRes, FontWeight.Normal),
        Font(s.boldRes, FontWeight.Bold),
    )
    is FontSource.System -> runCatching {
        FontFamily(Typeface.create(s.familyName, Typeface.NORMAL))
    }.getOrElse { FontFamily.Default }
}

/** Launcher typography derived from user preferences. */
@Immutable
data class FlexType(
    val fontFamily: FontFamily,
    val weight: FontWeight,
    val homeLabel: TextStyle,
    val drawerLabel: TextStyle,
    val heading: TextStyle,
    val search: TextStyle,
    val clock: TextStyle,
    val date: TextStyle,
    val body: TextStyle,
    val label: TextStyle,
    val lineHeightMultiplier: Float,
) {
    companion object {
        fun from(settings: TypographySettings): FlexType {
            val family = settings.font.toFontFamily()
            val weight = FontWeight(settings.fontWeight.coerceIn(100, 900))
            val lineHeight = settings.lineHeightMultiplier.coerceIn(0.8f, 1.6f)
            val spacing = settings.letterSpacingEm.coerceIn(0f, 0.1f).sp

            fun style(sizeSp: Float, w: FontWeight = weight) = TextStyle(
                fontFamily = family,
                fontWeight = w,
                fontSize = sizeSp.sp,
                lineHeight = (sizeSp * lineHeight).sp,
                letterSpacing = spacing,
            )

            return FlexType(
                fontFamily = family,
                weight = weight,
                homeLabel = style(settings.effectiveHomeLabel),
                drawerLabel = style(settings.effectiveDrawerLabel),
                heading = style(settings.effectiveHeading, weight),
                search = style(settings.effectiveSearch),
                clock = style(settings.effectiveClock, FontWeight.Light).copy(letterSpacing = 0.sp),
                date = style(settings.effectiveDate),
                body = style(14f),
                label = style(12f),
                lineHeightMultiplier = lineHeight,
            )
        }

        val Default: FlexType = from(TypographySettings.DEFAULT)
    }
}

/** Applies the launcher font family to Material components as well. */
fun Typography.withFont(family: FontFamily): Typography = Typography(
    displayLarge = displayLarge.copy(fontFamily = family),
    displayMedium = displayMedium.copy(fontFamily = family),
    displaySmall = displaySmall.copy(fontFamily = family),
    headlineLarge = headlineLarge.copy(fontFamily = family),
    headlineMedium = headlineMedium.copy(fontFamily = family),
    headlineSmall = headlineSmall.copy(fontFamily = family),
    titleLarge = titleLarge.copy(fontFamily = family),
    titleMedium = titleMedium.copy(fontFamily = family),
    titleSmall = titleSmall.copy(fontFamily = family),
    bodyLarge = bodyLarge.copy(fontFamily = family),
    bodyMedium = bodyMedium.copy(fontFamily = family),
    bodySmall = bodySmall.copy(fontFamily = family),
    labelLarge = labelLarge.copy(fontFamily = family),
    labelMedium = labelMedium.copy(fontFamily = family),
    labelSmall = labelSmall.copy(fontFamily = family),
)

/** Standard single-line behaviour for app labels. */
val AppLabelOverflow = TextOverflow.Ellipsis
