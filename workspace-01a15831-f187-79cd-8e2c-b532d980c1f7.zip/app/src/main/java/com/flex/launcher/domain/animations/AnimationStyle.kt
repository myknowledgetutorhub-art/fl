package com.flex.launcher.domain.animations

import kotlinx.serialization.Serializable

/**
 * The eight (plus) launcher motion styles. The enum only carries metadata; the actual
 * Compose transitions are built in `ui/animations/LauncherAnimations.kt` so this stays
 * unit-testable.
 */
enum class AnimationStyle(
    val id: String,
    val label: String,
    val description: String,
) {
    FADE("fade", "Fade", "Opacity only — the cheapest option"),
    SLIDE("slide", "Slide", "Panel slides in from the bottom edge"),
    SCALE("scale", "Scale / Zoom", "Grows from 92% with a soft fade"),
    SPRING("spring", "Spring", "Physical spring with a light overshoot"),
    CROSSFADE("crossfade", "Smooth crossfade", "Long, smooth opacity blend"),
    VERTICAL_REVEAL("vertical_reveal", "Vertical reveal", "Unfolds downward like a sheet"),
    PARALLAX("parallax", "Subtle parallax", "Content drifts against a static backdrop"),
    DEPTH("depth", "Depth / layer", "Scales and dims like a stacked card");

    companion object {
        const val DEFAULT_ID = "slide"
        val all: List<AnimationStyle> = entries
        fun fromId(id: String?): AnimationStyle = entries.firstOrNull { it.id == id } ?: SLIDE
    }
}

/** Where an animation style applies. */
enum class AnimationScope(val id: String, val label: String) {
    DRAWER("drawer", "App drawer"),
    SHEET("sheet", "Settings screens"),
    SEARCH("search", "Search results"),
    THEME("theme", "Theme changes"),
}

@Serializable
data class AnimationSettings(
    val enabled: Boolean = true,
    val drawerStyleId: String = AnimationStyle.DEFAULT_ID,
    val sheetStyleId: String = "slide",
    val searchStyleId: String = "fade",
    val themeStyleId: String = "crossfade",
    val speed: Float = 1.0f,
    val reducedMotion: Boolean = false,
) {
    val drawerStyle: AnimationStyle get() = AnimationStyle.fromId(drawerStyleId)
    val sheetStyle: AnimationStyle get() = AnimationStyle.fromId(sheetStyleId)
    val searchStyle: AnimationStyle get() = AnimationStyle.fromId(searchStyleId)
    val themeStyle: AnimationStyle get() = AnimationStyle.fromId(themeStyleId)

    /** Motion is only allowed when enabled and not overridden by reduced-motion. */
    val motionAllowed: Boolean get() = enabled && !reducedMotion

    fun sanitized(): AnimationSettings = copy(
        drawerStyleId = AnimationStyle.fromId(drawerStyleId).id,
        sheetStyleId = AnimationStyle.fromId(sheetStyleId).id,
        searchStyleId = AnimationStyle.fromId(searchStyleId).id,
        themeStyleId = AnimationStyle.fromId(themeStyleId).id,
        speed = if (speed.isNaN()) 1f else speed.coerceIn(SPEED.start, SPEED.endInclusive),
    )

    /** Duration in ms for a base length, adjusted by the speed slider (0.25x … 3x). */
    fun duration(baseMs: Int): Int {
        val factor = 1f / speed.coerceIn(SPEED.start, SPEED.endInclusive)
        return (baseMs * factor).toInt().coerceIn(0, 2000)
    }

    fun styleFor(scope: AnimationScope): AnimationStyle = when (scope) {
        AnimationScope.DRAWER -> drawerStyle
        AnimationScope.SHEET -> sheetStyle
        AnimationScope.SEARCH -> searchStyle
        AnimationScope.THEME -> themeStyle
    }

    companion object {
        val SPEED = 0.25f..3f
        val DEFAULT = AnimationSettings()
    }
}
