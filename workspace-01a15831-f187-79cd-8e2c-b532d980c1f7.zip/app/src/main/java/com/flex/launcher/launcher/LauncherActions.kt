package com.flex.launcher.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import com.flex.launcher.data.apps.AppRepository
import com.flex.launcher.data.prefs.RecentAppsStore
import com.flex.launcher.domain.dialer.DialerIntents
import com.flex.launcher.domain.model.AppEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed interface LaunchOutcome {
    data object Launched : LaunchOutcome
    data class Failed(val message: String) : LaunchOutcome
    data object DialerUnavailable : LaunchOutcome
}

/**
 * All "real world" side effects of the launcher live here so UI code stays declarative and
 * every failure path is explicit (never a fake success toast).
 */
class LauncherActions(
    private val context: Context,
    private val appRepository: AppRepository,
    private val recentStore: RecentAppsStore,
) {

    /** Launches [entry] and records it in the local recent history. */
    suspend fun launchApp(entry: AppEntry): LaunchOutcome = withContext(Dispatchers.Main) {
        val intent = appRepository.launchIntent(entry)
            ?: return@withContext LaunchOutcome.Failed("${entry.label} is no longer installed")
        try {
            context.startActivity(intent)
            withContext(Dispatchers.IO) { recentStore.recordLaunch(entry.packageName) }
            LaunchOutcome.Launched
        } catch (e: ActivityNotFoundException) {
            Log.w(TAG, "Activity not found for ${entry.key}", e)
            LaunchOutcome.Failed("${entry.label} could not be opened")
        } catch (e: SecurityException) {
            Log.w(TAG, "Not allowed to start ${entry.key}", e)
            LaunchOutcome.Failed("Android blocked launching ${entry.label}")
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected launch failure for ${entry.key}", e)
            LaunchOutcome.Failed("Could not open ${entry.label}")
        }
    }

    /** Opens the system dialer pre-filled; never dials by itself. */
    fun dial(rawNumber: String): LaunchOutcome {
        val intent = DialerIntents.build(rawNumber)
            ?: return LaunchOutcome.Failed(DialerIntents.validationError(rawNumber) ?: "Invalid number")
        return startIntent(intent, "No dialer app is available on this device")
    }

    /** Opens the system wallpaper picker (supported mechanism, no permission needed). */
    fun openWallpaperPicker(): LaunchOutcome {
        val intent = Intent(Intent.ACTION_SET_WALLPAPER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) == null) {
            return LaunchOutcome.Failed("This device does not expose a wallpaper picker")
        }
        return startIntent(intent, "Wallpaper picker unavailable")
    }

    fun openUsageAccessSettings(): LaunchOutcome {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (intent.resolveActivity(context.packageManager) != null) {
            startIntent(intent, "Usage access screen unavailable")
        } else {
            // Some OEMs hide the dedicated screen; the app list still hosts the entry point.
            startIntent(
                Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                "System settings unavailable",
            )
        }
    }

    fun openDefaultLauncherSettings(): LaunchOutcome {
        val candidates = buildList {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                add(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
            add(Intent(Settings.ACTION_HOME_SETTINGS))
            add(Intent(Settings.ACTION_SETTINGS))
        }
        val intent = candidates.firstOrNull { it.resolveActivity(context.packageManager) != null }
            ?: return LaunchOutcome.Failed("Default app settings are unavailable on this device")
        return startIntent(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), "Settings unavailable")
    }

    fun openAppInfo(packageName: String): LaunchOutcome {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.fromParts("package", packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return startIntent(intent, "App info unavailable")
    }

    fun openIntent(intent: Intent): LaunchOutcome = startIntent(intent, "No app can handle this action")

    fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    private fun startIntent(intent: Intent, failureMessage: String): LaunchOutcome = try {
        context.startActivity(intent)
        LaunchOutcome.Launched
    } catch (e: ActivityNotFoundException) {
        Log.w(TAG, "No activity for $intent", e)
        LaunchOutcome.Failed(failureMessage)
    } catch (e: SecurityException) {
        Log.w(TAG, "Security exception for $intent", e)
        LaunchOutcome.Failed(failureMessage)
    } catch (e: Exception) {
        Log.e(TAG, "Unexpected intent failure for $intent", e)
        LaunchOutcome.Failed(failureMessage)
    }

    companion object {
        private const val TAG = "LauncherActions"
    }
}
