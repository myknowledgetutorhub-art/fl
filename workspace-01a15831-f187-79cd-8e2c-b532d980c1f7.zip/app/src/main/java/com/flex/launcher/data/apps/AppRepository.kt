package com.flex.launcher.data.apps

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.flex.launcher.domain.model.AppEntry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Discovers launchable activities via PackageManager and keeps the list fresh when packages
 * are installed, removed, replaced or when hidden/disabled apps change state.
 *
 * Only apps exposing `ACTION_MAIN` + `CATEGORY_LAUNCHER` are visible thanks to the `<queries>`
 * element in the manifest — `QUERY_ALL_PACKAGES` is not requested.
 */
class AppRepository(
    private val context: Context,
    private val scope: CoroutineScope,
) {

    private val packageManager: PackageManager get() = context.packageManager
    private val loadMutex = Mutex()
    private var cached: List<AppEntry>? = null

    @Volatile
    private var lastError: String? = null

    enum class SortKey { ALPHABETICAL }

    /** Cold flow that emits the current app list and re-emits on package changes. */
    fun observeApps(): Flow<List<AppEntry>> = callbackFlow {
        // Seed immediately with whatever is cached to avoid an empty first frame.
        cached?.let { trySend(it) }
        launch(Dispatchers.IO) { send(load()) }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val pkg = intent?.data?.schemeSpecificPart
                Log.d(TAG, "Package change: ${intent?.action} $pkg")
                launch(Dispatchers.IO) { send(load()) }
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        awaitClose { runCatching { context.unregisterReceiver(receiver) } }
    }.conflate().distinctUntilChanged().flowOn(Dispatchers.Default)

    /** Loads the launchable app list. Never throws: failures surface as an empty list + error. */
    suspend fun load(): List<AppEntry> = withContext(Dispatchers.IO) {
        loadMutex.withLock {
            try {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    packageManager.queryIntentActivities(
                        intent,
                        PackageManager.ResolveInfoFlags.of(0L),
                    )
                } else {
                    packageManager.queryIntentActivities(intent, 0)
                }

                val entries = LinkedHashMap<String, AppEntry>()
                resolved.forEach { info ->
                    val activityInfo = info.activityInfo ?: return@forEach
                    val pkg = activityInfo.packageName ?: return@forEach
                    val activity = activityInfo.name ?: return@forEach
                    if (pkg.isBlank() || activity.isBlank()) return@forEach

                    val label = runCatching {
                        activityInfo.loadLabel(packageManager)?.toString()
                    }.getOrNull()?.takeIf { it.isNotBlank() }
                        ?: runCatching { info.loadLabel(packageManager)?.toString() }.getOrNull()
                        ?: pkg

                    val entry = AppEntry(
                        packageName = pkg,
                        activityName = activity,
                        label = label.trim(),
                    )
                    entries[entry.key] = entry
                }

                val list = entries.values.toList()
                cached = list
                lastError = null
                list
            } catch (e: Exception) {
                // PackageManager failures must not crash the launcher.
                Log.e(TAG, "Failed to query launchable apps", e)
                lastError = e.message ?: "Unable to read installed apps"
                cached ?: emptyList()
            }
        }
    }

    fun errorState(): String? = lastError

    fun entryFor(packageName: String, activityName: String): AppEntry? =
        cached?.firstOrNull { it.packageName == packageName && it.activityName == activityName }
            ?: cached?.firstOrNull { it.packageName == packageName }

    fun isInstalled(packageName: String): Boolean =
        runCatching { packageManager.getApplicationInfo(packageName, 0) }.isSuccess

    /** Loads the real launcher icon for an entry; returns null when unavailable. */
    suspend fun loadIcon(entry: AppEntry): Drawable? = withContext(Dispatchers.IO) {
        runCatching {
            val component = ComponentName(entry.packageName, entry.activityName)
            packageManager.getActivityIcon(component)
        }.recoverCatching {
            packageManager.getApplicationIcon(entry.packageName)
        }.getOrElse { throwable ->
            Log.w(TAG, "Icon unavailable for ${entry.packageName}", throwable)
            null
        }
    }

    /** Resolves the launch intent for an entry, or null when the activity is gone. */
    fun launchIntent(entry: AppEntry): Intent? =
        runCatching {
            packageManager.getLaunchIntentForPackage(entry.packageName)
                ?: Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                    component = ComponentName(entry.packageName, entry.activityName)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                }
        }.getOrNull()

    companion object {
        private const val TAG = "AppRepository"
    }
}
