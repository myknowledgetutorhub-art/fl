package com.flex.launcher.domain.dialer

import android.content.Intent
import android.net.Uri

/**
 * Builds the `ACTION_DIAL` intent used by the built-in dial-pad.
 *
 * The launcher never places calls itself: it only opens the system dialer pre-filled, which
 * requires no telephony permission at all.
 */
object DialerIntents {

    /** Characters the dialer accepts (DTMF digits + pause/wait + wildcards). */
    private val ALLOWED = Regex("^[0-9+*#,;]+$")

    /** Removes formatting characters users normally type. */
    fun sanitize(raw: String): String = raw.replace(Regex("[\\s\\-().]"), "").trim()

    fun isValidNumber(raw: String): Boolean = validationError(raw) == null

    /** Error text for invalid input, or null when the number is dialable. */
    fun validationError(raw: String): String? {
        if (raw.isBlank()) return "Enter a phone number"
        val clean = sanitize(raw)
        if (clean.isBlank()) return "Enter a phone number"
        val digits = clean.count { it.isDigit() }
        if (digits < 3) return "A phone number needs at least 3 digits"
        if (!ALLOWED.matches(clean)) return "Only digits and + * # , ; are allowed"
        if (clean.count { it == '+' } > 1) return "Only one + prefix is allowed"
        if (clean.contains('+') && !clean.startsWith("+")) return "The + prefix is only allowed at the start"
        if (digits > 20) return "That number is too long"
        return null
    }

    /**
     * Returns an `ACTION_DIAL` intent, or null when [raw] is not a dialable number.
     *
     * `Uri.parse("tel:…")` is used instead of `Uri.fromParts`, because `fromParts` percent-encodes
     * the leading `+` (`%2B`) which some dialers do not decode back into an international prefix.
     * The number is validated against a strict character allow-list first, so no encoding is
     * required for anything that can reach this point.
     */
    fun build(raw: String): Intent? {
        if (!isValidNumber(raw)) return null
        return Intent(Intent.ACTION_DIAL, Uri.parse("tel:${sanitize(raw)}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
}
