package com.flex.launcher

import android.app.Application
import com.flex.launcher.core.AppGraph

class FlexLauncherApp : Application() {

    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
    }
}
