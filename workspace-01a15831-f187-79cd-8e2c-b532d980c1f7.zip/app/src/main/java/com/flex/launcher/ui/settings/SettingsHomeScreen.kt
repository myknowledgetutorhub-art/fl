package com.flex.launcher.ui.settings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.theme.ThemePresets
import com.flex.launcher.domain.typography.FontOptions
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.InlineNotice
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard

/** Central settings hub. Every row navigates to a screen that actually changes behaviour. */
@Composable
fun SettingsHomeScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
) {
    val usageGranted by vm.usageAccessGranted.collectAsStateWithLifecycle()
    val isDefault by vm.isDefaultLauncher.collectAsStateWithLifecycle()
    val themeName = when (prefs.themeId) {
        ThemePresets.CUSTOM_ID -> "Custom theme"
        "wallpaper" -> "Wallpaper colours"
        else -> ThemePresets.byId(prefs.themeId).name
    }

    SettingsScaffold(title = "Settings", onBack = onBack) {
        InlineNotice(
            text = if (isDefault) {
                "Flex Launcher is your default home app."
            } else {
                "Flex Launcher is not your default home app yet — tap Home screen › Set as default."
            },
        )

        SectionTitle("Launcher")
        SettingsCard {
            SettingsActionRow("Home screen", { onNavigate(Routes.HOME_SCREEN) }, "Clock, date, default app, home grid")
            HorizontalDivider()
            SettingsActionRow("Recent apps", { onNavigate(Routes.RECENTS) }, "Ordering, count, usage access")
            HorizontalDivider()
            SettingsActionRow("App drawer", { onNavigate(Routes.DRAWER) }, "Sorting, columns, sections")
            HorizontalDivider()
            SettingsActionRow("Hide apps", { onNavigate(Routes.HIDE_APPS) }, "${prefs.hiddenApps.size} hidden")
        }

        SectionTitle("Appearance")
        SettingsCard {
            SettingsActionRow("Theme Studio", { onNavigate(Routes.THEME) }, themeName)
            HorizontalDivider()
            SettingsActionRow(
                "Fonts & typography",
                { onNavigate(Routes.TYPOGRAPHY) },
                FontOptions.byId(prefs.typography.fontId).displayName,
            )
            HorizontalDivider()
            SettingsActionRow("Icons & shapes", { onNavigate(Routes.ICONS) }, prefs.icons.shape.label)
            HorizontalDivider()
            SettingsActionRow("Animations", { onNavigate(Routes.ANIMATIONS) }, prefs.animations.drawerStyle.label)
            HorizontalDivider()
            SettingsActionRow("Status bar", { onNavigate(Routes.STATUS_BAR) }, prefs.statusBar.iconMode.label)
        }

        SectionTitle("System")
        SettingsCard {
            SettingsActionRow(
                "Permissions",
                { onNavigate(Routes.PERMISSIONS) },
                if (usageGranted) "Usage access granted" else "Usage access not granted",
            )
            HorizontalDivider()
            SettingsActionRow("Dial pad", { onNavigate(Routes.DIALER) }, "Open the system dialer")
            HorizontalDivider()
            SettingsActionRow("Backup & reset", { onNavigate(Routes.BACKUP) }, "Export, restore, reset")
            HorizontalDivider()
            SettingsActionRow("About Flex Launcher", { onNavigate(Routes.ABOUT) }, "Version and limitations")
        }
        Spacer(Modifier.height(28.dp))
    }
}
