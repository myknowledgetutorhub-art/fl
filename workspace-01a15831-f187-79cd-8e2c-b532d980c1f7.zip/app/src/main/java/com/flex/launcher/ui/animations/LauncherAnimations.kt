package com.flex.launcher.ui.animations

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.ui.Alignment
import com.flex.launcher.domain.animations.AnimationScope
import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.animations.AnimationStyle

/**
 * Maps the eight launcher motion styles onto real Compose transitions.
 * When motion is disabled (or reduced motion is on) every transition becomes a no-op, so
 * low-end devices and accessibility needs are both covered.
 */
object LauncherAnimations {

    fun enter(settings: AnimationSettings, scope: AnimationScope): EnterTransition {
        if (!settings.motionAllowed) return EnterTransition.None
        return enterFor(settings.styleFor(scope), settings)
    }

    fun exit(settings: AnimationSettings, scope: AnimationScope): ExitTransition {
        if (!settings.motionAllowed) return ExitTransition.None
        return exitFor(settings.styleFor(scope), settings)
    }

    fun enterFor(style: AnimationStyle, settings: AnimationSettings): EnterTransition {
        val base = 260
        return when (style) {
            AnimationStyle.FADE -> fadeIn(tween(settings.duration(200)))
            AnimationStyle.SLIDE -> fadeIn(tween(settings.duration(base))) +
                slideInVertically(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    initialOffsetY = { it / 5 },
                )
            AnimationStyle.SCALE -> fadeIn(tween(settings.duration(220))) +
                scaleIn(
                    animationSpec = tween(settings.duration(base), easing = LinearOutSlowInEasing),
                    initialScale = 0.92f,
                )
            AnimationStyle.SPRING -> fadeIn(tween(settings.duration(160))) +
                slideInVertically(
                    animationSpec = spring(
                        dampingRatio = 0.78f,
                        stiffness = 700f / settings.speed.coerceIn(0.25f, 3f),
                    ),
                    initialOffsetY = { it / 8 },
                )
            AnimationStyle.CROSSFADE -> fadeIn(tween(settings.duration(380), easing = FastOutSlowInEasing))
            AnimationStyle.VERTICAL_REVEAL -> fadeIn(tween(settings.duration(180))) +
                expandVertically(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    expandFrom = Alignment.Top,
                )
            AnimationStyle.PARALLAX -> fadeIn(tween(settings.duration(280))) +
                slideInVertically(
                    animationSpec = tween(settings.duration(base + 80), easing = LinearOutSlowInEasing),
                    initialOffsetY = { it / 14 },
                )
            AnimationStyle.DEPTH -> fadeIn(tween(settings.duration(240))) +
                scaleIn(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    initialScale = 0.88f,
                )
        }
    }

    fun exitFor(style: AnimationStyle, settings: AnimationSettings): ExitTransition {
        val base = 200
        return when (style) {
            AnimationStyle.FADE -> fadeOut(tween(settings.duration(160)))
            AnimationStyle.SLIDE -> fadeOut(tween(settings.duration(base))) +
                slideOutVertically(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    targetOffsetY = { it / 5 },
                )
            AnimationStyle.SCALE -> fadeOut(tween(settings.duration(180))) +
                scaleOut(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    targetScale = 0.94f,
                )
            AnimationStyle.SPRING -> fadeOut(tween(settings.duration(140))) +
                slideOutVertically(
                    animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = 900f),
                    targetOffsetY = { it / 8 },
                )
            AnimationStyle.CROSSFADE -> fadeOut(tween(settings.duration(300)))
            AnimationStyle.VERTICAL_REVEAL -> fadeOut(tween(settings.duration(160))) +
                shrinkVertically(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    shrinkTowards = Alignment.Top,
                )
            AnimationStyle.PARALLAX -> fadeOut(tween(settings.duration(200))) +
                slideOutVertically(
                    animationSpec = tween(settings.duration(base), easing = LinearOutSlowInEasing),
                    targetOffsetY = { it / 14 },
                )
            AnimationStyle.DEPTH -> fadeOut(tween(settings.duration(180))) +
                scaleOut(
                    animationSpec = tween(settings.duration(base), easing = FastOutSlowInEasing),
                    targetScale = 0.9f,
                )
        }
    }

    /** Scale/alpha values used by the preview cards in the animation settings screen. */
    fun previewTarget(style: AnimationStyle): Pair<Float, Float> = when (style) {
        AnimationStyle.FADE -> 1f to 0f
        AnimationStyle.SLIDE -> 0.8f to 0f
        AnimationStyle.SCALE -> 0.92f to 0f
        AnimationStyle.SPRING -> 0.9f to 0f
        AnimationStyle.CROSSFADE -> 1f to 0.35f
        AnimationStyle.VERTICAL_REVEAL -> 1f to 0f
        AnimationStyle.PARALLAX -> 0.96f to 0f
        AnimationStyle.DEPTH -> 0.88f to 0f
    }
}
