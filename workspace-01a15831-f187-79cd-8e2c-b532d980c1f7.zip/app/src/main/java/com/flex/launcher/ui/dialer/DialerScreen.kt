package com.flex.launcher.ui.dialer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.flex.launcher.domain.dialer.DialerIntents
import com.flex.launcher.ui.components.clickableNoRipple
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors
import com.flex.launcher.ui.theme.contrastOn

/**
 * Dial-pad utility. It only ever builds an `ACTION_DIAL` intent for the *system* dialer —
 * Flex Launcher has no telephony permission and never places a call directly.
 */
@Composable
fun DialerScreen(
    number: String,
    onNumberChange: (String) -> Unit,
    error: String?,
    onDial: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val keys = listOf(
        listOf("1", "2", "3"),
        listOf("4", "5", "6"),
        listOf("7", "8", "9"),
        listOf("*", "0", "#"),
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(colors.background.copy(alpha = 0.97f)),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Dial pad", style = type.heading, color = colors.textPrimary)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Filled.Close, contentDescription = "Close dial pad", tint = colors.textPrimary)
                }
            }

            Spacer(Modifier.height(12.dp))

            Text(
                text = number.ifEmpty { "Enter a number" },
                style = type.clock.copy(fontSize = type.heading.fontSize * 1.9f),
                color = if (number.isEmpty()) colors.textSecondary else colors.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )

            if (error != null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    error,
                    style = type.label,
                    color = Color(0xFFEF5350),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            Spacer(Modifier.weight(0.6f))

            keys.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    row.forEach { key ->
                        DialKey(
                            key = key,
                            onClick = { onNumberChange(number + key) },
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // '+' is only valid at the start, so it replaces the number.
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .clickableNoRipple { if (!number.startsWith("+")) onNumberChange("+$number") },
                    contentAlignment = Alignment.Center,
                ) {
                    Text("+", style = type.heading.copy(fontSize = type.heading.fontSize * 1.4f), color = colors.textSecondary)
                }
                Spacer(Modifier.width(24.dp))
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(colors.primary)
                        .clickableNoRipple(onDial),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Phone,
                        contentDescription = "Open system dialer",
                        tint = contrastOn(colors.primary),
                    )
                }
                Spacer(Modifier.width(24.dp))
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .clickableNoRipple {
                            if (number.isNotEmpty()) onNumberChange(number.dropLast(1))
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Delete last digit",
                        tint = colors.textSecondary,
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                text = "Calls are placed in your phone app. Flex Launcher never dials on its own.",
                style = type.label,
                color = colors.textSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun DialKey(key: String, onClick: () -> Unit) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(84.dp)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(22.dp))
            .background(colors.card.copy(alpha = 0.85f))
            .clickableNoRipple(onClick)
            .padding(6.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            text = key,
            style = type.heading.copy(fontSize = type.heading.fontSize * 1.6f),
            color = colors.textPrimary,
            textAlign = TextAlign.Center,
        )
    }
}

/** Pure helper used by the UI and tests: digits currently in the field. */
fun digitsOnly(number: String): String = number.filter { it.isDigit() }

fun dialErrorOrNull(number: String): String? =
    if (number.isBlank()) null else DialerIntents.validationError(number)
