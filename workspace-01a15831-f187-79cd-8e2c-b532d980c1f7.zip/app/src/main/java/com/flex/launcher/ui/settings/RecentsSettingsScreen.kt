package com.flex.launcher.ui.settings

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.RecentSettings
import com.flex.launcher.ui.MainViewModel
import com.flex.launcher.ui.components.InlineNotice
import com.flex.launcher.ui.components.SectionTitle
import com.flex.launcher.ui.components.SettingsActionRow
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSliderRow
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.theme.LocalFlexType
import com.flex.launcher.ui.theme.LocalLauncherColors

@Composable
fun RecentsSettingsScreen(
    vm: MainViewModel,
    prefs: LauncherPrefs,
    onBack: () -> Unit,
    onOpenPermissions: () -> Unit,
) {
    val colors = LocalLauncherColors.current
    val type = LocalFlexType.current
    val usageGranted by vm.usageAccessGranted.collectAsStateWithLifecycle()
    val recents by vm.recentApps.collectAsStateWithLifecycle()

    fun update(transform: (RecentSettings) -> RecentSettings) {
        vm.updatePrefs { it.copy(recents = transform(it.recents).sanitized()) }
    }

    SettingsScaffold(title = "Recent apps", onBack = onBack, subtitle = "${recents.size} shown") {
        InlineNotice(
            text = if (usageGranted) {
                "Usage access is granted: ordering uses Android's UsageStats data plus Flex Launcher's own launch history."
            } else {
                "Usage access is not granted. Recent apps currently use Flex Launcher's own launch history only."
            },
        )

        SectionTitle("Display")
        SettingsCard {
            SettingsSwitchRow(
                title = "Show recent apps",
                description = "Displays the Recent apps section at the top of the app drawer",
                checked = prefs.recents.enabled,
                onCheckedChange = { on -> update { it.copy(enabled = on) } },
            )
            SettingsSliderRow(
                "Number of recent items",
                prefs.recents.maxItems.toFloat(),
                { v -> update { it.copy(maxItems = v.toInt()) } },
                RecentSettings.MIN_ITEMS.toFloat()..RecentSettings.MAX_ITEMS.toFloat(),
                steps = (RecentSettings.MAX_ITEMS - RecentSettings.MIN_ITEMS) - 1,
                valueLabel = { it.toInt().toString() },
                onReset = { update { it.copy(maxItems = RecentSettings.DEFAULT.maxItems) } },
            )
            SettingsSwitchRow(
                title = "Show recents on the home screen",
                description = "Adds a recent row to the home surface",
                checked = prefs.recents.showOnHome,
                onCheckedChange = { on -> update { it.copy(showOnHome = on) } },
            )
        }

        SectionTitle("Data source")
        SettingsCard {
            SettingsSwitchRow(
                title = "Use Android UsageStats",
                description = "Requires the Usage access permission. Read locally only — nothing is uploaded.",
                checked = prefs.recents.useUsageAccess,
                onCheckedChange = { on -> update { it.copy(useUsageAccess = on) } },
            )
            SettingsActionRow(
                "Usage access status",
                onOpenPermissions,
                trailingText = if (usageGranted) "Granted" else "Not granted",
            )
            SettingsActionRow(
                if (usageGranted) "Open Android Usage access settings" else "Grant Usage access",
                { vm.openUsageAccessSettings() },
                "Refreshes automatically when you return",
            )
        }

        SectionTitle("History")
        SettingsCard {
            SettingsActionRow(
                "Clear Flex Launcher history",
                { vm.clearRecentHistory() },
                "Removes locally stored launch timestamps",
                destructive = true,
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "Android does not give launchers access to the system Recents screen or to a list of " +
                "currently running tasks. UsageStats timestamps can be coarse and omit apps that were " +
                "never opened during the stats window. Flex Launcher asks the platform for app-open " +
                "events only, and never records what you do inside other apps.",
            style = type.label,
            color = colors.textSecondary,
            modifier = Modifier.padding(end = 8.dp),
        )
        Spacer(Modifier.height(24.dp))
    }
}
