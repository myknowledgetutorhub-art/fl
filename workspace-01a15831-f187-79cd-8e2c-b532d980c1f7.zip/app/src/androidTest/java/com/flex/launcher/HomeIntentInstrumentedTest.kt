package com.flex.launcher

import android.content.Intent
import android.content.pm.PackageManager
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * On-device verification of the HOME contract. Requires a connected device or emulator:
 *
 *   ./gradlew connectedDebugAndroidTest
 *
 * CI compiles this source set (`assembleDebugAndroidTest`) but does not run it, because the
 * hosted runners have no launcher-capable device.
 */
@RunWith(AndroidJUnit4::class)
class HomeIntentInstrumentedTest {

    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    @Test
    fun homeIntentResolvesToThisLauncher() {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        @Suppress("DEPRECATION")
        val candidates = context.packageManager.queryIntentActivities(homeIntent, 0)
        assertTrue(
            "Flex Launcher must be offered for CATEGORY_HOME",
            candidates.any { it.activityInfo?.packageName == context.packageName },
        )
    }

    @Test
    fun launcherActivityIsExportedAndResolvable() {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            setPackage(context.packageName)
        }
        @Suppress("DEPRECATION")
        val resolved = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        assertEquals("com.flex.launcher.MainActivity", resolved?.activityInfo?.name)
    }

    @Test
    fun noInternetPermissionIsRequested() {
        val requested = context.packageManager
            .getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
            .requestedPermissions
            ?.toList()
            .orEmpty()
        assertTrue(requested.none { it == "android.permission.INTERNET" })
    }
}
