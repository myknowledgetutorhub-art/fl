package com.flex.launcher

import com.flex.launcher.domain.animations.AnimationScope
import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.animations.AnimationStyle
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AnimationTest {

    @Test
    fun `eight animation styles exist`() {
        assertTrue("found ${AnimationStyle.all.size}", AnimationStyle.all.size >= 8)
    }

    @Test
    fun `all required styles are present`() {
        val labels = AnimationStyle.all.map { it.label }
        listOf(
            "Fade", "Slide", "Scale / Zoom", "Spring", "Smooth crossfade",
            "Vertical reveal", "Subtle parallax", "Depth / layer",
        ).forEach { assertTrue("missing $it", labels.contains(it)) }
    }

    @Test
    fun `style ids are unique`() {
        assertEquals(AnimationStyle.all.size, AnimationStyle.all.map { it.id }.toSet().size)
    }

    @Test
    fun `unknown style id falls back to slide`() {
        assertEquals(AnimationStyle.SLIDE, AnimationStyle.fromId("nope"))
        assertEquals(AnimationStyle.FADE, AnimationStyle.fromId("fade"))
        assertEquals(AnimationStyle.SLIDE, AnimationStyle.fromId(null))
    }

    @Test
    fun `each scope maps to its configured style`() {
        val settings = AnimationSettings(
            drawerStyleId = "fade",
            sheetStyleId = "spring",
            searchStyleId = "scale",
            themeStyleId = "crossfade",
        )
        assertEquals(AnimationStyle.FADE, settings.styleFor(AnimationScope.DRAWER))
        assertEquals(AnimationStyle.SPRING, settings.styleFor(AnimationScope.SHEET))
        assertEquals(AnimationStyle.SCALE, settings.styleFor(AnimationScope.SEARCH))
        assertEquals(AnimationStyle.CROSSFADE, settings.styleFor(AnimationScope.THEME))
    }

    @Test
    fun `reduced motion and disabled switch off motion`() {
        assertTrue(AnimationSettings.DEFAULT.motionAllowed)
        assertFalse(AnimationSettings(enabled = false).motionAllowed)
        assertFalse(AnimationSettings(reducedMotion = true).motionAllowed)
    }

    @Test
    fun `speed is clamped and scales durations`() {
        val fast = AnimationSettings(speed = 10f).sanitized()
        assertEquals(AnimationSettings.SPEED.endInclusive, fast.speed, 0.001f)
        assertTrue("faster speed must shorten duration", fast.duration(300) < 300)

        val slow = AnimationSettings(speed = 0.25f).sanitized()
        assertTrue("slower speed must lengthen duration", slow.duration(300) > 300)

        val normal = AnimationSettings(speed = 1f)
        assertEquals(200, normal.duration(200))
    }

    @Test
    fun `duration never becomes negative`() {
        (1..50).forEach { _ ->
            assertTrue(AnimationSettings(speed = 3f).duration(10) >= 0)
        }
    }

    @Test
    fun `settings sanitize unknown style ids`() {
        val sanitized = AnimationSettings(
            drawerStyleId = "bogus",
            sheetStyleId = "bogus2",
            searchStyleId = "bogus3",
            themeStyleId = "bogus4",
            speed = Float.NaN,
        ).sanitized()
        assertEquals(AnimationStyle.SLIDE.id, sanitized.drawerStyleId)
        assertEquals(AnimationStyle.SLIDE.id, sanitized.sheetStyleId)
        assertEquals(1f, sanitized.speed, 0.001f)
    }
}
