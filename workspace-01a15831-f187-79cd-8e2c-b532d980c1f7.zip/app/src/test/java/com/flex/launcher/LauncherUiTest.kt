package com.flex.launcher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.RecentApp
import com.flex.launcher.domain.model.RecentSource
import com.flex.launcher.ui.animations.LauncherAnimations
import com.flex.launcher.ui.components.LauncherSearchField
import com.flex.launcher.ui.drawer.AppDrawer
import com.flex.launcher.ui.drawer.DrawerCallbacks
import com.flex.launcher.ui.home.HomeCallbacks
import com.flex.launcher.ui.home.HomeScreen
import com.flex.launcher.ui.theme.FlexTheme
import com.flex.launcher.ui.theme.FlexType
import com.flex.launcher.ui.theme.LauncherColors
import com.flex.launcher.domain.theme.ThemePresets
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Compose UI tests executed on the JVM with Robolectric. They exercise the real composables
 * (home screen, app drawer, search, settings widgets) rather than mocks.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33], qualifiers = "w411dp-h891dp-xxhdpi")
class LauncherUiTest {

    @get:Rule
    val rule = createComposeRule()

    private val palette = ThemePresets.byId("midnight_black").palette
    private val colors = LauncherColors(
        background = androidx.compose.ui.graphics.Color(palette.background),
        backgroundGradient = emptyList(),
        gradientDirection = palette.direction,
        surface = androidx.compose.ui.graphics.Color(palette.surface),
        card = androidx.compose.ui.graphics.Color(palette.card),
        primary = androidx.compose.ui.graphics.Color(palette.primary),
        secondary = androidx.compose.ui.graphics.Color(palette.secondary),
        accent = androidx.compose.ui.graphics.Color(palette.accent),
        textPrimary = androidx.compose.ui.graphics.Color(palette.textPrimary),
        textSecondary = androidx.compose.ui.graphics.Color(palette.textSecondary),
        isLight = false,
        statusBarIconsDark = false,
        backgroundOpacity = 100f,
    )

    private fun app(pkg: String, label: String) = AppEntry(pkg, "$pkg.Main", label)

    private val testApps = listOf(
        app("com.example.alpha", "Alpha"),
        app("com.example.beta", "Beta"),
        app("com.example.gamma", "Gamma"),
    )

    private fun content(block: @androidx.compose.runtime.Composable () -> Unit) {
        rule.setContent {
            FlexTheme(colors = colors, type = FlexType.Default, animations = LauncherPrefs.DEFAULT.animations) {
                block()
            }
        }
    }

    @Test
    fun homeScreenShowsEmptyStateAndSearchEntryPoint() {
        var drawerOpened = false
        content {
            HomeScreen(
                prefs = LauncherPrefs.DEFAULT,
                colors = colors,
                pinned = emptyList(),
                isDefaultLauncher = true,
                loadingApps = false,
                callbacks = HomeCallbacks(
                    onLaunch = {},
                    onOpenDrawer = { drawerOpened = true },
                    onOpenSettings = {},
                    onOpenDialer = {},
                    onSetDefaultLauncher = {},
                ),
            )
        }
        rule.onNodeWithText("Your home screen is empty").assertIsDisplayed()
        rule.onNodeWithText("Search apps").assertIsDisplayed()
        rule.onNodeWithText("Open app drawer").performClick()
        assertEquals(true, drawerOpened)
    }

    @Test
    fun homeScreenRendersPinnedApps() {
        content {
            HomeScreen(
                prefs = LauncherPrefs.DEFAULT,
                colors = colors,
                pinned = testApps,
                isDefaultLauncher = true,
                loadingApps = false,
                callbacks = HomeCallbacks({}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithText("Alpha").assertIsDisplayed()
        rule.onNodeWithText("Gamma").assertIsDisplayed()
    }

    @Test
    fun homeScreenOffersDefaultLauncherShortcutWhenNotDefault() {
        content {
            HomeScreen(
                prefs = LauncherPrefs.DEFAULT,
                colors = colors,
                pinned = testApps,
                isDefaultLauncher = false,
                loadingApps = false,
                callbacks = HomeCallbacks({}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithText("Set as default").assertIsDisplayed()
    }

    @Test
    fun drawerShowsRecentHelpersAndAllApps() {
        val recents = listOf(RecentApp(testApps[1], System.currentTimeMillis() - 60_000, RecentSource.LOCAL_HISTORY))
        content {
            var query by remember { mutableStateOf("") }
            AppDrawer(
                prefs = LauncherPrefs.DEFAULT,
                apps = testApps,
                recents = recents,
                pinned = emptyList(),
                recencyRank = emptyMap(),
                query = query,
                onQueryChange = { query = it },
                appsLoading = false,
                appsError = null,
                usageAccessGranted = false,
                callbacks = DrawerCallbacks({}, {}, {}, {}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithText("Recent apps").assertIsDisplayed()
        rule.onNodeWithText("All apps").assertIsDisplayed()
        rule.onNodeWithText("Alpha").assertIsDisplayed()
        // Beta appears twice on purpose: once in Recent apps, once in All apps.
        assertEquals(2, rule.onAllNodesWithText("Beta").fetchSemanticsNodes().size)
        rule.onNodeWithText("Gamma").assertIsDisplayed()
    }

    @Test
    fun drawerSearchFiltersTheRealList() {
        content {
            var query by remember { mutableStateOf("") }
            AppDrawer(
                prefs = LauncherPrefs.DEFAULT,
                apps = testApps,
                recents = emptyList(),
                pinned = emptyList(),
                recencyRank = emptyMap(),
                query = query,
                onQueryChange = { query = it },
                appsLoading = false,
                appsError = null,
                usageAccessGranted = true,
                callbacks = DrawerCallbacks({}, {}, {}, {}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithTag("drawer_search").performTextInput("be")
        rule.onNodeWithText("Beta").assertIsDisplayed()
        rule.onNodeWithText("Alpha").assertDoesNotExist()
    }

    @Test
    fun drawerShowsEmptyStateWhenNothingMatches() {
        content {
            var query by remember { mutableStateOf("") }
            AppDrawer(
                prefs = LauncherPrefs.DEFAULT,
                apps = testApps,
                recents = emptyList(),
                pinned = emptyList(),
                recencyRank = emptyMap(),
                query = query,
                onQueryChange = { query = it },
                appsLoading = false,
                appsError = null,
                usageAccessGranted = true,
                callbacks = DrawerCallbacks({}, {}, {}, {}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithTag("drawer_search").performTextInput("zzz")
        rule.onNodeWithText("No apps match “zzz”").assertIsDisplayed()
        rule.onNodeWithText("Clear search").assertIsDisplayed()
    }

    @Test
    fun drawerLaunchesAppOnTap() {
        var launched: AppEntry? = null
        content {
            AppDrawer(
                prefs = LauncherPrefs.DEFAULT,
                apps = testApps,
                recents = emptyList(),
                pinned = emptyList(),
                recencyRank = emptyMap(),
                query = "",
                onQueryChange = {},
                appsLoading = false,
                appsError = null,
                usageAccessGranted = true,
                callbacks = DrawerCallbacks({ launched = it }, {}, {}, {}, {}, {}, {}, {}),
            )
        }
        rule.onNodeWithText("Alpha").performClick()
        assertEquals("com.example.alpha", launched?.packageName)
    }

    @Test
    fun searchFieldAcceptsInput() {
        var value = ""
        content {
            var query by remember { mutableStateOf("") }
            LauncherSearchField(
                query = query,
                onQueryChange = { query = it; value = it },
                testTag = "search_field",
            )
        }
        rule.onNodeWithTag("search_field").performTextInput("hello")
        assertEquals("hello", value)
    }

    @Test
    fun animationSettingsProduceTransitionsForEveryStyle() {
        // Guards against a style that silently maps to "no animation".
        val settings = LauncherPrefs.DEFAULT.animations.copy(enabled = true, reducedMotion = false)
        com.flex.launcher.domain.animations.AnimationStyle.all.forEach { style ->
            val enter = LauncherAnimations.enterFor(style, settings)
            val exit = LauncherAnimations.exitFor(style, settings)
            assert(enter != androidx.compose.animation.EnterTransition.None) { "${style.id} enter is None" }
            assert(exit != androidx.compose.animation.ExitTransition.None) { "${style.id} exit is None" }
        }
    }
}
