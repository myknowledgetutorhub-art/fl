package com.flex.launcher

import com.flex.launcher.data.prefs.BackupCodec
import com.flex.launcher.data.prefs.BackupPayload
import com.flex.launcher.data.prefs.PreferencesRepository
import com.flex.launcher.data.prefs.RecentAppsStore
import com.flex.launcher.domain.animations.AnimationSettings
import com.flex.launcher.domain.model.AppSortMode
import com.flex.launcher.domain.model.LauncherPrefs
import com.flex.launcher.domain.model.ThemeMode
import com.flex.launcher.domain.theme.ThemePresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PreferencesTest {

    private val json = PreferencesRepository.defaultJson()

    @Test
    fun `defaults survive a json round trip`() {
        val encoded = json.encodeToString(LauncherPrefs.serializer(), LauncherPrefs.DEFAULT)
        val decoded = json.decodeFromString(LauncherPrefs.serializer(), encoded)
        assertEquals(LauncherPrefs.DEFAULT, decoded)
    }

    @Test
    fun `all preference fields round trip`() {
        val custom = LauncherPrefs.DEFAULT.copy(
            themeId = ThemePresets.CUSTOM_ID,
            themeMode = ThemeMode.DARK,
            amoledMode = true,
            backgroundOpacity = 42f,
            cardCornerRadius = 30f,
            hiddenApps = setOf("com.example.a", "com.example.b"),
            hapticsEnabled = false,
            wallpaperDim = 25f,
            drawer = LauncherPrefs.DEFAULT.drawer.copy(sortMode = AppSortMode.RECENT),
            recents = LauncherPrefs.DEFAULT.recents.copy(maxItems = 9),
            animations = AnimationSettings(reducedMotion = true),
        )
        val encoded = json.encodeToString(LauncherPrefs.serializer(), custom)
        val decoded = json.decodeFromString(LauncherPrefs.serializer(), encoded)
        assertEquals(custom, decoded)
        assertEquals(setOf("com.example.a", "com.example.b"), decoded.hiddenApps)
        assertFalse(decoded.hapticsEnabled)
    }

    @Test
    fun `hidden apps persist as package identifiers`() {
        val prefs = LauncherPrefs.DEFAULT.copy(hiddenApps = setOf("com.flex.launcher.test"))
        val encoded = json.encodeToString(LauncherPrefs.serializer(), prefs)
        assertTrue(encoded.contains("com.flex.launcher.test"))
        val decoded = json.decodeFromString(LauncherPrefs.serializer(), encoded)
        assertTrue(decoded.hiddenApps.contains("com.flex.launcher.test"))
    }

    @Test
    fun `corrupt json falls back to defaults`() {
        val repo = PreferencesRepository(dataStore = throwingStore(), json = json)
        assertEquals(LauncherPrefs.DEFAULT, repo.decode("{not valid json"))
        assertEquals(LauncherPrefs.DEFAULT, repo.decode(""))
        assertEquals(LauncherPrefs.DEFAULT, repo.decode(null))
    }

    @Test
    fun `unknown json keys are ignored`() {
        val decoded = json.decodeFromString(
            LauncherPrefs.serializer(),
            """{"schemaVersion":1,"themeId":"ocean_blue","futureField":"ignored"}""",
        )
        assertEquals("ocean_blue", decoded.themeId)
    }

    @Test
    fun `sanitizer clamps untrusted values`() {
        val dirty = LauncherPrefs.DEFAULT.copy(
            backgroundOpacity = 500f,
            cardCornerRadius = -20f,
            wallpaperDim = 400f,
            hiddenApps = setOf("ok", "  "),
            recents = LauncherPrefs.DEFAULT.recents.copy(maxItems = 999),
        ).sanitized()

        assertEquals(100f, dirty.backgroundOpacity, 0.001f)
        assertEquals(0f, dirty.cardCornerRadius, 0.001f)
        assertEquals(80f, dirty.wallpaperDim, 0.001f)
        assertEquals(setOf("ok"), dirty.hiddenApps)
        assertEquals(12, dirty.recents.maxItems)
    }

    @Test
    fun `recent history json round trips`() {
        val store = RecentAppsStore(dataStore = throwingStore())
        val history = mapOf("com.a" to 111L, "com.b" to 222L)
        val encoded = store.encode(history)
        assertEquals(history, store.decode(encoded))
        assertTrue(store.decode("garbage").isEmpty())
        assertTrue(store.decode(null).isEmpty())
    }

    @Test
    fun `backup payload round trips`() {
        val payload = BackupPayload(
            exportedAtEpochMillis = 1234L,
            prefs = LauncherPrefs.DEFAULT.copy(themeId = "emerald_green"),
            recentHistory = mapOf("com.a" to 5L),
        )
        val text = BackupCodec.encode(payload)
        val result = BackupCodec.decode(text)
        assertTrue(result.isSuccess)
        assertEquals("emerald_green", result.getOrNull()?.prefs?.themeId)
        assertEquals(mapOf("com.a" to 5L), result.getOrNull()?.recentHistory)
    }

    @Test
    fun `invalid backup files are rejected with a message`() {
        val result = BackupCodec.decode("{\"hello\":1}")
        assertTrue(result.isFailure)
        assertNotNull(result.exceptionOrNull()?.message)
        assertTrue(BackupCodec.decode("").isFailure)
    }

    @Test
    fun `future schema versions are rejected`() {
        val futureJson = """
            {"app":"Flex Launcher","schemaVersion":99,"prefs":{"schemaVersion":99}}
        """.trimIndent()
        val result = BackupCodec.decode(futureJson)
        assertTrue(result.isFailure)
    }

    @Test
    fun `theme id resolution handles custom and unknown ids`() {
        assertTrue(ThemePresets.exists(ThemePresets.CUSTOM_ID))
        assertNull(ThemePresets.all.firstOrNull { it.id == "unknown" })
    }

    /** A DataStore that is never touched by these pure-JSON tests. */
    private fun throwingStore() = object : androidx.datastore.core.DataStore<androidx.datastore.preferences.core.Preferences> {
        override val data: kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences> =
            kotlinx.coroutines.flow.flow {
                throw UnsupportedOperationException("not used in unit tests")
            }

        override suspend fun updateData(
            transform: suspend (t: androidx.datastore.preferences.core.Preferences) -> androidx.datastore.preferences.core.Preferences,
        ): androidx.datastore.preferences.core.Preferences =
            throw UnsupportedOperationException("not used in unit tests")
    }
}
