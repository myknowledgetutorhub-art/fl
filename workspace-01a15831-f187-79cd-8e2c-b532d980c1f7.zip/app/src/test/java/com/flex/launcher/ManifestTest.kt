package com.flex.launcher

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.w3c.dom.Element
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

/**
 * Verifies the *source* manifest: HOME intent filter, export flags and the "no unnecessary
 * permissions" policy. Runs on the JVM, so it also protects against regressions in CI.
 */
class ManifestTest {

    private val androidNs = "http://schemas.android.com/apk/res/android"

    private val manifest: Element by lazy {
        val candidates = listOf(
            File("src/main/AndroidManifest.xml"),
            File("app/src/main/AndroidManifest.xml"),
        )
        val file = candidates.firstOrNull { it.exists() }
            ?: error("AndroidManifest.xml not found from ${File(".").absolutePath}")
        val factory = DocumentBuilderFactory.newInstance().apply { isNamespaceAware = true }
        factory.newDocumentBuilder().parse(file).documentElement
    }

    private fun Element.children(tag: String): List<Element> {
        val nodes = getElementsByTagName(tag)
        return (0 until nodes.length).mapNotNull { nodes.item(it) as? Element }
    }

    private fun Element.attr(name: String): String? = getAttributeNS(androidNs, name).takeIf { it.isNotEmpty() }

    private fun activity(nameSuffix: String): Element =
        manifest.children("activity").first { it.attr("name")?.endsWith(nameSuffix) == true }

    private fun categoriesOf(element: Element): List<String> =
        element.children("category").mapNotNull { it.attr("name") }

    private fun actionsOf(element: Element): List<String> =
        element.children("action").mapNotNull { it.attr("name") }

    @Test
    fun `main activity is exported for the launcher intent`() {
        val main = activity("MainActivity")
        assertEquals("true", main.attr("exported"))
        assertEquals("singleTask", main.attr("launchMode"))
    }

    @Test
    fun `main activity declares the HOME category`() {
        val main = activity("MainActivity")
        val filters = (0 until main.getElementsByTagName("intent-filter").length)
            .map { main.getElementsByTagName("intent-filter").item(it) as Element }

        val homeFilter = filters.firstOrNull { filter ->
            categoriesOf(filter).contains("android.intent.category.HOME")
        }
        assertTrue("MainActivity must declare CATEGORY_HOME", homeFilter != null)
        assertTrue(actionsOf(homeFilter!!).contains("android.intent.action.MAIN"))
        assertTrue(categoriesOf(homeFilter).contains("android.intent.category.DEFAULT"))
        // Also reachable from the app drawer so users can open settings if not default.
        assertTrue(categoriesOf(homeFilter).contains("android.intent.category.LAUNCHER"))
    }

    @Test
    fun `only the main activity is exported`() {
        val exported = manifest.children("activity").filter { it.attr("exported") == "true" }
        assertEquals(1, exported.size)
    }

    @Test
    fun `no services or receivers are declared`() {
        assertTrue(manifest.children("service").isEmpty())
        assertTrue(manifest.children("receiver").isEmpty())
    }

    @Test
    fun `usage stats permission is declared and documented`() {
        val permissions = manifest.children("uses-permission").mapNotNull { it.attr("name") }
        assertTrue(permissions.contains("android.permission.PACKAGE_USAGE_STATS"))
        assertTrue(permissions.contains("android.permission.SET_WALLPAPER"))
    }

    @Test
    fun `dangerous or unnecessary permissions are absent`() {
        val permissions = manifest.children("uses-permission").mapNotNull { it.attr("name") }.toSet()
        listOf(
            "android.permission.INTERNET",
            "android.permission.CALL_PHONE",
            "android.permission.READ_CONTACTS",
            "android.permission.READ_SMS",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.CAMERA",
            "android.permission.RECORD_AUDIO",
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE",
            "android.permission.READ_PHONE_STATE",
            "android.permission.QUERY_ALL_PACKAGES",
            "android.permission.SYSTEM_ALERT_WINDOW",
            "android.permission.REQUEST_DELETE_PACKAGES",
        ).forEach { forbidden ->
            assertFalse("Manifest must not request $forbidden", permissions.contains(forbidden))
        }
    }

    @Test
    fun `package visibility is scoped through queries`() {
        val queries = manifest.children("queries")
        assertTrue("a <queries> block is required on Android 11+", queries.isNotEmpty())
        val intents = queries.first().children("intent")
        assertTrue(intents.any { intent ->
            actionsOf(intent).contains("android.intent.action.MAIN") &&
                categoriesOf(intent).contains("android.intent.category.LAUNCHER")
        })
    }

    @Test
    fun `backup is disabled to protect local preferences`() {
        val application = manifest.children("application").first()
        assertEquals("false", application.attr("allowBackup"))
    }
}
