package com.flex.launcher

import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.RecentResolver
import com.flex.launcher.domain.model.RecentSource
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecentResolverTest {

    private fun app(pkg: String, label: String = pkg) =
        AppEntry(packageName = pkg, activityName = "$pkg.Main", label = label)

    private val apps = listOf(
        app("com.a"), app("com.b"), app("com.c"), app("com.d"),
    )

    @Test
    fun `usage stats order results newest first`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = mapOf("com.a" to 100L, "com.c" to 300L, "com.b" to 200L),
            localHistory = emptyMap(),
            hidden = emptySet(),
            limit = 10,
            preferUsageStats = true,
        )
        assertEquals(listOf("com.c", "com.b", "com.a"), result.map { it.app.packageName })
        assertTrue(result.all { it.source == RecentSource.USAGE_STATS })
    }

    @Test
    fun `local history is used when usage stats are unavailable`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = emptyMap(),
            localHistory = mapOf("com.d" to 50L, "com.a" to 90L),
            hidden = emptySet(),
            limit = 10,
            preferUsageStats = true,
        )
        assertEquals(listOf("com.a", "com.d"), result.map { it.app.packageName })
        assertTrue(result.all { it.source == RecentSource.LOCAL_HISTORY })
    }

    @Test
    fun `limit is honoured`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = apps.associate { it.packageName to it.packageName.hashCode().toLong() },
            localHistory = emptyMap(),
            hidden = emptySet(),
            limit = 2,
            preferUsageStats = true,
        )
        assertEquals(2, result.size)
    }

    @Test
    fun `zero limit returns empty list`() {
        val result = RecentResolver.resolve(apps, mapOf("com.a" to 1L), emptyMap(), emptySet(), 0, true)
        assertTrue(result.isEmpty())
    }

    @Test
    fun `hidden and unknown packages are excluded`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = mapOf("com.a" to 10L, "com.hidden" to 20L, "com.unknown" to 30L),
            localHistory = mapOf("com.b" to 40L),
            hidden = setOf("com.b"),
            limit = 10,
            preferUsageStats = true,
        )
        assertEquals(listOf("com.a"), result.map { it.app.packageName })
    }

    @Test
    fun `fresher local launch wins over stale usage data`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = mapOf("com.a" to 100L),
            localHistory = mapOf("com.a" to 500L),
            hidden = emptySet(),
            limit = 5,
            preferUsageStats = true,
        )
        assertEquals(500L, result.first().lastUsedMillis)
    }

    @Test
    fun `local history is preferred when usage tracking is disabled`() {
        val result = RecentResolver.resolve(
            apps = apps,
            usageStats = mapOf("com.a" to 900L),
            localHistory = mapOf("com.b" to 100L),
            hidden = emptySet(),
            limit = 5,
            preferUsageStats = false,
        )
        assertEquals(RecentSource.LOCAL_HISTORY, result.first().source)
        assertEquals("com.b", result.first().app.packageName)
    }

    @Test
    fun `empty inputs produce an empty list`() {
        assertTrue(RecentResolver.resolve(emptyList(), emptyMap(), emptyMap(), emptySet(), 5, true).isEmpty())
    }
}
