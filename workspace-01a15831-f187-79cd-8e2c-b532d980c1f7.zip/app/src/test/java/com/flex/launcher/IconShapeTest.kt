package com.flex.launcher

import com.flex.launcher.domain.icons.IconSettings
import com.flex.launcher.domain.icons.IconShape
import com.flex.launcher.domain.icons.ShapeGeometry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IconShapeTest {

    @Test
    fun `twelve icon shapes exist`() {
        assertTrue("found ${IconShape.all.size}", IconShape.all.size >= 12)
    }

    @Test
    fun `required shape names are present`() {
        val labels = IconShape.all.map { it.label }
        listOf(
            "Circle", "Rounded square", "Square", "Squircle", "Teardrop", "Hexagon",
            "Octagon", "Diamond", "Flower", "Pebble", "Shield", "Rounded diamond",
        ).forEach { required ->
            assertTrue("missing shape $required", labels.contains(required))
        }
    }

    @Test
    fun `every shape has unique id and geometry`() {
        assertEquals(IconShape.all.size, IconShape.all.map { it.id }.toSet().size)
        assertEquals(
            "geometries must be genuinely distinct",
            IconShape.all.size,
            IconShape.all.map { it.geometry }.toSet().size,
        )
    }

    @Test
    fun `polygon shapes use the right vertex counts`() {
        assertEquals(ShapeGeometry.RegularPolygon(6, 0f), IconShape.HEXAGON.geometry)
        assertEquals(ShapeGeometry.RegularPolygon(8, 22.5f), IconShape.OCTAGON.geometry)
        assertEquals(ShapeGeometry.RegularPolygon(4, 0f, 0.99f), IconShape.DIAMOND.geometry)
        assertEquals(4, (IconShape.FLOWER.geometry as ShapeGeometry.Flower).lobes)
    }

    @Test
    fun `teardrop has exactly one sharp corner`() {
        val teardrop = IconShape.TEARDROP.geometry as ShapeGeometry.Teardrop
        assertEquals(0.42f, teardrop.radiusRatio, 0.001f)
        assertNotEquals(IconShape.ROUNDED_SQUARE.geometry, teardrop)
    }

    @Test
    fun `squircle uses a superellipse exponent`() {
        val squircle = IconShape.SQUIRCLE.geometry as ShapeGeometry.Superellipse
        assertEquals(4f, squircle.exponent, 0.001f)
    }

    @Test
    fun `unknown shape id falls back to squircle`() {
        assertEquals(IconShape.SQUIRCLE, IconShape.fromId("not-a-shape"))
        assertEquals(IconShape.CIRCLE, IconShape.fromId("circle"))
        assertEquals(IconShape.SQUIRCLE, IconShape.fromId(null))
    }

    @Test
    fun `icon settings clamp every value`() {
        val extreme = IconSettings(
            shapeId = "bogus",
            sizeDp = 500f,
            spacingDp = -10f,
            homeColumns = 99,
            drawerColumns = -4,
        ).sanitized()

        assertEquals(IconShape.SQUIRCLE.id, extreme.shapeId)
        assertEquals(IconSettings.ICON_SIZE.endInclusive, extreme.sizeDp, 0.001f)
        assertEquals(IconSettings.ICON_SPACING.start, extreme.spacingDp, 0.001f)
        assertEquals(IconSettings.HOME_COLUMNS.endInclusive, extreme.homeColumns)
        assertEquals(IconSettings.DRAWER_COLUMNS.start, extreme.drawerColumns)
    }

    @Test
    fun `column ranges are usable`() {
        assertTrue(IconSettings.HOME_COLUMNS.first >= 3)
        assertTrue(IconSettings.DRAWER_COLUMNS.last <= 7)
        assertTrue(IconSettings.DEFAULT.homeColumns in IconSettings.HOME_COLUMNS)
    }
}
