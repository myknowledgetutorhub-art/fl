package com.flex.launcher

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.flex.launcher.data.apps.AppRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/** Package discovery smoke tests using Robolectric's real PackageManager implementation. */
@RunWith(RobolectricTestRunner::class)
class AppRepositoryTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    @Test
    fun `load returns launchable activities without crashing on an empty device`() = runBlocking {
        val repository = AppRepository(context, kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main))
        val apps = repository.load()
        // Robolectric exposes at least the app under test's own launcher activity.
        assertTrue(apps.isNotEmpty())
        val self = apps.firstOrNull { it.packageName == context.packageName }
        assertNotNull("Flex Launcher itself must be discoverable", self)
        assertTrue(self!!.label.isNotBlank())
        assertTrue(self.activityName.isNotBlank())
        assertNull(repository.errorState())
    }

    @Test
    fun `unknown package has no launch intent`() = runBlocking {
        val repository = AppRepository(context, kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main))
        assertFalse(repository.isInstalled("com.example.definitely.not.installed"))
    }

    @Test
    fun `entry key is stable for persistence`() = runBlocking {
        val repository = AppRepository(context, kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main))
        val apps = repository.load()
        apps.forEach { app ->
            assertTrue(app.key.contains(app.packageName))
            assertTrue(app.key.contains(app.activityName))
        }
    }
}
