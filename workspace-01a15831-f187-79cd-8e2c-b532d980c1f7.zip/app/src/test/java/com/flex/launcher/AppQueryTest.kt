package com.flex.launcher

import com.flex.launcher.domain.model.AppEntry
import com.flex.launcher.domain.model.AppQuery
import com.flex.launcher.domain.model.AppSortMode
import com.flex.launcher.domain.model.normalizeForSort
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppQueryTest {

    private fun app(pkg: String, label: String) =
        AppEntry(packageName = pkg, activityName = "$pkg.Main", label = label)

    private val apps = listOf(
        app("com.android.chrome", "Chrome"),
        app("com.whatsapp", "WhatsApp"),
        app("com.android.camera", "Camera"),
        app("org.example.cafe", "Café"),
        app("com.example.zed", "zed"),
        app("com.example.empty", "   "),
    )

    @Test
    fun `alphabetical sorting ignores case and accents`() {
        val sorted = AppQuery.alphabetical(apps).map { it.label.trim() }
        assertEquals(listOf("", "Café", "Camera", "Chrome", "WhatsApp", "zed"), sorted)
    }

    @Test
    fun `normalizeForSort strips diacritics`() {
        assertEquals("cafe", normalizeForSort("Café"))
        assertEquals("uber", normalizeForSort("Über"))
        assertEquals("apps", normalizeForSort("  APPS  "))
    }

    @Test
    fun `hidden packages are filtered out`() {
        val visible = AppQuery.visible(apps, setOf("com.whatsapp", "com.android.chrome"))
        assertEquals(4, visible.size)
        assertTrue(visible.none { it.packageName == "com.whatsapp" })
    }

    @Test
    fun `search matches label case insensitively`() {
        assertEquals(listOf("WhatsApp"), AppQuery.search(apps, "whats").map { it.label })
        assertEquals(listOf("Chrome"), AppQuery.search(apps, "CHROME").map { it.label })
    }

    @Test
    fun `search matches accent-insensitive queries`() {
        assertEquals(listOf("Café"), AppQuery.search(apps, "cafe").map { it.label })
    }

    @Test
    fun `search matches package names`() {
        val results = AppQuery.search(apps, "android")
        assertEquals(2, results.size)
        assertTrue(results.all { it.packageName.contains("android") })
    }

    @Test
    fun `blank query returns everything`() {
        assertEquals(apps.size, AppQuery.search(apps, "").size)
        assertEquals(apps.size, AppQuery.search(apps, "   ").size)
    }

    @Test
    fun `no matches returns empty list`() {
        assertTrue(AppQuery.search(apps, "zzzzz").isEmpty())
    }

    @Test
    fun `recent sorting puts known packages first`() {
        val recency = mapOf(
            "com.whatsapp" to 5_000L,
            "com.android.chrome" to 9_000L,
        )
        val sorted = AppQuery.byRecent(apps, recency).map { it.packageName }
        assertEquals("com.android.chrome", sorted[0])
        assertEquals("com.whatsapp", sorted[1])
        // Remaining apps fall back to alphabetical
        assertEquals(sorted.size, apps.size)
    }

    @Test
    fun `sort mode dispatches to the right strategy`() {
        val recency = mapOf("com.whatsapp" to 10L)
        val recent = AppQuery.sorted(apps, AppSortMode.RECENT, recency)
        val alpha = AppQuery.sorted(apps, AppSortMode.ALPHABETICAL, recency)
        assertEquals("com.whatsapp", recent.first().packageName)
        assertEquals("", alpha.first().label.trim())
    }
}
