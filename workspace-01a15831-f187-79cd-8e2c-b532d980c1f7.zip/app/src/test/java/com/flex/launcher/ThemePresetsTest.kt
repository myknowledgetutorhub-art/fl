package com.flex.launcher

import com.flex.launcher.core.util.ColorMath
import com.flex.launcher.domain.theme.GradientDirection
import com.flex.launcher.domain.theme.ThemePalette
import com.flex.launcher.domain.theme.ThemePresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemePresetsTest {

    private val requiredNames = listOf(
        "Pure AMOLED Black", "Midnight Black", "Graphite Gray", "Dark Titanium", "Ocean Blue",
        "Arctic Blue", "Neon Cyberpunk", "Purple Aurora", "Deep Violet", "Emerald Green",
        "Forest Green", "Sunset Orange", "Rose Pink", "Ruby Red", "Golden Luxury",
        "Pastel Dreams", "Minimal White", "Warm Sand", "Frosted Glass", "Gradient Galaxy",
    )

    @Test
    fun `at least twenty presets exist`() {
        assertTrue("expected >= 20 presets, found ${ThemePresets.all.size}", ThemePresets.all.size >= 20)
    }

    @Test
    fun `every required preset name is present`() {
        val names = ThemePresets.all.map { it.name }
        requiredNames.forEach { required ->
            assertTrue("missing preset: $required", names.contains(required))
        }
    }

    @Test
    fun `presets have unique ids and names`() {
        assertEquals(ThemePresets.all.size, ThemePresets.all.map { it.id }.toSet().size)
        assertEquals(ThemePresets.all.size, ThemePresets.all.map { it.name }.toSet().size)
    }

    @Test
    fun `preset backgrounds are visually distinct`() {
        val backgrounds = ThemePresets.all.map { it.palette.background }
        assertEquals(backgrounds.size, backgrounds.toSet().size)
    }

    @Test
    fun `primary text meets WCAG AA on its background`() {
        ThemePresets.all.forEach { preset ->
            val ratio = ColorMath.contrastRatio(preset.palette.background, preset.palette.textPrimary)
            assertTrue(
                "${preset.name} primary text contrast was $ratio",
                ratio >= 4.5,
            )
        }
    }

    @Test
    fun `secondary text stays legible`() {
        ThemePresets.all.forEach { preset ->
            val ratio = ColorMath.contrastRatio(preset.palette.background, preset.palette.textSecondary)
            assertTrue("${preset.name} secondary text contrast was $ratio", ratio >= 3.0)
        }
    }

    @Test
    fun `accent colours are visible against the background`() {
        ThemePresets.all.forEach { preset ->
            val ratio = ColorMath.contrastRatio(preset.palette.background, preset.palette.primary)
            assertTrue("${preset.name} primary accent contrast was $ratio", ratio >= 3.0)
        }
    }

    @Test
    fun `amoled preset uses pure black`() {
        val amoled = ThemePresets.byId("pure_amoled")
        assertEquals(0xFF000000.toInt(), amoled.palette.background)
        assertTrue(amoled.palette.isAmoled)
        assertEquals(0xFF000000.toInt(), amoled.palette.effectiveBackground(amoledMode = true))
    }

    @Test
    fun `amoled override forces black for any dark palette`() {
        val ocean = ThemePresets.byId("ocean_blue").palette
        assertEquals(0xFF000000.toInt(), ocean.effectiveBackground(amoledMode = true))
        assertNotEquals(0xFF000000.toInt(), ocean.effectiveBackground(amoledMode = false))
    }

    @Test
    fun `light presets are flagged and dark ones are not`() {
        assertTrue(ThemePresets.byId("minimal_white").palette.isLight)
        assertTrue(ThemePresets.byId("warm_sand").palette.isLight)
        assertFalse(ThemePresets.byId("midnight_black").palette.isLight)
    }

    @Test
    fun `unknown id falls back to first preset`() {
        assertEquals(ThemePresets.all[0].id, ThemePresets.byId("does-not-exist").id)
        assertFalse(ThemePresets.exists("does-not-exist"))
        assertTrue(ThemePresets.exists(ThemePresets.CUSTOM_ID))
    }

    @Test
    fun `gradients have at least two stops when specified`() {
        ThemePresets.all.filter { it.palette.gradient.isNotEmpty() }.forEach { preset ->
            assertTrue("${preset.name} has a single-stop gradient", preset.palette.gradient.size >= 2)
            assertNotEquals(GradientDirection.NONE, preset.palette.direction)
        }
    }

    @Test
    fun `light variant of a dark palette is readable`() {
        val light = ThemePresets.byId("midnight_black").palette.toLightVariant()
        assertTrue(light.isLight)
        assertTrue(ColorMath.contrastRatio(light.background, light.textPrimary) >= 4.5)
    }

    @Test
    fun `dark variant of a light palette is readable`() {
        val dark = ThemePresets.byId("minimal_white").palette.toDarkVariant()
        assertFalse(dark.isLight)
        assertTrue(ColorMath.contrastRatio(dark.background, dark.textPrimary) >= 4.5)
    }

    @Test
    fun `custom palette default resolves glyphs`() {
        val palette = ThemePalette.DEFAULT
        assertEquals(palette.readableText(palette.background), palette.textPrimary)
    }
}
