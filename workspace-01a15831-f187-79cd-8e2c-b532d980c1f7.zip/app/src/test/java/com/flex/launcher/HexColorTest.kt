package com.flex.launcher

import com.flex.launcher.core.util.ColorMath
import com.flex.launcher.core.util.HexColor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HexColorTest {

    @Test
    fun `parses six digit hex`() {
        assertEquals(0xFF112233.toInt(), HexColor.parse("#112233"))
        assertEquals(0xFFAABBCC.toInt(), HexColor.parse("AABBCC"))
        assertEquals(0xFF000000.toInt(), HexColor.parse("#000000"))
        assertEquals(0xFFFFFFFF.toInt(), HexColor.parse("#ffffff"))
    }

    @Test
    fun `parses three digit shorthand`() {
        assertEquals(0xFFFFFFFF.toInt(), HexColor.parse("#fff"))
        assertEquals(0xFF112233.toInt(), HexColor.parse("#123"))
    }

    @Test
    fun `parses eight digit argb`() {
        assertEquals(0x80FF0000.toInt(), HexColor.parse("#80FF0000"))
    }

    @Test
    fun `rejects invalid input`() {
        listOf("", "   ", "#", "#12", "#12345", "#GGGGGG", "red", "#1234567", "##123456").forEach { input ->
            assertFalse("should reject '$input'", HexColor.isValid(input))
            assertNull("should not parse '$input'", HexColor.parse(input))
        }
        assertNull(HexColor.parse(null))
    }

    @Test
    fun `tolerates whitespace and leading hash`() {
        assertEquals(0xFF00FF00.toInt(), HexColor.parse("  #00FF00  "))
        assertEquals(0xFF00FF00.toInt(), HexColor.parse("00FF00"))
    }

    @Test
    fun `formats canonically`() {
        assertEquals("#112233", HexColor.format(0xFF112233.toInt()))
        assertEquals("#112233", HexColor.format(0x80112233.toInt()))
        assertEquals("#80112233", HexColor.format(0x80112233.toInt(), includeAlpha = true))
    }

    @Test
    fun `normalize round trips`() {
        val value = 0xFF7AA2F7.toInt()
        assertEquals("#7AA2F7", HexColor.normalize("#7aa2f7"))
        assertEquals(value, HexColor.parse(HexColor.normalize(HexColor.format(value))))
        assertNull(HexColor.normalize("nope"))
    }

    @Test
    fun `contrast ratio is symmetric and bounded`() {
        val black = 0xFF000000.toInt()
        val white = 0xFFFFFFFF.toInt()
        assertEquals(21.0, ColorMath.contrastRatio(black, white), 0.01)
        assertEquals(1.0, ColorMath.contrastRatio(black, black), 0.01)
        assertEquals(
            ColorMath.contrastRatio(black, white),
            ColorMath.contrastRatio(white, black),
            0.0001,
        )
    }

    @Test
    fun `ensure contrast fixes unreadable text`() {
        val background = 0xFF111111.toInt()
        val unreadable = 0xFF1A1A1A.toInt()
        val fixed = ColorMath.ensureContrast(background, unreadable, 4.5)
        assertTrue(ColorMath.contrastRatio(background, fixed) >= 4.5)
    }

    @Test
    fun `blend produces opaque result between colours`() {
        val result = ColorMath.blend(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0.5f)
        assertEquals(0xFF, (result ushr 24) and 0xFF)
        assertEquals(127, (result ushr 16) and 0xFF, )
        assertEquals(0xFFFFFFFF.toInt(), ColorMath.blend(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 1f))
    }
}
