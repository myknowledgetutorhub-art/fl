package com.flex.launcher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import com.flex.launcher.domain.theme.ThemePresets
import com.flex.launcher.ui.components.ColorHexField
import com.flex.launcher.ui.components.SegmentedChoice
import com.flex.launcher.ui.components.SettingsCard
import com.flex.launcher.ui.components.SettingsSwitchRow
import com.flex.launcher.ui.theme.FlexTheme
import com.flex.launcher.ui.theme.FlexType
import com.flex.launcher.ui.theme.LauncherColors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/** Interactive UI tests for the reusable settings controls used across the settings center. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33], qualifiers = "w411dp-h891dp-xxhdpi")
class SettingsWidgetsTest {

    @get:Rule
    val rule = createComposeRule()

    private val palette = ThemePresets.byId("minimal_white").palette
    private val colors = LauncherColors(
        background = androidx.compose.ui.graphics.Color(palette.background),
        backgroundGradient = emptyList(),
        gradientDirection = palette.direction,
        surface = androidx.compose.ui.graphics.Color(palette.surface),
        card = androidx.compose.ui.graphics.Color(palette.card),
        primary = androidx.compose.ui.graphics.Color(palette.primary),
        secondary = androidx.compose.ui.graphics.Color(palette.secondary),
        accent = androidx.compose.ui.graphics.Color(palette.accent),
        textPrimary = androidx.compose.ui.graphics.Color(palette.textPrimary),
        textSecondary = androidx.compose.ui.graphics.Color(palette.textSecondary),
        isLight = true,
        statusBarIconsDark = true,
        backgroundOpacity = 100f,
    )

    @Test
    fun switchRowTogglesAndReportsNewValue() {
        var toggled: Boolean? = null
        rule.setContent {
            FlexTheme(colors, FlexType.Default, com.flex.launcher.domain.animations.AnimationSettings.DEFAULT) {
                SettingsCard {
                    SettingsSwitchRow(
                        title = "Pure AMOLED black",
                        checked = false,
                        onCheckedChange = { toggled = it },
                    )
                }
            }
        }
        rule.onNodeWithText("Pure AMOLED black").performClick()
        assertEquals(true, toggled)
    }

    @Test
    fun segmentedChoiceSelectsOption() {
        var selected by mutableStateOf("A")
        rule.setContent {
            FlexTheme(colors, FlexType.Default, com.flex.launcher.domain.animations.AnimationSettings.DEFAULT) {
                SegmentedChoice(
                    options = listOf("A", "B", "C"),
                    selected = selected,
                    onSelect = { selected = it },
                    label = { it },
                )
            }
        }
        rule.onNodeWithText("C").performClick()
        assertEquals("C", selected)
    }

    @Test
    fun hexFieldAppliesValidColour() {
        var applied: Int? = null
        rule.setContent {
            FlexTheme(colors, FlexType.Default, com.flex.launcher.domain.animations.AnimationSettings.DEFAULT) {
                ColorHexField(label = "Primary", color = 0xFF112233.toInt()) { applied = it }
            }
        }
        rule.onNodeWithTag("color_field_Primary").performTextReplacement("#00FF00")
        assertEquals(0xFF00FF00.toInt(), applied)
    }

    @Test
    fun hexFieldRejectsInvalidColourAndShowsError() {
        var applied: Int? = null
        rule.setContent {
            FlexTheme(colors, FlexType.Default, com.flex.launcher.domain.animations.AnimationSettings.DEFAULT) {
                ColorHexField(label = "Accent", color = 0xFF112233.toInt()) { applied = it }
            }
        }
        rule.onNodeWithTag("color_field_Accent").performTextReplacement("nope")
        rule.onNodeWithText("Enter #RRGGBB or #AARRGGBB").assertIsDisplayed()
        assertEquals(null, applied)
    }

    @Test
    fun lightThemeKeepsTextReadable() {
        assertTrue(colors.isLight)
        assertTrue(colors.statusBarIconsDark)
    }
}
