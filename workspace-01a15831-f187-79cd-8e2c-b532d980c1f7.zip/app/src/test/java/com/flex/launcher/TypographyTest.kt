package com.flex.launcher

import com.flex.launcher.domain.typography.FontOptions
import com.flex.launcher.domain.typography.FontSource
import com.flex.launcher.domain.typography.TypographyLimits
import com.flex.launcher.domain.typography.TypographySettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TypographyTest {

    @Test
    fun `at least twenty four font options exist`() {
        assertTrue("found ${FontOptions.all.size}", FontOptions.all.size >= 24)
    }

    @Test
    fun `font ids and names are unique`() {
        assertEquals(FontOptions.all.size, FontOptions.all.map { it.id }.toSet().size)
        assertEquals(FontOptions.all.size, FontOptions.all.map { it.displayName }.toSet().size)
    }

    @Test
    fun `fonts are real assets not duplicated labels`() {
        val bundledRes = FontOptions.all
            .mapNotNull { (it.source as? FontSource.Bundled)?.regularRes }
        assertEquals("bundled font assets must be distinct", bundledRes.size, bundledRes.toSet().size)
        // At least 20 real bundled families, the rest are platform families.
        assertTrue("expected >= 20 bundled fonts, found ${bundledRes.size}", bundledRes.size >= 20)
        assertTrue(FontOptions.all.any { it.source is FontSource.System })
    }

    @Test
    fun `every category from the spec is represented`() {
        val categories = FontOptions.all.map { it.category }.toSet()
        assertTrue(categories.size >= 8)
    }

    @Test
    fun `licences are documented for every font`() {
        FontOptions.all.forEach { font ->
            assertTrue("${font.displayName} has no licence info", font.license.isNotBlank())
        }
    }

    @Test
    fun `unknown font id falls back to default`() {
        assertEquals(FontOptions.DEFAULT_ID, FontOptions.byId("nonsense").id)
        assertFalse(FontOptions.exists("nonsense"))
    }

    @Test
    fun `default typography is inside every range`() {
        val settings = TypographySettings.DEFAULT
        assertTrue(settings.homeLabelSp in TypographyLimits.HOME_LABEL)
        assertTrue(settings.drawerLabelSp in TypographyLimits.DRAWER_LABEL)
        assertTrue(settings.sectionHeadingSp in TypographyLimits.SECTION_HEADING)
        assertTrue(settings.searchTextSp in TypographyLimits.SEARCH)
        assertTrue(settings.clockSp in TypographyLimits.CLOCK)
        assertTrue(settings.dateSp in TypographyLimits.DATE)
        assertTrue(settings.lineHeightMultiplier in TypographyLimits.LINE_HEIGHT)
        assertTrue(settings.textScale in TypographyLimits.TEXT_SCALE)
    }

    @Test
    fun `out of range sizes are clamped`() {
        val extreme = TypographySettings(
            homeLabelSp = 999f,
            drawerLabelSp = -5f,
            sectionHeadingSp = 1000f,
            searchTextSp = 0f,
            clockSp = -100f,
            dateSp = 500f,
            fontWeight = 2000,
            lineHeightMultiplier = 9f,
            letterSpacingEm = 5f,
            textScale = 12f,
        ).sanitized()

        assertEquals(TypographyLimits.HOME_LABEL.endInclusive, extreme.homeLabelSp, 0.001f)
        assertEquals(TypographyLimits.DRAWER_LABEL.start, extreme.drawerLabelSp, 0.001f)
        assertEquals(TypographyLimits.SECTION_HEADING.endInclusive, extreme.sectionHeadingSp, 0.001f)
        assertEquals(TypographyLimits.SEARCH.start, extreme.searchTextSp, 0.001f)
        assertEquals(TypographyLimits.CLOCK.start, extreme.clockSp, 0.001f)
        assertEquals(TypographyLimits.DATE.endInclusive, extreme.dateSp, 0.001f)
        assertEquals(800, extreme.fontWeight)
        assertEquals(TypographyLimits.LINE_HEIGHT.endInclusive, extreme.lineHeightMultiplier, 0.001f)
        assertEquals(TypographyLimits.TEXT_SCALE.endInclusive, extreme.textScale, 0.001f)
    }

    @Test
    fun `NaN values fall back to range start`() {
        val sanitized = TypographySettings(homeLabelSp = Float.NaN).sanitized()
        assertEquals(TypographyLimits.HOME_LABEL.start, sanitized.homeLabelSp, 0.001f)
    }

    @Test
    fun `withX helpers stay in range`() {
        val base = TypographySettings.DEFAULT
        assertEquals(TypographyLimits.HOME_LABEL.endInclusive, base.withHomeLabel(500f).homeLabelSp, 0.001f)
        assertEquals(300, base.withWeight(100).fontWeight)
        assertEquals(TypographyLimits.TEXT_SCALE.endInclusive, base.withScale(99f).textScale, 0.001f)
        assertEquals(FontOptions.DEFAULT_ID, base.withFont("unknown").fontId)
    }

    @Test
    fun `text scale multiplies effective sizes`() {
        val scaled = TypographySettings.DEFAULT.copy(textScale = 1.25f).sanitized()
        assertEquals(
            scaled.homeLabelSp * 1.25f,
            scaled.effectiveHomeLabel,
            0.001f,
        )
        assertEquals(scaled.clockSp * 1.25f, scaled.effectiveClock, 0.001f)
    }

    @Test
    fun `bounds are ordered and inclusive`() {
        listOf(
            TypographyLimits.HOME_LABEL,
            TypographyLimits.DRAWER_LABEL,
            TypographyLimits.SECTION_HEADING,
            TypographyLimits.SEARCH,
            TypographyLimits.CLOCK,
            TypographyLimits.DATE,
            TypographyLimits.TEXT_SCALE,
        ).forEach { range ->
            assertTrue(range.start < range.endInclusive)
        }
    }
}
