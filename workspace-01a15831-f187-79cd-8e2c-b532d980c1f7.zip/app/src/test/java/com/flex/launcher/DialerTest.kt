package com.flex.launcher

import android.content.Intent
import com.flex.launcher.domain.dialer.DialerIntents
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class DialerTest {

    @Test
    fun `builds an ACTION_DIAL intent for a valid number`() {
        val intent = DialerIntents.build("+1 (555) 123-4567")
        assertNotNull(intent)
        assertEquals(Intent.ACTION_DIAL, intent!!.action)
        assertEquals("tel:+15551234567", intent.data.toString())
        assertTrue(intent.flags and Intent.FLAG_ACTIVITY_NEW_TASK != 0)
    }

    @Test
    fun `never uses ACTION_CALL`() {
        val intent = DialerIntents.build("5551234")
        assertEquals(Intent.ACTION_DIAL, intent!!.action)
        assertFalse(intent.action == Intent.ACTION_CALL)
    }

    @Test
    fun `sanitizes formatting characters`() {
        assertEquals("5551234", DialerIntents.sanitize(" 5 5 5-1.2(3)4 "))
        assertEquals("+919876543210", DialerIntents.sanitize("+91 98765-43210"))
    }

    @Test
    fun `rejects empty and too short numbers`() {
        assertNull(DialerIntents.build(""))
        assertNull(DialerIntents.build("   "))
        assertNull(DialerIntents.build("12"))
        assertFalse(DialerIntents.isValidNumber(""))
        assertEquals("Enter a phone number", DialerIntents.validationError(""))
        assertTrue(DialerIntents.validationError("12")!!.contains("3 digits"))
    }

    @Test
    fun `rejects invalid characters`() {
        assertNull(DialerIntents.build("555-ABC"))
        assertNotNull(DialerIntents.validationError("555abc"))
    }

    @Test
    fun `rejects misplaced plus sign`() {
        assertNull(DialerIntents.build("55+5123"))
        assertNull(DialerIntents.build("++5551234"))
        assertNotNull(DialerIntents.build("+5551234"))
    }

    @Test
    fun `accepts DTMF characters`() {
        assertNotNull(DialerIntents.build("*123#"))
        assertNotNull(DialerIntents.build("123,456"))
    }

    @Test
    fun `rejects overly long numbers`() {
        assertNull(DialerIntents.build("1".repeat(25)))
        assertNotNull(DialerIntents.validationError("1".repeat(25)))
    }

    @Test
    fun `valid number has no error`() {
        assertNull(DialerIntents.validationError("9876543210"))
        assertTrue(DialerIntents.isValidNumber("9876543210"))
    }
}
