# Keep kotlinx.serialization generated serializers for preference models.
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.**
-keepclassmembers class com.flex.launcher.** {
    *** Companion;
}
-keepclasseswithmembers class com.flex.launcher.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.flex.launcher.data.prefs.**$$serializer { *; }
